`timescale 1ns / 1ps
// All ownership decisions run in the DDR core clock domain. Four frame slots
// keep the displayed frame and newest completed frame out of the writer's way.
module frame_bank_ctrl (
    input wire clk,
    input wire rst_n,
    input wire wr_start,
    input wire wr_complete,
    input wire rd_start,
    output reg [1:0] wr_bank,
    output reg [1:0] rd_bank,
    output reg display_valid
);
    reg [1:0] latest_bank;
    reg latest_valid;
    reg [1:0] next_bank;
    reg found;
    integer i;
    reg [1:0] candidate;

    always @* begin
        next_bank = wr_bank;
        found = 1'b0;
        candidate = wr_bank;
        for (i = 1; i < 4; i = i + 1) begin
            candidate = wr_bank + i;
            if (!found &&
                (!display_valid || candidate != rd_bank) &&
                (!latest_valid || candidate != latest_bank)) begin
                next_bank = candidate;
                found = 1'b1;
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_bank <= 2'd0;
            rd_bank <= 2'd0;
            latest_bank <= 2'd0;
            latest_valid <= 1'b0;
            display_valid <= 1'b0;
        end else begin
            if (wr_start)
                wr_bank <= next_bank;
            if (wr_complete) begin
                latest_bank <= wr_bank;
                latest_valid <= 1'b1;
            end
            // Latch only at the start of HDMI vertical blanking. Reuse a full
            // frame when the camera is late; intermediate full frames may drop.
            if (rd_start && latest_valid) begin
                rd_bank <= latest_bank;
                display_valid <= 1'b1;
            end
        end
    end
endmodule
