`timescale 1ns/1ps
// OV5640 471D=01 asserts VSYNC at end of frame. The interpolator must
// finish its bottom output row before publishing that frame boundary.
module tb_raw8_frame_end;
    parameter W=1920,H=1080;
    reg clk=0; always #5 clk=~clk;
    reg rst_n=0,vs=0,de=0;
    reg [7:0] raw=0;
    wire out_vs,out_de;
    wire [15:0] rgb;
    raw8_to_rgb565 #(.WIDTH(W),.HEIGHT(H)) dut(
        .pclk(clk),.rst_n(rst_n),.vs_in(vs),.de_in(de),.raw_in(raw),
        .vs_out(out_vs),.de_out(out_de),.rgb_out(rgb));
    integer pixels=0,lines=0,row_pixels=0,complete_frames=0;
    reg old_de=0,old_vs=0,armed=0;
    always @(posedge clk) begin
        #2;
        if(rst_n) begin
            if(out_vs && !old_vs) begin
                if(armed) begin
                    if(pixels!=W*H || lines!=H)
                        $fatal(1,"VSYNC interrupted frame: pixels=%0d lines=%0d expected=%0d/%0d",pixels,lines,W*H,H);
                    complete_frames=complete_frames+1;
                end
                armed=1; pixels=0; lines=0;
            end
            if(out_de) begin
                if(out_vs) $fatal(1,"RGB overlaps output VSYNC");
                if(rgb!=={5'd28,6'd26,5'd3}) $fatal(1,"wrong Bayer output %h",rgb);
                pixels=pixels+1; row_pixels=row_pixels+1;
            end
            if(old_de && !out_de) begin
                if(row_pixels!=W) $fatal(1,"short row %0d",row_pixels);
                lines=lines+1; row_pixels=0;
            end
            old_de=out_de; old_vs=out_vs;
        end
    end
    integer f,x,y;
    initial begin
        repeat(8) @(negedge clk); rst_n=1;
        vs=1; repeat(8) @(negedge clk); vs=0;
        repeat(W+40) @(negedge clk);
        for(f=0;f<3;f=f+1) begin
            // Third frame deliberately has VSYNC high over active data.
            // Capture must key off the frame edge, not gate all pixels by VS level.
            for(y=0;y<H;y=y+1) begin
                for(x=0;x<W;x=x+1) begin
                    de=1;
                    case({y[0],x[0]})
                        2'b00: raw=24;
                        2'b11: raw=224;
                        default: raw=104;
                    endcase
                    @(negedge clk);
                end
                de=0;
                if(y!=H-1) repeat(580) @(negedge clk);
            end
            // VSYNC coincides with HREF falling in frame 0, and follows it
            // by one PCLK in the other frames.
            if(f!=0) @(negedge clk);
            if(vs) begin vs=0; repeat(8) @(negedge clk); end
            vs=1; repeat(8) @(negedge clk);
            if(f!=1) vs=0;
            repeat(W+800) @(negedge clk);
        end
        if(complete_frames!=3) $fatal(1,"only %0d complete frames",complete_frames);
        $display("PASS end-of-frame VSYNC: 3 complete %0dx%0d frames, bottom row drained before VSYNC; high VS level accepted",W,H);
        $finish;
    end
    initial begin #200000000; $fatal(1,"timeout"); end
endmodule
