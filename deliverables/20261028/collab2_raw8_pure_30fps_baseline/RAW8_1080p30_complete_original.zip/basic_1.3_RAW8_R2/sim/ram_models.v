// Behavioral stand-ins for the example's unregistered-output dual-clock RAMs.
module wr_fram_buf(input [31:0] wr_data,input [11:0] wr_addr,input wr_en,wr_clk,wr_rst,
    output reg [255:0] rd_data,input [8:0] rd_addr,input rd_clk,rd_rst);
    reg [31:0] mem[0:4095];
    integer i;
    always @(posedge wr_clk) if(wr_en) mem[wr_addr]<=wr_data;
    always @(posedge rd_clk) begin
        if(rd_rst) rd_data<=0;
        else for(i=0;i<8;i=i+1) rd_data[i*32+:32]<=mem[{rd_addr,3'b0}+i];
    end
endmodule
module rd_fram_buf(input [255:0] wr_data,input [8:0] wr_addr,input wr_en,wr_clk,wr_rst,
    output reg [31:0] rd_data,input [11:0] rd_addr,input rd_clk,rd_rst);
    reg [31:0] mem[0:4095];
    integer i;
    always @(posedge wr_clk)
        if(wr_en) for(i=0;i<8;i=i+1) mem[{wr_addr,3'b0}+i]<=wr_data[i*32+:32];
    always @(posedge rd_clk) if(rd_rst) rd_data<=0; else rd_data<=mem[rd_addr];
endmodule
