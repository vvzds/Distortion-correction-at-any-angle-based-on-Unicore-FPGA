`timescale 1ns / 1ps
module tb_frame_bank_ctrl;
    reg clk=0; always #4 clk=~clk;
    reg rst_n=0, wr_start=0, wr_complete=0, rd_start=0;
    wire [1:0] wr_bank,rd_bank;
    wire valid;
    frame_bank_ctrl dut(clk,rst_n,wr_start,wr_complete,rd_start,wr_bank,rd_bank,valid);
    integer newest=-1;
    integer read_frame=-1;
    integer slot_frame[0:3];
    integer write_frame=0;
    integer cycles=0;
    reg [1:0] old_read;
    integer i;
    initial begin
        for(i=0;i<4;i=i+1) slot_frame[i]=-1;
        repeat(5) @(negedge clk);
        rst_n=1;
        // Independent frame periods, irregular camera completion, occasional
        // incomplete frames, repeated output frames, and simultaneous events.
        for(cycles=0;cycles<30000;cycles=cycles+1) begin
            wr_start=(cycles%97==0);
            wr_complete=(cycles%97==73 && write_frame%7!=0);
            rd_start=(cycles%101==37);
            old_read=rd_bank;
            if(rd_start && newest>=0) read_frame=slot_frame[newest];
            if(wr_complete) begin
                slot_frame[wr_bank]=write_frame;
                newest=wr_bank;
            end
            @(negedge clk);
            if(wr_start) begin
                write_frame=write_frame+1;
                if(valid && wr_bank==rd_bank) $fatal(1,"writer owns displayed slot");
                if(newest>=0 && wr_bank==newest) $fatal(1,"writer owns newest completed slot");
            end
            if(!rd_start && rd_bank!=old_read) $fatal(1,"read bank changed mid frame");
            if(valid && slot_frame[rd_bank]!=read_frame) $fatal(1,"displayed frame overwritten");
        end
        rst_n=0;
        @(negedge clk);
        if(valid) $fatal(1,"reset validity");
        $display("PASS frame banks: %0d cycles, %0d camera frames, asynchronous boundaries",cycles,write_frame);
        $finish;
    end
endmodule
