`timescale 1ns/1ps
module tb_fram_buf;
    localparam W=1920,H=6,WORDS=W*H/16;
    reg dclk=0; always #4 dclk=~dclk;
    reg cclk=0; always #5.952381 cclk=~cclk;
    reg vclk=0; always #6.734007 vclk=~vclk;
    reg rst_n=0, wr_vs=0,wr_de=0,rd_vs=0,rd_de=0;
    reg [15:0] pixel=0;
    wire out_de,ready;
    wire [15:0] out_pixel;
    wire [27:0] awaddr,araddr;
    wire [3:0] awlen,arlen;
    wire awvalid,arvalid;
    wire [255:0] wdata;
    wire [31:0] wstrb;
    reg wbusy=0,rbusy=0;
    reg [27:0] wa,ra;
    integer wremain=0,rremain=0,wdly=0,rdly=0;
    wire awready=!wbusy;
    wire arready=!rbusy;
    wire wready=wbusy && wdly==0;
    wire wlast=wready && wremain==1;
    reg [255:0] rdata=0;
    reg rvalid=0,rlast=0;
    reg [255:0] mem[0:4*WORDS-1];
    function integer idx(input [27:0] addr);
        begin idx=addr[21:20]*WORDS+(addr[19:0]>>3); end
    endfunction
    fram_buf #(.H_NUM(W),.V_NUM(H)) dut(
        .vin_clk(cclk),.wr_fsync(wr_vs),.wr_en(wr_de),.wr_data(pixel),.init_done(ready),
        .ddr_clk(dclk),.ddr_rstn(rst_n),.vout_clk(vclk),.rd_fsync(rd_vs),.rd_en(rd_de),
        .vout_de(out_de),.vout_data(out_pixel),.axi_awaddr(awaddr),.axi_awid(),.axi_awlen(awlen),
        .axi_awsize(),.axi_awburst(),.axi_awready(awready),.axi_awvalid(awvalid),
        .axi_wdata(wdata),.axi_wstrb(wstrb),.axi_wlast(wlast),.axi_wvalid(),.axi_wready(wready),.axi_bid(4'd0),
        .axi_araddr(araddr),.axi_arid(),.axi_arlen(arlen),.axi_arsize(),.axi_arburst(),
        .axi_arvalid(arvalid),.axi_arready(arready),.axi_rready(),.axi_rdata(rdata),
        .axi_rvalid(rvalid),.axi_rlast(rlast),.axi_rid(4'd0)
    );
    integer writes=0,reads=0,short_writes=0,short_reads=0;
    always @(posedge dclk) begin
        rvalid<=0; rlast<=0;
        if(awvalid && awready) begin
            wbusy<=1; wa<=awaddr; wremain<=awlen+1; wdly<=7;
            if(awlen==7) short_writes<=short_writes+1;
        end else if(wbusy) begin
            if(wdly!=0) wdly<=wdly-1;
            else begin
                if(idx(wa)>=4*WORDS || wa[19:0]>=W*H/2) $fatal(1,"write address %h",wa);
                mem[idx(wa)]<=wdata;
                if(wstrb!==32'hffffffff) $fatal(1,"write mask");
                writes<=writes+1; wa<=wa+8; wremain<=wremain-1;
                if(wremain==1) wbusy<=0;
            end
        end
        if(arvalid && arready) begin
            rbusy<=1; ra<=araddr; rremain<=arlen+1; rdly<=3;
            if(arlen==7) short_reads<=short_reads+1;
        end else if(rbusy) begin
            if(rdly!=0) rdly<=rdly-1;
            else begin
                if(idx(ra)>=4*WORDS || ra[19:0]>=W*H/2) $fatal(1,"read address %h",ra);
                rdata<=mem[idx(ra)]; rvalid<=1; rlast<=(rremain==1);
                reads<=reads+1; ra<=ra+8; rremain<=rremain-1;
                if(rremain==1) rbusy<=0;
            end
        end
    end
    integer frame,x,y;
    reg capture_done=0;
    initial begin
        repeat(10) @(negedge cclk); rst_n=1;
        repeat(20) @(negedge cclk);
        for(frame=1;frame<=5;frame=frame+1) begin
            wr_vs=1; repeat(12) @(negedge cclk); wr_vs=0;
            repeat(180) @(negedge cclk);
            for(y=0;y<H;y=y+1) begin
                for(x=0;x<W;x=x+1) begin
                    wr_de=1; pixel=frame*1000+y*W+x;
                    @(negedge cclk);
                end
                wr_de=0; repeat(580) @(negedge cclk);
            end
            repeat(330) @(negedge cclk);
        end
        capture_done=1;
    end
    integer display_frame,dx,dy,checked=0,pos=0,frame_base=-1;
    reg check=0;
    always @(posedge vclk) begin
        #2;
        if(out_de && check) begin
            if(pos==0) frame_base=out_pixel;
            if(out_pixel !== ((frame_base+pos-2*(pos/W)*W)&16'hffff))
                $fatal(1,"pixel mismatch display=%0d pos=%0d got=%h expected=%h",display_frame,pos,out_pixel,(frame_base+pos-2*(pos/W)*W)&16'hffff);
            pos=pos+1;
            checked=checked+1;
        end
    end
    initial begin
        wait(rst_n);
        for(display_frame=0;display_frame<7;display_frame=display_frame+1) begin
            @(negedge vclk); rd_vs=1;
            repeat(10) @(negedge vclk);
            rd_vs=0;
            repeat(250) @(negedge vclk);
            check=ready; pos=0;
            for(dy=0;dy<H;dy=dy+1) begin
                rd_de=1; repeat(W) @(negedge vclk);
                rd_de=0; repeat(280) @(negedge vclk);
            end
            if(check && pos!=W*H) $fatal(1,"display pixel count %0d",pos);
            if(check) $display("PASS DDR display frame %0d: %0d vertically flipped pixels, source first pixel %0d",display_frame,pos,frame_base);
            check=0;
            repeat(100) @(negedge vclk);
        end
        if(writes!=5*WORDS) $fatal(1,"write beats %0d expected %0d",writes,5*WORDS);
        if(checked<2*W*H || short_writes==0 || short_reads==0) $fatal(1,"insufficient coverage");
        $display("PASS frame buffer: %0d writes, %0d reads, %0d checked pixels; 120-beat lines include final 8-beat bursts",writes,reads,checked);
        $finish;
    end
    initial begin #5000000; $fatal(1,"timeout"); end
endmodule
