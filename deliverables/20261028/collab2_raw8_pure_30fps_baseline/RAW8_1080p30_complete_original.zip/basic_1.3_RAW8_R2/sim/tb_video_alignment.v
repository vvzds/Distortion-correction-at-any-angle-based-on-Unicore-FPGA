`timescale 1ns/1ps
// Exercise the real sync generator and read buffer together, including the
// final output register used by the top level. DDR supplies coordinate pixels.
module tb_video_alignment;
    localparam W=1920,H=6;
    reg vclk=0; always #6.734007 vclk=~vclk;
    reg dclk=0; always #4 dclk=~dclk;
    reg rst_n=0;
    wire vs,hs,active,read_enable,buf_de,req;
    wire [15:0] buf_pixel,read_length;
    wire [27:0] read_address;
    reg [255:0] read_data=0;
    reg data_valid=0,read_done=0;
    sync_vg #(.V_TOTAL(10),.V_SYNC(1),.V_BP(2),.V_ACT(H),.V_FP(1)) timing(
        .clk(vclk),.rstn(rst_n),.vs_out(vs),.hs_out(hs),
        .de_out(active),.de_re(read_enable),.x_act(),.y_act());
    rd_buf #(.ADDR_WIDTH(28),.H_NUM(W),.V_NUM(H),.PIX_WIDTH(16),.LINE_ADDR_WIDTH(20)) reader(
        .ddr_clk(dclk),.ddr_rstn(rst_n),.vout_clk(vclk),.rd_fsync(vs),
        .frame_bank(2'd0),.frame_start(),.rd_en(read_enable),
        .vout_de(buf_de),.vout_data(buf_pixel),.init_done(1'b1),
        .ddr_rreq(req),.ddr_raddr(read_address),.ddr_rd_len(read_length),
        .ddr_rrdy(1'b1),.ddr_rdone(read_done),.ddr_rdata(read_data),.ddr_rdata_en(data_valid));
    reg busy=0;
    integer beat=0,delay_count=0,base=0,i;
    always @(posedge dclk) begin
        data_valid<=0;
        read_done<=0;
        if(req) begin
            if(busy) $fatal(1,"overlapping line requests");
            if(read_length!=120) $fatal(1,"incorrect DDR line length");
            busy<=1; beat<=0; delay_count<=8; base<=read_address*2;
        end else if(busy) begin
            if(delay_count!=0) delay_count<=delay_count-1;
            else begin
                for(i=0;i<16;i=i+1) read_data[i*16+:16]<=base+beat*16+i;
                data_valid<=1;
                beat<=beat+1;
                if(beat==119) begin busy<=0; read_done<=1; end
            end
        end
    end
    reg connector_de=0,connector_vs=0,expected_de=0;
    reg [15:0] connector_pixel=0;
    always @(posedge vclk) begin
        connector_de<=buf_de;
        connector_vs<=vs;
        connector_pixel<=buf_pixel;
        expected_de<=active;
    end
    integer pos=0,frames=0,checked=0,expected_pixel=0;
    reg last_vs=0,armed=0;
    always @(posedge vclk) begin
        #2;
        if(rst_n) begin
            if(connector_vs && !last_vs) begin
                if(armed) begin
                    if(pos!=W*H) $fatal(1,"wrong frame size %0d",pos);
                    frames=frames+1;
                    if(frames==2) begin
                        $display("PASS video alignment: %0d pixels; vertical flip and RGB/DE aligned to active area, first/last pixel correct",checked);
                        $finish;
                    end
                end
                armed=1; pos=0;
            end
            if(armed && connector_de!==expected_de) $fatal(1,"DE not aligned to HDMI active area");
            if(armed && connector_de) begin
                expected_pixel=(H-1-pos/W)*W+(pos%W);
                if(connector_pixel!==expected_pixel[15:0]) $fatal(1,"pixel %0d got %0d",pos,connector_pixel);
                pos=pos+1; checked=checked+1;
            end
            last_vs=connector_vs;
        end
    end
    initial begin repeat(10) @(negedge vclk); rst_n=1; end
    initial begin #1000000; $fatal(1,"alignment test timeout"); end
endmodule
