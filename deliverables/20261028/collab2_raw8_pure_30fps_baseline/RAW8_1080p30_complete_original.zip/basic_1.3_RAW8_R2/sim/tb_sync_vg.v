`timescale 1ns / 1ps
module tb_sync_vg;
    reg clk=0; always #5 clk=~clk;
    reg rst_n=0;
    wire vs,hs,de,request;
    wire [11:0] x,y;
    sync_vg dut(clk,rst_n,vs,hs,de,request,x,y);
    integer cycles=0,pixels=0,lines=0,line_pixels=0,hs_width=0;
    reg prev_de=0,prev_vs=0,prev_hs=0;
    integer frame=0;
    initial begin
        repeat(5) @(negedge clk);
        rst_n=1;
        // Align to the second rising VSYNC, then count two full frame periods.
        @(posedge vs);
        for(frame=0;frame<2;frame=frame+1) begin
            @(negedge vs); @(posedge vs);
            cycles=0; pixels=0; lines=0; line_pixels=0; hs_width=0;
            prev_de=0; prev_vs=1;
            begin: one_frame
                forever begin
                    @(negedge clk);
                    if(vs && !prev_vs) disable one_frame;
                    cycles=cycles+1;
                    if(hs) hs_width=hs_width+1;
                    if(de) begin pixels=pixels+1; line_pixels=line_pixels+1; end
                    if(prev_de && !de) begin
                        if(line_pixels!=1920) $fatal(1,"line length %0d",line_pixels);
                        lines=lines+1; line_pixels=0;
                    end
                    prev_de=de; prev_vs=vs;
                end
            end
            if(cycles!=2200*1125 || pixels!=1920*1080 || lines!=1080 || hs_width!=44*1125)
                $fatal(1,"timing cycles=%0d pixels=%0d lines=%0d hs=%0d",cycles,pixels,lines,hs_width);
            $display("PASS HDMI frame: 2200x1125 total, 1920x1080 active, 74.25MHz/2475000=30Hz");
        end
        $finish;
    end
    initial begin #200000000; $fatal(1,"timeout"); end
endmodule
