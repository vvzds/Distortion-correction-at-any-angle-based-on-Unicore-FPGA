"""Run with Python 3 and Icarus Verilog 11+ (paths supplied explicitly)."""
from pathlib import Path
import argparse
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--iverilog', default='iverilog')
parser.add_argument('--vvp', default='vvp')
parser.add_argument('--ivl-lib', default=None)
parser.add_argument('--test', action='append', help='Only run the named test(s)')
args = parser.parse_args()
root = Path(__file__).resolve().parent.parent
tests = {
    'tb_reg_config': (['reg_config', 'i2c_com'], []),
    'tb_frame_bank_ctrl': (['frame_bank_ctrl'], []),
    'tb_raw8': (['raw8_to_rgb565'], []),
    'tb_raw8_frame_end': (['raw8_to_rgb565'], []),
    'tb_fram_buf': (['fram_buf', 'wr_buf', 'rd_buf', 'frame_bank_ctrl',
                     'wr_cmd_trans', 'wr_rd_ctrl_top', 'wr_ctrl', 'rd_ctrl'], ['ram_models']),
    'tb_raw8_ddr': (['raw8_to_rgb565', 'fram_buf', 'wr_buf', 'rd_buf', 'frame_bank_ctrl',
                     'wr_cmd_trans', 'wr_rd_ctrl_top', 'wr_ctrl', 'rd_ctrl'], ['ram_models']),
    'tb_sync_vg': (['sync_vg'], []),
    'tb_video_alignment': (['sync_vg', 'rd_buf'], ['ram_models']),
}
for name, (rtl, models) in tests.items():
    if args.test and name not in args.test:
        continue
    with tempfile.TemporaryDirectory(prefix='fpga_rtl_test_') as temp:
        program = Path(temp) / (name + '.vvp')
        command = [args.iverilog]
        if args.ivl_lib:
            command += ['-B', args.ivl_lib]
        command += ['-g2012', '-s', name, '-o', str(program), str(root/'sim'/f'{name}.v')]
        command += [str(root/'source/rtl'/f'{item}.v') for item in rtl]
        command += [str(root/'sim'/f'{item}.v') for item in models]
        subprocess.run(command, check=True)
        print('RUN', name, flush=True)
        run_command = [args.vvp, str(program)]
        result = subprocess.run(run_command, capture_output=True, text=True)
        (root/'sim'/f'{name}.log').write_text(result.stdout + result.stderr, encoding='utf-8')
        print(result.stdout + result.stderr, flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
