`timescale 1ns / 1ps
module tb_raw8;
    parameter W = 1920;
    parameter H = 1080;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0, vs = 0, de = 0;
    reg [7:0] data = 0;
    wire [3:0] out_de;
    wire [15:0] rgb [0:3];
    genvar k;
    generate for (k=0;k<4;k=k+1) begin: phases
        raw8_to_rgb565 #(.WIDTH(W), .HEIGHT(H), .BAYER_PHASE(k)) dut (
            .pclk(clk), .rst_n(rst_n), .vs_in(vs), .de_in(de), .raw_in(data),
            .vs_out(), .de_out(out_de[k]), .rgb_out(rgb[k])
        );
    end endgenerate
    integer pixels = 0, rows = 0, row_pixels = 0;
    integer frame_number = 0;
    reg last_de = 0;
    reg checking = 0;
    // Constant per-channel Bayer image: B=24, G=104, R=224.
    // Swapping the configured Bayer phase deliberately swaps the expected RGB.
    always @(posedge clk) begin
        #2;
        if (checking) begin
            if (out_de !== {4{out_de[0]}}) $fatal(1,"phase DE mismatch");
            if (out_de[0]) begin
                pixels = pixels + 1;
                row_pixels = row_pixels + 1;
                if (rgb[0] !== {5'd28,6'd26,5'd3}) $fatal(1,"BGGR color %h",rgb[0]);
                if (rgb[3] !== {5'd3,6'd26,5'd28}) $fatal(1,"RGGB color %h",rgb[3]);
                if (rgb[1] !== {5'd13,6'd31,5'd13}) $fatal(1,"GBRG color %h",rgb[1]);
                if (rgb[2] !== {5'd13,6'd31,5'd13}) $fatal(1,"GRBG color %h",rgb[2]);
            end
            if (last_de && !out_de[0]) begin
                if (row_pixels != W) $fatal(1,"row %0d length %0d expected %0d",rows,row_pixels,W);
                rows = rows + 1;
                row_pixels = 0;
            end
            last_de = out_de[0];
        end
    end
    integer x,y;
    initial begin
        repeat(5) @(negedge clk);
        rst_n=1;
        // Ignore incomplete data before the first VSYNC.
        de=1; data=8'hff;
        repeat(7) @(negedge clk);
        de=0;
        repeat(3) @(negedge clk);
        if (out_de != 0) $fatal(1,"unarmed capture emitted data");
        for(frame_number=0;frame_number<2;frame_number=frame_number+1) begin
            vs=1;
            repeat(8) @(negedge clk);
            vs=0;
            pixels=0; rows=0; row_pixels=0; last_de=0; checking=1;
            repeat(8) @(negedge clk);
            for(y=0;y<H;y=y+1) begin
                for(x=0;x<W;x=x+1) begin
                    de=1;
                    case({y[0],x[0]})
                        2'b00:data=24;
                        2'b11:data=224;
                        default:data=104;
                    endcase
                    @(negedge clk);
                end
                de=0;
                repeat(24) @(negedge clk);
            end
            repeat(W+50) @(negedge clk);
            if(pixels!=W*H || rows!=H) $fatal(1,"frame pixels=%0d rows=%0d",pixels,rows);
            checking=0;
            $display("PASS RAW8 frame %0d: %0dx%0d, %0d pixels, four Bayer phases",frame_number,W,H,pixels);
        end
        rst_n=0;
        repeat(5) @(negedge clk);
        if(out_de!=0) $fatal(1,"reset emitted data");
        $finish;
    end
    initial begin #100000000; $fatal(1,"timeout"); end
endmodule
