`timescale 1ns/1ps
module tb_reg_config;
    reg clk=0; always #10 clk=~clk;
    reg rst_n=1,enable=0;
    wire scl,done,slow;
    wire [8:0] index;
    tri1 sda;
    reg ack_low=0;
    assign sda=ack_low ? 1'b0 : 1'bz;
    reg_config #(.I2C_HALF_PERIOD(2)) dut(clk,rst_n,enable,done,scl,sda,slow,index);
    reg active=0;
    integer bit_count=0,byte_count=0,transactions=0,starts=0;
    reg [7:0] shift=0;
    reg [31:0] command=0;
    reg [7:0] registers[0:65535];
    reg nack_first=1;
    integer first_writes=0;
    always @(negedge sda) if(scl && rst_n) begin
        active=1; bit_count=0; byte_count=0; shift=0; command=0;
        starts=starts+1;
        if(!enable) $fatal(1,"SCCB started before power-on delay finished");
    end
    always @(negedge scl) begin
        if(active && bit_count==8 && !(nack_first && transactions==0)) ack_low=1;
        else ack_low=0;
    end
    always @(posedge scl) if(active) begin
        if(bit_count<8) begin
            shift={shift[6:0],sda};
            bit_count=bit_count+1;
        end else begin
            command={command[23:0],shift};
            byte_count=byte_count+1;
            bit_count=0;
            if(byte_count==4) begin
                if(command[31:24]!==8'h78) $fatal(1,"sensor address %h",command);
                if(command[23:8]==16'hffff) $fatal(1,"wrote delay placeholder as register");
                if(command==32'h78310311) first_writes=first_writes+1;
                if(command[23:8]==16'h3008 && command[7:0]==8'h02 &&
                   (registers['h3036]!==8'h54 || registers['h4300]!==8'h00 || registers['h3824]!==8'h02))
                    $fatal(1,"stream enabled before final PLL/format setup");
                registers[command[23:8]]=command[7:0];
                transactions=transactions+1;
                active=0;
            end
        end
    end
    initial begin
        #1 rst_n=0;
        repeat(20) @(negedge clk);
        rst_n=1;
        repeat(20) @(negedge clk);
        if(starts!=0 || done) $fatal(1,"early configuration");
        enable=1;
        wait(done);
        if(first_writes!=3) $fatal(1,"first NACK retry / pad-clock selection count: %0d",first_writes);
        if(transactions!=263) $fatal(1,"wrong transaction count %0d",transactions);
        if({registers['h3808],registers['h3809]}!==16'd1920 ||
           {registers['h380a],registers['h380b]}!==16'd1080 ||
           {registers['h380c],registers['h380d]}!==16'd2500 ||
           {registers['h380e],registers['h380f]}!==16'd1120 ||
           registers['h4300]!==8'h00 || registers['h501f]!==8'h03 ||
           registers['h3034]!==8'h18 || registers['h3035]!==8'h11 ||
           registers['h3036]!==8'h54 || registers['h3037]!==8'h13 ||
           registers['h3108]!==8'h01 ||
           registers['h460c]!==8'h22 || registers['h3824]!==8'h02 ||
           {registers['h3a02],registers['h3a03]}!==16'd1116 ||
           {registers['h3a14],registers['h3a15]}!==16'd1116 ||
           {registers['h3a08],registers['h3a09]}!==16'd336 ||
           {registers['h3a0a],registers['h3a0b]}!==16'd280 || registers['h3a00][2]!==1'b0)
            $fatal(1,"incorrect final RAW8 mode registers");
        $display("PASS SCCB: 262 register writes + 1 NACK retry; RAW8 1920x1080, 84MHz target, HTS2500 VTS1120; night mode off");
        rst_n=0; enable=0;
        repeat(10) @(negedge clk);
        if(done || index!=0) $fatal(1,"reset did not restart configuration");
        $finish;
    end
    initial begin #5000000; $fatal(1,"configuration timeout index=%0d transactions=%0d",index,transactions); end
endmodule
