"""Package originals, offline evidence and review; exclude dependencies/temp trees."""
from pathlib import Path
import csv,hashlib,io,zipfile
ROOT=Path(__file__).resolve().parent
OUTPUT=ROOT.parents[1]/'Host_review.zip'
def sha(raw):return hashlib.sha256(raw).hexdigest().upper()
paths=[p for p in ROOT.iterdir() if p.is_file() and p.suffix in ('.py','.md','.json','.tsv','.log')]
for folder in ('incoming','synthetic'):
    paths.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
paths=sorted(set(paths));manifest=io.StringIO(newline='');w=csv.writer(manifest,delimiter='\t',lineterminator='\n');w.writerow(['path','bytes','sha256'])
with zipfile.ZipFile(OUTPUT,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in paths:
        data=p.read_bytes();name=p.relative_to(ROOT).as_posix();z.writestr(name,data);w.writerow([name,len(data),sha(data)])
    z.writestr('MANIFEST_SHA256.tsv',manifest.getvalue().encode('utf-8'))
with zipfile.ZipFile(OUTPUT) as z:
    assert z.testzip() is None
    rows=list(csv.DictReader(io.StringIO(z.read('MANIFEST_SHA256.tsv').decode()),delimiter='\t'))
    assert len(z.namelist())==len(rows)+1
    for row in rows:
        data=z.read(row['path']);assert len(data)==int(row['bytes']) and sha(data)==row['sha256'] and data==(ROOT/row['path']).read_bytes()
OUTPUT.with_suffix('.zip.sha256').write_text(sha(OUTPUT.read_bytes())+'  '+OUTPUT.name+'\n',encoding='ascii')
print('PASS files='+str(len(rows)+1)+' missing=0 mismatch=0 bytes='+str(OUTPUT.stat().st_size))
print(OUTPUT);print(sha(OUTPUT.read_bytes()))
