"""Offline synthetic tests of delivered tools; no camera, GUI, or UART hardware."""
from pathlib import Path
import contextlib, hashlib, importlib.util, io, json, math, os, runpy, sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent/'host_validation_deps'))
sys.stdout.reconfigure(encoding='utf-8');sys.stderr.reconfigure(encoding='utf-8')
import cv2
import numpy as np
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'incoming'
OUT=ROOT/'synthetic'
OUT.mkdir(exist_ok=True)
results=[]

def record(name, passed, detail):
    results.append({'test':name,'pass':bool(passed),'detail':detail})
    print(('PASS ' if passed else 'FAIL ')+name+': '+str(detail))

def load(name):
    spec=importlib.util.spec_from_file_location(name,SRC/'calibration_tools'/f'{name}.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def invoke(path, argv, work):
    old=os.getcwd();args=sys.argv[:];buf=io.StringIO();exc=None
    try:
        os.chdir(work);sys.argv=[str(path),*argv]
        with contextlib.redirect_stdout(buf),contextlib.redirect_stderr(buf):
            try:runpy.run_path(str(path),run_name='__main__')
            except Exception as e:exc=repr(e)
    finally:os.chdir(old);sys.argv=args
    return buf.getvalue(),exc

before={p.relative_to(SRC).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in SRC.rglob('*') if p.is_file()}
record('dependencies',True,{'cv2':cv2.__version__,'numpy':np.__version__,'serial':__import__('serial').VERSION})
# R01: supplied main() uses real OpenCV calibration/projectPoints on independent synthetic corner data.
# Only imread/chessboard detection are providers; this is not an image-detection or hardware test.
K=np.array([[1000.,0,960.],[0,980.,540.],[0,0,1.]])
d=np.array([-0.1,0.03,0.002,-0.001,0.])
obj=np.zeros((12*9,3),np.float32);obj[:,:2]=np.mgrid[0:12,0:9].T.reshape(-1,2)*0.025
views=[]
for i in range(20):
    rv=np.array([-.25+.025*i,.18*math.sin(i),-.1+.01*i])
    tv=np.array([-.18+.018*(i%5),-.13+.012*(i%4),.65+.018*i])
    corners=cv2.projectPoints(obj,rv,tv,K,d)[0].astype(np.float32)
    views.append(corners)
cal_dir=OUT/'calibration';cal_dir.mkdir(exist_ok=True)
for i in range(21):(cal_dir/f'{i:02d}.png').write_bytes(b'synthetic-placeholder-not-an-image')
orig_read=cv2.imread;orig_detect=cv2.findChessboardCornersSB
index={'value':0};sizes=[]
def fake_read(path,*a,**kw):
    index['value']=int(Path(path).stem)
    return np.zeros((720,1280,3),np.uint8) if index['value']==20 else np.zeros((1080,1920,3),np.uint8)
def fake_detect(gray,cb,*a,**kw):
    sizes.append(gray.shape)
    return (tuple(cb)==(12,9),views[min(index['value'],19)])
cv2.imread=fake_read;cv2.findChessboardCornersSB=fake_detect
try:
    text,exc=invoke(SRC/'calibration_tools/calibrate.py',['--dir',str(cal_dir)],cal_dir)
finally:cv2.imread=orig_read;cv2.findChessboardCornersSB=orig_detect
(ROOT/'calibrate_synthetic_console.log').write_text(text+str(exc),encoding='utf-8')
if exc is None and (cal_dir/'calib_result.json').exists():
    out=json.loads((cal_dir/'calib_result.json').read_text(encoding='utf-8'))
    record('R01_real_calibration_fix_k3',len(out['dist_full'])==5 and out['dist_full'][4]==0 and out['rms']<0.01,
           {'rms':out['rms'],'dist_full':out['dist_full'],'flags':out['calib_flags'],'synthetic':True})
    record('R02_per_image_size_filter',len(out['images'])==20 and '20.png' not in out['images'] and all(s==(1080,1920) for s in sizes),{'used':len(out['images']),'detect_shapes':sorted(set(sizes))})
    frame=bytes.fromhex(out['uart01_frame']);record('R03_main_valid_frame',len(frame)==37 and frame[:4]==bytes([0xaa,0x55,1,32]) and frame[-1]==sum(frame[4:-1])%256,len(frame))
else:record('R01_calibrate_main',False,exc)
# R03 domain guard and nonfinite values, delivered functions (not rewritten).
cal=load('calibrate');params=dict(fx=1000.,fy=980.,cx=960.,cy=540.,k1=-.1,k2=.03,p1=.002,p2=-.001)
for val in [65536.,float('nan'),float('inf')]:
    p=dict(params,fx=val);record('R03_reject_'+str(val),bool(cal.g02_violations(p)),str(val))
# Subpixel helper: dark->light and reversed polarity must have same edge position.
lin=load('linearity');g=np.zeros((100,100),np.uint8);g[:,50:]=255
pa=lin.subpix_edge_centroid(g,(50,50),(1,0));pb=lin.subpix_edge_centroid(255-g,(50,50),(1,0))
record('R05_polarity',pa is not None and pb is not None and np.allclose(pa,pb),{'bright':pa,'dark':pb})
# R05 CLI: long synthetic slanted edge through real Canny/Hough/PCA.
y,x=np.mgrid[:600,:800];im=np.where(x>350+.15*y,240,15).astype(np.uint8)
cv2.imencode('.png',im)[1].tofile(OUT/'line.png')
text,exc=invoke(SRC/'calibration_tools/linearity.py',['line.png','--minlen','300'],OUT)
(ROOT/'linearity_synthetic_console.log').write_text(text+str(exc),encoding='utf-8')
record('R05_cli_synthetic',exc is None and '全图最大直线度偏差' in text,{'exception':exc,'output':text[-250:]})
# R06 CLI with analytically generated Gaussian-blurred slanted step; avoid hardware.
y,x=np.mgrid[:256,:256]
for sigma in (1.,2.):
    image=np.array([[int(round(255*.5*(1+math.erf((xx-128-.12*yy)/(sigma*math.sqrt(2)))))) for xx in range(256)] for yy in range(256)],np.uint8)
    name=OUT/f'edge_sigma{sigma}.png';cv2.imencode('.png',image)[1].tofile(name)
    text,exc=invoke(SRC/'calibration_tools/mtf50.py',[name.name,'--roi','16','16','224','224'],OUT)
    (ROOT/f'mtf_sigma{sigma}_console.log').write_text(text+str(exc),encoding='utf-8')
    record('R06_cli_sigma'+str(sigma),exc is None and 'MTF50 =' in text,{'exception':exc,'output':text[-250:]})
# Flat ROI must be explicitly invalid, never accepted as a numeric measurement.
cv2.imencode('.png',np.full((256,256),128,np.uint8))[1].tofile(OUT/'flat.png')
text,exc=invoke(SRC/'calibration_tools/mtf50.py',['flat.png','--roi','16','16','224','224'],OUT)
record('R06_flat_roi',exc is None and 'MTF50 =' not in text,{'exception':exc,'output':text[-200:]})
after={p.relative_to(SRC).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in SRC.rglob('*') if p.is_file()}
record('originals_unchanged',before==after,len(before))
(ROOT/'cv_path_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print('SUMMARY',sum(r['pass'] for r in results),'/',len(results))
sys.exit(0 if all(r['pass'] for r in results) else 1)
