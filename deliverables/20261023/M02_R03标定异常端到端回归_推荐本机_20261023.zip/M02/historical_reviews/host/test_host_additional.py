"""Capture and UART mocked tests; MTF scratch diagnosis does not edit incoming."""
from pathlib import Path
import contextlib, hashlib, importlib.util, io, json, os, runpy, sys
ROOT=Path(__file__).resolve().parent;SRC=ROOT/'incoming';OUT=ROOT/'synthetic'
sys.path.insert(0,str(ROOT.parent/'host_validation_deps'))
sys.stdout.reconfigure(encoding='utf-8');sys.stderr.reconfigure(encoding='utf-8')
import cv2,numpy as np
results=[]
def rec(name,passed,detail):
    results.append({'test':name,'pass':bool(passed),'detail':detail});print(('PASS ' if passed else 'FAIL ')+name+': '+str(detail))
# 18 original manifest files are unchanged.
rows=[]
for line in (SRC/'UART_HOST_TOOL/SHA256SUMS.txt').read_text(encoding='utf-8-sig').splitlines():
    if not line.strip():continue
    expected,name=line.split(maxsplit=1);p=SRC/'UART_HOST_TOOL'/name.lstrip('*');rows.append(hashlib.sha256(p.read_bytes()).hexdigest().lower()==expected.lower())
rec('UART_manifest',len(rows)==18 and all(rows),len(rows))
scratch=ROOT/'uart_tmp';scratch.mkdir(exist_ok=True)
import tempfile;tempfile.tempdir=str(scratch)
orig_mkdir=os.mkdir
def sandbox_mkdir(path,mode=0o777,*,dir_fd=None):
    if mode==0o700 and Path(path).resolve().is_relative_to(scratch):mode=0o777
    return orig_mkdir(path,mode,dir_fd=dir_fd)
os.mkdir=sandbox_mkdir
old_path=sys.path[:];old_args=sys.argv[:];buf=io.StringIO()
try:
    sys.path.insert(0,str(SRC/'UART_HOST_TOOL'));sys.argv=['uart_tool.py','selftest']
    with contextlib.redirect_stdout(buf),contextlib.redirect_stderr(buf):
        try:runpy.run_path(str(SRC/'UART_HOST_TOOL/uart_tool.py'),run_name='__main__')
        except SystemExit as ex:code=ex.code
finally:os.mkdir=orig_mkdir;sys.path[:]=old_path;sys.argv=old_args
(ROOT/'uart_selftest_rerun.log').write_text(buf.getvalue(),encoding='utf-8')
rec('UART_U0_U5',code==0 and 'ALL TESTS PASSED' in buf.getvalue(),{'exit':code,'scratch_acl_compatibility':True})
spec=importlib.util.spec_from_file_location('tool',SRC/'UART_HOST_TOOL/uart_tool.py');tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)
for status in (0x00040312,0x00080012):
    text=tool.format_status(status,SRC/'UART_HOST_TOOL/status_map_uart.json')
    rec('status_'+hex(status),bool(text),text)
# Fake VideoCapture and GUI only. Actual delivered script and dimension branches run unchanged.
class Cap:
    def __init__(self,size):self.size=size;self.frame=0;self.released=False
    def set(self,*a):pass
    def isOpened(self):return True
    def get(self,p):return self.size[0] if p==cv2.CAP_PROP_FRAME_WIDTH else self.size[1]
    def read(self):
        self.frame+=1
        return True,np.zeros((720,1280,3),np.uint8) if self.frame==1 else np.zeros((1080,1920,3),np.uint8)
    def release(self):self.released=True
saved={n:getattr(cv2,n) for n in ('VideoCapture','imshow','waitKey','imwrite','destroyAllWindows')}
for label,size in [('bad_reported',(1280,720)),('actual_frames',(1920,1080))]:
    cap=Cap(size);written=[];keys=iter([32,32,ord('q')])
    cv2.VideoCapture=lambda *a:cap;cv2.imshow=lambda *a:None;cv2.destroyAllWindows=lambda:None
    cv2.waitKey=lambda *a:next(keys);cv2.imwrite=lambda p,img:written.append((p,img.shape)) or True
    buf=io.StringIO();error=None;args=sys.argv[:]
    try:
        sys.argv=['capture.py','--dir',str(OUT/'capture')]
        with contextlib.redirect_stdout(buf):
            try:runpy.run_path(str(SRC/'calibration_tools/capture.py'),run_name='__main__')
            except SystemExit as e:error=str(e)
    finally:sys.argv=args
    rec('R02_capture_'+label,(not written and error is not None) if label=='bad_reported' else (error is None and len(written)==1 and written[0][1]==(1080,1920,3)),{'exit':error,'saved_shapes':[s for _,s in written],'output':buf.getvalue()})
for n,f in saved.items():setattr(cv2,n,f)
# Diagnose first MTF failure in a separate scratch copy, leaving incoming byte-exact.
s=(SRC/'calibration_tools/mtf50.py').read_text(encoding='utf-8').replace('cv2.CV_32F','cv2.CV_64F')
diag=ROOT/'mtf50_dtype_diagnostic.py';diag.write_text(s,encoding='utf-8')
for img in ('edge_sigma1.0.png','edge_sigma2.0.png','flat.png'):
    buf=io.StringIO();error=None;args=sys.argv[:];wd=os.getcwd()
    try:
        os.chdir(OUT);sys.argv=[str(diag),img,'--roi','16','16','224','224']
        with contextlib.redirect_stdout(buf),contextlib.redirect_stderr(buf):
            try:runpy.run_path(str(diag),run_name='__main__')
            except Exception as e:error=repr(e)
    finally:sys.argv=args;os.chdir(wd)
    rec('R06_scratch_dtype_'+img,error is None and 'MTF50 =' in buf.getvalue(),{'exception':error,'output':buf.getvalue(),'diagnostic_only':True})
(ROOT/'additional_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')

sys.exit(0 if all(r['pass'] for r in results) else 1)
