"""Self-check real report parsing and fail-closed acceptance gates; no FPGA claims."""
import copy
import importlib.util
import json
from pathlib import Path
import shutil
import unittest
import uuid
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('review', ROOT / 'pds_review.py')
R = importlib.util.module_from_spec(spec)
spec.loader.exec_module(R)
DEFAULT = ROOT / 'incoming/impl_results_default'


class TestReports(unittest.TestCase):
    def test_actual_default_both_views(self):
        post = R.parse_csv(DEFAULT / 'multiseed_summary.csv')
        final = R.parse_final(DEFAULT / 'hdmi_ddr_ov5640_top_timing_summary_after_hold_fix.txt')
        self.assertEqual((post['Setup(Slow)'], post['tns'], post['ep']), (-.574, -4.726, 25))
        slow = final['sections']['Setup(Slow)']
        self.assertEqual((slow['wns'], slow['tns'], slow['ep']), (-.548, -4.095, 25))
        self.assertEqual(len(slow['domains']), 15)
        self.assertGreaterEqual(final['sections']['Hold(Fast)']['wns'], 0)

    def make_seed(self, parent, seed, wns=.2, final_wns=None, hold=.1, binding=True):
        target = parent / ('seed_' + str(seed))
        target.mkdir()
        (target / 'source').mkdir()
        (target / 'ipcore').mkdir()
        (target / 'source/core.v').write_text('// synthetic unit-test input, not RTL evidence')
        (target / R.FDC).write_text(R.ATTRIBUTE)
        (target / 'build.tcl').write_text('# unit-test fixture')
        (target / 'run_trial.tcl').write_text('pnr -gplace_seed %d -groute_seed %d\n' % (seed, seed))
        (target / 'console_full.log').write_text('G6_PHASE=FINISHED\n')
        (target / 'rtr.db').write_text('<synthetic-test-only/>')
        (target / 'fixture.sbit').write_bytes(b'SYNTHETIC - NOT A BITSTREAM')
        text = R.read(DEFAULT / 'multiseed_summary.csv')
        text = text.replace('single,OK,Fail,-0.574,1.712,0.107,0.099,',
                            'single,OK,%s,%s,1.712,%s,0.099,' % ('OK' if wns >= 0 else 'Fail', wns, hold))
        text = text.replace(',-4.726,25,0.000,0,NA', ',%s,%s,0.000,0,NA' % (min(0, wns), 0 if wns >= 0 else 1))
        (target / 'multiseed_summary.csv').write_text(text)
        fw = wns if final_wns is None else final_wns
        lines = ['Design Summary : ' + ('No Constraints Violated.' if fw >= 0 and hold >= 0 else 'Some Constraints Violated.')]
        for kind, corner in (('Setup', 'Slow'), ('Hold', 'Slow'), ('Setup', 'Fast'), ('Hold', 'Fast')):
            value = fw if (kind, corner) == ('Setup', 'Slow') else hold if kind == 'Hold' else .4
            lines.extend(['%s Summary(%s Corner):' % (kind, corner),
                          'ddrphy_sysclk ddrphy_sysclk %s %s %d 100' % (value, min(0, value), value < 0)])
        (target / 'fixture_timing_summary_after_hold_fix.txt').write_text('\n'.join(lines))
        if binding:
            (target / 'binding_mapped.fdc').write_text('\n'.join(
                'define_attribute {i:u_corr_top.u_core.u_map.%s_a1_32.gateop} {PAP_GROUP} {%s}' % (p, R.GROUP)
                for p in ('N78', 'N82')))
        self.receipt(target, seed)
        return target

    def receipt(self, target, seed):
        inp = R.inputs(target)
        R.dump(target / 'trial_inputs_sha256.json', inp)
        artifacts = {p.relative_to(target).as_posix(): R.sha(p) for p in target.iterdir()
                     if p.is_file() and p.suffix in ('.csv', '.txt', '.db', '.sbit', '.log', '.fdc')}
        R.dump(target / 'process_receipt.json', dict(seed=seed, placement_seed=seed, route_seed=seed,
             exit_code=0, error=None, inputs_unchanged=True, inputs_before=inp, inputs_after=inp,
             artifacts_sha256=artifacts))

    def run_case(self, modifications=None, n=8):
        # Ordinary mkdir inherits the workspace ACL; tempfile's private mode is
        # incompatible with this managed Windows sandbox. Keep synthetic fixtures.
        root = ROOT / 'synthetic_gate_fixtures' / uuid.uuid4().hex
        root.mkdir(parents=True)
        R.dump(root / 'run_plan.json', dict(seeds=list(range(n))))
        for seed in range(n):
            self.make_seed(root, seed)
        if modifications:
            modifications(root)
        return R.assess(root)

    def test_eight_complete_passes_only_physical_gate(self):
        result = self.run_case()
        self.assertTrue(result['physical_trial_pass'])
        self.assertIn('UNRESOLVED', result['S3_status'])
        self.assertIn('PENDING', result['S4_status'])
        self.assertIn('NOT DECLARED', result['overall_G6_acceptance'])

    def test_seven_of_eight_mild_failure_allowed(self):
        def mod(root):
            shutil.rmtree(root / 'seed_7')
            self.make_seed(root, 7, wns=-.05)
        r = self.run_case(mod)
        self.assertEqual(r['closed'], 7)
        self.assertTrue(r['physical_trial_pass'])

    def test_two_failures_rejected(self):
        def mod(root):
            for s in (6, 7):
                shutil.rmtree(root / ('seed_' + str(s)))
                self.make_seed(root, s, wns=-.05)
        self.assertFalse(self.run_case(mod)['S1_pass'])

    def test_floor_rejected_even_seven_close(self):
        def mod(root):
            shutil.rmtree(root / 'seed_7')
            self.make_seed(root, 7, wns=-.101)
        self.assertFalse(self.run_case(mod)['S1_pass'])

    def test_missing_sbit_invalidates_seed(self):
        r = self.run_case(lambda root: (root / 'seed_7/fixture.sbit').unlink())
        self.assertEqual(r['valid'], 7)
        self.assertFalse(r['S5_seed_evidence_complete'])
        self.assertFalse(r['physical_trial_pass'])

    def test_bad_seed_not_hidden_when_eight_valid_remain(self):
        r = self.run_case(lambda root: (root / 'seed_8/fixture.sbit').unlink(), n=9)
        self.assertTrue(r['S1_pass'])
        self.assertFalse(r['physical_trial_pass'])

    def test_artifact_tamper_rejected(self):
        def mod(root):
            with (root / 'seed_7/multiseed_summary.csv').open('a') as f:
                f.write('\nchanged')
        r = self.run_case(mod)
        self.assertEqual(r['valid'], 7)
        self.assertFalse(r['physical_trial_pass'])

    def test_input_tamper_rejected(self):
        r = self.run_case(lambda root: (root / 'seed_0/source/core.v').write_text('changed'))
        self.assertEqual(r['valid'], 7)

    def test_hold_failure_rejected(self):
        def mod(root):
            shutil.rmtree(root / 'seed_7')
            self.make_seed(root, 7, hold=-.001)
        self.assertFalse(self.run_case(mod)['S2_pass'])

    def test_post_final_disagreement_rejected(self):
        def mod(root):
            shutil.rmtree(root / 'seed_7')
            self.make_seed(root, 7, wns=.2, final_wns=-.01)
        self.assertFalse(self.run_case(mod)['S2_pass'])

    def test_missing_leaf_binding_pending(self):
        def mod(root):
            shutil.rmtree(root / 'seed_7')
            self.make_seed(root, 7, binding=False)
        r = self.run_case(mod)
        self.assertTrue(r['S1_pass'])
        self.assertFalse(r['binding_confirmed'])
        self.assertFalse(r['physical_trial_pass'])

    def test_module_attribute_is_not_binding_proof(self):
        def mod(root):
            (root / 'seed_7/binding_mapped.fdc').write_text(R.ATTRIBUTE)
            self.receipt(root / 'seed_7', 7)
        self.assertFalse(self.run_case(mod)['binding_confirmed'])

    def test_nonzero_exit_invalidates(self):
        def mod(root):
            p = root / 'seed_7/process_receipt.json'
            obj = json.loads(p.read_text())
            obj['exit_code'] = 1
            R.dump(p, obj)
        self.assertEqual(self.run_case(mod)['valid'], 7)

    def test_fewer_than_eight_rejected(self):
        self.assertFalse(self.run_case(n=7)['S1_pass'])

    def test_different_sources_across_seeds_rejected(self):
        def mod(root):
            (root / 'seed_7/source/core.v').write_text('different, re-receipted source')
            self.receipt(root / 'seed_7', 7)
        r = self.run_case(mod)
        self.assertEqual(r['valid'], 8)
        self.assertFalse(r['comparable_inputs'])
        self.assertFalse(r['physical_trial_pass'])

    def test_echoed_completion_is_not_execution(self):
        def mod(root):
            (root / 'seed_7/console_full.log').write_text('Executing: puts "G6_PHASE=FINISHED"\n')
            self.receipt(root / 'seed_7', 7)
        self.assertEqual(self.run_case(mod)['valid'], 7)

    def test_prepare_eight_distinct_flows_without_pds(self):
        root = ROOT / 'synthetic_gate_fixtures' / uuid.uuid4().hex
        source = root / 'package/candidate_host'
        (source / 'source').mkdir(parents=True)
        (source / 'ipcore').mkdir()
        (source / 'source/core.v').write_text('// synthetic input')
        (source / R.FDC).write_text('# baseline\n' + R.ATTRIBUTE)
        (source / 'build.tcl').write_text('cd [file dirname [info script]]\ncompile\nsynthesize\ndev_map\npnr\nreport_timing\ngen_bit_stream\n')
        package = source.parent
        R.dump(package / 'MANIFEST_SHA256.json', {p.relative_to(package).as_posix(): R.sha(p)
               for p in source.rglob('*') if p.is_file()})
        original_need = R.need
        def local_fixture_need(ok, message):
            # Only the ASCII path policy is bypassed for this local synthetic fixture.
            # The production CLI retains the policy, and no PDS process is invoked.
            if message != 'Use a new ASCII output path for PDS':
                original_need(ok, message)
        with patch.object(R, 'need', side_effect=local_fixture_need):
            R.prepare(package, root / 'out', [2, 3, 5, 7, 8, 9, 10, 11])
        for seed in (2, 3, 5, 7, 8, 9, 10, 11):
            target = root / 'out' / ('seed_' + str(seed))
            flow = R.read(target / 'run_trial.tcl')
            self.assertEqual(flow.count('\npnr '), 1)
            self.assertIn('pnr -gplace_seed %d -groute_seed %d\n' % (seed, seed), flow)
            self.assertIn('g6_optional_export export_fdc', flow)
            self.assertEqual((target / 'source/core.v').read_bytes(), (source / 'source/core.v').read_bytes())
            self.assertEqual(R.inputs(target), json.loads((target / 'trial_inputs_sha256.json').read_text()))


if __name__ == '__main__':
    unittest.main(verbosity=2)
