"""Synthetic fault injection. Fixtures are NOT FPGA or PDS execution evidence."""
import json
from pathlib import Path
import subprocess
import sys
import unittest
import uuid
from startup_console_gate import classify, MESSAGES, POLICY
from test_pds_review import TestReports, R

ROOT = Path(__file__).resolve().parent
SHELL = 'D:/pango/PDS_2022.2-SP6.4/bin/pds_shell.exe'


def log(seed=2):
    return '\n'.join([
        'License checkout: fabric_shell from D:/pango/PDS_2022.2-SP6.4/license/synthetic.lic',
        'Compiling architecture definition.', *MESSAGES,
        f"Analyzing project file 'D:/synthetic/seed_{seed}/run_trial.pds'.",
        'Executing : set_arch -family Logos2 -device PG2L100H -speedgrade -6 -package FBG676',
        'Executing : compile -top_module hdmi_ddr_ov5640_top successfully.',
        'Executing : synthesize -ads -selected_syn_tool_opt 2 successfully.',
        'Executing : dev_map successfully.', 'G6_PHASE=DEV_MAP_DONE',
        f'Executing : pnr -gplace_seed {seed} -groute_seed {seed} successfully.',
        'G6_PHASE=PNR_DONE', 'Executing : report_timing successfully.',
        'Executing : gen_bit_stream successfully.', 'G6_PHASE=FINISHED', ''])


class TestConsole(unittest.TestCase):
    def test_recognized_startup_pair(self):
        r=classify(log(),2,{'pds_shell':SHELL},POLICY)
        self.assertTrue(r['accepted'])
        self.assertEqual([x['line'] for x in r['accepted_diagnostics']],[3,4])

    def test_strict_default_rejects_pair(self):
        self.assertFalse(classify(log(),2,{'pds_shell':SHELL})['accepted'])

    def test_clean_log_preserves_existing_rule(self):
        self.assertTrue(classify('G6_PHASE=FINISHED\n',2,{},POLICY)['accepted'])

    def test_unknown_policy_rejected(self):
        self.assertFalse(classify('',2,{},'unknown')['accepted'])

    def test_unrecognized_tool_version(self):
        self.assertFalse(classify(log(),2,{'pds_shell':SHELL.replace('SP6.4','SP6.1')},POLICY)['accepted'])


mutations = {
    'unknown_E':lambda s:s.replace('G6_PHASE=PNR_DONE','E: PNR failed\nG6_PHASE=PNR_DONE'),
    'ERROR':lambda s:s.replace('G6_PHASE=PNR_DONE','ERROR: failed\nG6_PHASE=PNR_DONE'),
    'modelsim_error':lambda s:s.replace('G6_PHASE=PNR_DONE','** Error: failed\nG6_PHASE=PNR_DONE'),
    'modelsim_fatal':lambda s:s.replace('G6_PHASE=PNR_DONE','** Fatal: failed\nG6_PHASE=PNR_DONE'),
    'case_whitespace_error':lambda s:s.replace('G6_PHASE=PNR_DONE','  error: failed\nG6_PHASE=PNR_DONE'),
    'changed_message':lambda s:s.replace('compile db.','compile db. details'),
    'indented_allowlist':lambda s:s.replace(MESSAGES[0],' '+MESSAGES[0]),
    'lowercase_allowlist':lambda s:s.replace(MESSAGES[0],MESSAGES[0].lower()),
    'single_error':lambda s:s.replace(MESSAGES[1]+'\n',''),
    'duplicate_error':lambda s:s.replace(MESSAGES[0],MESSAGES[0]+'\n'+MESSAGES[0]),
    'reverse_errors':lambda s:s.replace('\n'.join(MESSAGES),'\n'.join(reversed(MESSAGES))),
    'extra_prefix':lambda s:'Executing : compile\n'+s,
    'post_startup_errors':lambda s:s.replace('\n'.join(MESSAGES)+'\n','').replace('G6_PHASE=PNR_DONE','\n'.join(MESSAGES)+'\nG6_PHASE=PNR_DONE'),
    'pair_after_finish':lambda s:s+'\n'.join(MESSAGES)+'\n',
    'version':lambda s:s.replace('SP6.4','SP6.1'),
    'project_seed':lambda s:s.replace('/seed_2/','/seed_3/'),
    'wrong_arch':lambda s:s.replace('PG2L100H','PG2L200H'),
    'pnr_seed':lambda s:s.replace('-groute_seed 2','-groute_seed 3'),
    'reorder_stages':lambda s:s.replace('G6_PHASE=PNR_DONE\nExecuting : report_timing successfully.','Executing : report_timing successfully.\nG6_PHASE=PNR_DONE'),
    'unknown_phase':lambda s:s.replace('G6_PHASE=PNR_DONE','G6_PHASE=UNKNOWN\nG6_PHASE=PNR_DONE'),
    'truncated':lambda s:s[:s.index('Executing : gen_bit_stream')],
    'echo_finish':lambda s:s.replace('G6_PHASE=FINISHED','Executing : puts "G6_PHASE=FINISHED"'),
    'trailing_output':lambda s:s+'unrecognized trailing activity\n',
}
for token in [s for s in log().splitlines() if s.endswith('successfully.') or s.startswith('G6_PHASE=')]:
    key=token.replace(' ','_').replace(':','').replace('=','_').replace('.','')
    mutations['missing_'+key]=lambda s,t=token:s.replace(t+'\n','')
    mutations['duplicate_'+key]=lambda s,t=token:s.replace(t,t+'\n'+t)

for name, mutation in mutations.items():
    def test(self, mutation=mutation):
        self.assertFalse(classify(mutation(log()),2,{'pds_shell':SHELL},POLICY)['accepted'])
    setattr(TestConsole,'test_reject_'+name,test)


class TestIntegrated(unittest.TestCase):
    def setUp(self):
        self.helper=TestReports()
        self.root=ROOT/'synthetic_gate_fixtures'/uuid.uuid4().hex
        self.root.mkdir(parents=True)
        R.dump(self.root/'run_plan.json',{'seeds':[2]})
        self.target=self.helper.make_seed(self.root,2)
        (self.target/'console_full.log').write_text(log(),encoding='utf-8')
        self.receipt()

    def receipt(self):
        self.helper.receipt(self.target,2)
        p=self.target/'process_receipt.json'
        obj=json.loads(p.read_text());obj['pds_shell']=SHELL;R.dump(p,obj)

    def assess(self):return R.assess(self.root,POLICY)

    def test_adaptation_does_not_waive_eight_seed_rule(self):
        result=self.assess()
        self.assertEqual(result['valid'],1)
        self.assertFalse(result['S1_pass'])
        self.assertFalse(result['physical_trial_pass'])

    def test_default_strict_preserved(self):
        self.assertEqual(R.assess(self.root)['valid'],0)

    def test_missing_binding_not_waived(self):
        (self.target/'binding_mapped.fdc').unlink();self.receipt()
        result=self.assess()
        self.assertEqual(result['valid'],1)
        self.assertFalse(result['binding_confirmed'])

    def test_cli_preserves_input_output(self):
        existing=self.root/'old.json';existing.write_text('keep')
        for output in [existing,self.target/'new.json']:
            p=subprocess.run([sys.executable,'-B',str(ROOT/'pds_review.py'),'collect',
                '--run',str(self.root),'--console-policy',POLICY,'--output',str(output)],capture_output=True)
            self.assertNotEqual(p.returncode,0)
        self.assertEqual(existing.read_text(),'keep')
        self.assertFalse((self.target/'new.json').exists())


def change_receipt(case,key,value):
    p=case.target/'process_receipt.json';o=json.loads(p.read_text());o[key]=value;R.dump(p,o)

def drop_hash(case,name):
    p=case.target/'process_receipt.json';o=json.loads(p.read_text());del o['artifacts_sha256'][name];R.dump(p,o)

faults={
    'nonzero_exit':lambda c:change_receipt(c,'exit_code',1),
    'process_error':lambda c:change_receipt(c,'error','timeout'),
    'receipt_seed':lambda c:change_receipt(c,'route_seed',7),
    'input_drift_flag':lambda c:change_receipt(c,'inputs_unchanged',False),
    'input_tamper':lambda c:(c.target/'source/core.v').write_text('changed'),
    'console_tamper':lambda c:(c.target/'console_full.log').write_text(log()+'tamper'),
    'missing_sbit':lambda c:(c.target/'fixture.sbit').unlink(),
    'missing_rtr':lambda c:(c.target/'rtr.db').unlink(),
    'missing_receipt':lambda c:(c.target/'process_receipt.json').unlink(),
    'unreceipted_sbit':lambda c:drop_hash(c,'fixture.sbit'),
    'unreceipted_console':lambda c:drop_hash(c,'console_full.log'),
}
for name,mutation in faults.items():
    def test(self,mutation=mutation):
        mutation(self)
        self.assertEqual(self.assess()['valid'],0)
    setattr(TestIntegrated,'test_reject_'+name,test)

def replace_and_receipt(c,name,text):
    (c.target/name).write_text(text);c.receipt()

for name,file,text in [
    ('invalid_xml','rtr.db','not XML'),
    ('bad_csv','multiseed_summary.csv','not a PDS report'),
    ('incomplete_final','fixture_timing_summary_after_hold_fix.txt','Design Summary : no quadrants'),
    ('late_error','console_full.log',log().replace('G6_PHASE=PNR_DONE','E: PNR failed\nG6_PHASE=PNR_DONE')),
    ('empty_bitstream','fixture.sbit',''),
]:
    def test(self,file=file,text=text):
        replace_and_receipt(self,file,text)
        self.assertEqual(self.assess()['valid'],0)
    setattr(TestIntegrated,'test_rereceipted_'+name,test)

if __name__=='__main__':
    suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c)
                             for c in (TestReports,TestConsole,TestIntegrated))
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(not result.wasSuccessful())
