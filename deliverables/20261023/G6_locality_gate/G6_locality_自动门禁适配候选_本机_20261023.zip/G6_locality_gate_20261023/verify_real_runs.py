"""Read-only replay of preserved locality evidence; never invokes PDS."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
W=Path(__file__).resolve().parent
RUN=Path('D:/g6_locality_runs_20261022')
E=W/'replay_results'
E.mkdir()  # Fresh output only; never overwrite bundled historical evidence.
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
anchors={str(p):sha(p) for p in [RUN/'review_results.json',RUN/'run_plan.json',Path('D:/g6_locality_pkg/tools/pds_review.py'),Path('D:/g6_locality_pkg/MANIFEST_SHA256.json')]}
for p in RUN.glob('seed_*/process_receipt.json'):anchors[str(p)]=sha(p)
spec=importlib.util.spec_from_file_location('original_review',W/'original/pds_review.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
base=old.assess(RUN)
(E/'original_strict.json').write_text(json.dumps(base,ensure_ascii=False,indent=2),encoding='utf-8')
if base['valid']!=0:raise RuntimeError('Unexpected original result')
for policy in ['strict','startup-db-v1']:
    out=E/(policy+'.json')
    p=subprocess.run([sys.executable,'-B',str(W/'pds_review.py'),'collect','--run',str(RUN),
                      '--console-policy',policy,'--output',str(out)],capture_output=True,encoding='utf-8')
    (E/(policy+'_cli.log')).write_text(p.stdout+p.stderr,encoding='utf-8')
    if p.returncode!=2:raise RuntimeError(f'{policy}: expected physical gate rejection exit 2, got {p.returncode}')
strict=json.loads((E/'strict.json').read_text(encoding='utf-8'))
adapt=json.loads((E/'startup-db-v1.json').read_text(encoding='utf-8'))
if strict['valid']!=0:raise RuntimeError('Strict default changed')
expected={'valid':8,'closed':2,'closure_ratio':.25,'S1_pass':False,'S2_pass':True,
          'binding_confirmed':False,'physical_trial_pass':False,'comparable_inputs':True,'S5_seed_evidence_complete':True}
for k,v in expected.items():
    if adapt[k]!=v:raise RuntimeError(f'{k}: {adapt[k]} != {v}')
if any(len(r['console_gate']['accepted_diagnostics'])!=2 for r in adapt['seeds']):raise RuntimeError('Diagnostic audit missing')
# The interrupted run has no receipt/terminal evidence and must remain rejected.
import pds_review as candidate
from startup_console_gate import classify,POLICY
interrupted=RUN/'_interrupted_seed_3_20261022'
g=classify(candidate.read(interrupted/'console_full.log'),3,{'pds_shell':'D:/pango/PDS_2022.2-SP6.4/bin/pds_shell.exe'},POLICY)
if g['accepted'] or (interrupted/'process_receipt.json').exists():raise RuntimeError('Interrupted-run negative control failed')
for p,h in anchors.items():
    if sha(Path(p))!=h:raise RuntimeError('Original modified: '+p)
summary={'scope':'Offline evidence review only; no PDS run or source replacement','original_valid':base['valid'],
         'candidate_strict_valid':strict['valid'],'adapted':expected,'cli_exit_codes':{'strict':2,POLICY:2},
         'interrupted_run_gate':g,'preserved_original_sha256':anchors}
(E/'verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
