"""Narrow, opt-in PDS SP6.4 startup diagnostic classification.

Caller must first verify process receipt, all input/artifact hashes and parse
required timing/bitstream evidence. This function alone is NOT seed acceptance.
"""
import re

POLICY = 'startup-db-v1'
ERROR_RE = re.compile(r'^\s*(?:E:|ERROR:|\*\* (?:Error|Fatal):)', re.I)
MESSAGES = ('E: Please rerun to generate compile db.',
            'E: Flow-0011: PNR or PLC design DB file is not found.')


def classify(console, seed, receipt, policy='strict'):
    lines = console.splitlines()
    errors = [{'line': i + 1, 'text': s} for i, s in enumerate(lines) if ERROR_RE.match(s)]
    result = dict(policy=policy, accepted=False, classification='REJECTED',
                  error_lines=errors, accepted_diagnostics=[], reason=None)

    def reject(reason):
        result['reason'] = reason
        return result

    if policy not in ('strict', POLICY):
        return reject('Unknown console policy')
    if not errors:
        result.update(accepted=True, classification='NO_ERROR_LINES')
        return result
    if policy == 'strict':
        return reject('PDS error in console')
    if [e['text'] for e in errors] != list(MESSAGES):
        return reject('Unexpected, repeated, altered or additional error lines')
    # Exact startup prefix: no commands or arbitrary lines may precede the pair.
    if len(lines) < 6 or not re.fullmatch(
            r'License checkout: fabric_shell from .+[\\/]PDS_2022\.2-SP6\.4[\\/]license[\\/][^\\/]+\.lic', lines[0]):
        return reject('Unrecognized SP6.4 startup/license prefix')
    if lines[1:4] != ['Compiling architecture definition.', *MESSAGES]:
        return reject('Diagnostics are outside the recognized startup prefix')
    if not re.fullmatch(r"Analyzing project file '[^'\r\n]+/seed_" + str(seed) + r"/run_trial\.pds'\.", lines[4]):
        return reject('Startup project/seed mismatch')
    if lines[5] != 'Executing : set_arch -family Logos2 -device PG2L100H -speedgrade -6 -package FBG676':
        return reject('Unexpected first command after startup')
    shell = str(receipt.get('pds_shell', '')).replace('\\', '/')
    if not shell.endswith('/PDS_2022.2-SP6.4/bin/pds_shell.exe'):
        return reject('Receipt does not identify the supported SP6.4 executable')
    # Exactly once, in order. Completion markers alone cannot establish success.
    stages = [
        'Executing : compile -top_module hdmi_ddr_ov5640_top successfully.',
        'Executing : synthesize -ads -selected_syn_tool_opt 2 successfully.',
        'Executing : dev_map successfully.',
        'G6_PHASE=DEV_MAP_DONE',
        f'Executing : pnr -gplace_seed {seed} -groute_seed {seed} successfully.',
        'G6_PHASE=PNR_DONE',
        'Executing : report_timing successfully.',
        'Executing : gen_bit_stream successfully.',
        'G6_PHASE=FINISHED',
    ]
    positions = []
    for stage in stages:
        found = [i for i, s in enumerate(lines) if s == stage]
        if len(found) != 1:
            return reject('Missing or repeated success evidence: ' + stage)
        positions.append(found[0])
    if positions != sorted(positions) or positions[0] <= 5:
        return reject('Success evidence is out of order')
    phases = [s for s in lines if s.startswith('G6_PHASE=')]
    if phases != ['G6_PHASE=DEV_MAP_DONE', 'G6_PHASE=PNR_DONE', 'G6_PHASE=FINISHED']:
        return reject('Unexpected phase sequence')
    if any(s.strip() for s in lines[positions[-1] + 1:]):
        return reject('Unexpected output after FINISHED')
    result.update(accepted=True, classification='RECOVERED_STARTUP_DB_DIAGNOSTICS',
                  accepted_diagnostics=errors,
                  reason='Exact SP6.4 pre-project DB diagnostics followed by ordered successful build stages')
    return result
