from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
for name,digest in manifest.items():
    p=(root/name).resolve()
    if not p.is_relative_to(root) or not p.is_file():raise SystemExit('Missing/unsafe: '+name)
    if hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise SystemExit('Hash mismatch: '+name)
print(f'PASS: {len(manifest)} manifest-listed files verified')
