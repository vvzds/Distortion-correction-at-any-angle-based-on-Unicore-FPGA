"""G6 constraint-trial preparation and evidence review. Python standard library only.

This tool never downloads software, programs hardware or declares S3/S4 complete.
"""
from pathlib import Path
import argparse
import csv
import datetime as dt
import hashlib
import io
import json
import math
import re
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET

from startup_console_gate import classify

GROUP = 'g6_map_locality'
ATTRIBUTE = 'define_attribute {i:u_corr_top.u_core.u_map} {PAP_GROUP} {' + GROUP + '}\n'
FDC = 'HDMI_DDR3_OV5640_test.fdc'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
    return h.hexdigest().upper()


def dump(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def read(path):
    data = Path(path).read_bytes()
    for enc in ('utf-8-sig', 'gb18030'):
        try:
            return data.decode(enc).replace('\r\n', '\n')
        except UnicodeDecodeError:
            pass
    raise ValueError('Cannot decode ' + str(path))


def need(ok, message):
    if not ok:
        raise ValueError(message)


def number(value):
    result = float(value)
    need(math.isfinite(result), 'Non-finite timing value')
    return result


def inputs(root):
    files = [p for part in ('source', 'ipcore') for p in (root / part).rglob('*') if p.is_file()]
    files += [root / FDC, root / 'build.tcl', root / 'run_trial.tcl']
    return {p.relative_to(root).as_posix(): sha(p) for p in sorted(files)}


def parse_csv(path):
    lines = read(path).splitlines()
    need(any('2022.2-SP6.4' in line for line in lines[:3]), 'SP6.4 version evidence missing')
    header = next((i for i, line in enumerate(lines) if line.startswith('Seed,State,Convergence,')), None)
    need(header is not None, 'Native seed header missing')
    rows = []
    for line in lines[header + 1:]:
        if not line.strip() or line.startswith('Pass Rate'):
            break
        rows.append(line)
    table = list(csv.DictReader(io.StringIO('\n'.join([lines[header]] + rows))))
    need(len(table) == 1, 'Expected one native result per isolated seed directory')
    row = table[0]
    need(row['State'] == 'OK', 'Native flow state is not OK')
    quad = {k: number(row[k]) for k in ('Setup(Slow)', 'Setup(Fast)', 'Hold(Slow)', 'Hold(Fast)')}
    quad.update(tns=number(row['Setup(Slow) Total Failing TNS']),
                ep=int(row['Setup(Slow) Total Failing Endpoints']),
                hold_tns=number(row['Hold(Slow) Total Failing THS']),
                hold_ep=int(row['Hold(Slow) Total Failing Endpoints']))
    need(quad['ep'] >= 0 and quad['hold_ep'] >= 0, 'Negative endpoint count')
    return dict(native_seed=row['Seed'], convergence=row['Convergence'], **quad)


def parse_final(path):
    text = read(path)
    summary = re.search(r'(?m)^Design Summary\s*:\s*(.+)$', text)
    need(summary is not None, 'Design Summary missing')
    sections = {}
    matches = list(re.finditer(r'(?m)^(\w+) Summary\((Slow|Fast) Corner\):\s*$', text))
    for i, match in enumerate(matches):
        kind, corner = match.groups()
        body = text[match.end():matches[i + 1].start() if i + 1 < len(matches) else len(text)]
        domains = []
        for line in body.splitlines():
            parts = line.split()
            if len(parts) != 6:
                continue
            try:
                wns, tns = number(parts[2]), number(parts[3])
                ep, total = int(parts[4]), int(parts[5])
            except ValueError:
                continue
            need(ep >= 0 and total >= ep, 'Invalid final endpoint count')
            domains.append(dict(launch=parts[0], capture=parts[1], wns=wns, tns=tns, ep=ep, total=total))
        if domains:
            sections[kind + '(' + corner + ')'] = dict(
                wns=min(r['wns'] for r in domains), tns=round(sum(r['tns'] for r in domains), 6),
                ep=sum(r['ep'] for r in domains), domains=domains)
    need(all(k in sections for k in ('Setup(Slow)', 'Setup(Fast)', 'Hold(Slow)', 'Hold(Fast)')),
         'Final report lacks one or more timing quadrants')
    return dict(design_summary=summary.group(1).strip(), sections=sections)


def binding_evidence(root):
    # The source module attribute by itself is NOT proof. Require exported leaf attributes
    # on both synthesized multiplier trees. Exports are evidence only, never build inputs.
    hits = {'N78': [], 'N82': []}
    for path in (root / 'binding_mapped.fdc', root / 'binding_groups.fdc'):
        if not path.is_file():
            continue
        for obj, value in re.findall(r'define_attribute\s+\{([^}]+)\}\s+\{PAP_GROUP\}\s+\{([^}]+)\}', read(path)):
            if value != GROUP:
                continue
            for prefix in hits:
                if re.search(r'u_map[./]' + prefix + r'_[am]\w*', obj):
                    hits[prefix].append(dict(file=path.name, object=obj))
    return dict(confirmed=all(hits.values()), leaf_attributes=hits,
                limitation='Exported leaf binding is checked; placement benefit still requires timing runs.')


def prepare(package, out, seeds):
    package, out = package.resolve(), out.resolve()
    need(out.as_posix().isascii(), 'Use a new ASCII output path for PDS')
    need(not out.exists(), 'Output already exists; do not overwrite evidence')
    need(len(seeds) == len(set(seeds)) and all(s >= 0 for s in seeds), 'Seeds must be distinct nonnegative integers')
    need(not out.is_relative_to(package) and not package.is_relative_to(out), 'Separate package and run directories')
    manifest = json.loads((package / 'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
    for name, digest in manifest.items():
        need(sha(package / name) == digest, 'Package hash mismatch: ' + name)
    source = package / 'candidate_host'
    need(read(source / FDC).endswith(ATTRIBUTE), 'Unexpected trial constraint')
    base = read(source / 'build.tcl')
    need(base.count('\npnr\n') == 1 and base.count('\ndev_map\n') == 1, 'Unexpected build flow')
    base = base[:base.index('\npnr\n')]
    out.mkdir(parents=True)
    plan = dict(created=dt.datetime.now().isoformat(), seeds=seeds, group=GROUP,
                package_manifest_sha256=sha(package / 'MANIFEST_SHA256.json'),
                constraint_kind='RTL module PAP_GROUP, coarse locality trial, not a numeric region')
    for seed in seeds:
        target = out / ('seed_' + str(seed))
        shutil.copytree(source, target)
        flow = ('proc g6_optional_export {args} {\n'
                '    if {[catch {uplevel 1 $args} detail]} {puts "G6_EXPORT_UNAVAILABLE=$detail"}\n}\n'
                + base + '\n'
                + 'g6_optional_export export_fdc -file binding_mapped.fdc\n'
                + 'puts "G6_PHASE=DEV_MAP_DONE"\n'
                + 'pnr -gplace_seed ' + str(seed) + ' -groute_seed ' + str(seed) + '\n'
                + 'puts "G6_PHASE=PNR_DONE"\nreport_timing\ngen_bit_stream\n'
                + 'g6_optional_export generate_constraint -file binding_groups.fdc -group\n'
                + 'puts "G6_PHASE=FINISHED"\n')
        (target / 'run_trial.tcl').write_text(flow, encoding='utf-8')
        dump(target / 'trial_inputs_sha256.json', inputs(target))
    dump(out / 'run_plan.json', plan)
    print('PREPARED; no physical run performed: ' + str(out))


def execute(root, shell, limit):
    root, shell = root.resolve(), shell.resolve()
    need(shell.is_file(), 'PDS shell executable not found')
    need(root.as_posix().isascii(), 'PDS run path must be ASCII')
    plan = json.loads((root / 'run_plan.json').read_text(encoding='utf-8'))
    completed = 0
    for seed in plan['seeds']:
        target = root / ('seed_' + str(seed))
        if (target / 'process_receipt.json').exists():
            continue
        if limit is not None and completed >= limit:
            break
        need(not (target / 'console_full.log').exists(), 'Interrupted run exists; preserve it and create a fresh run')
        expected = json.loads((target / 'trial_inputs_sha256.json').read_text())
        need(inputs(target) == expected, 'Seed input hashes changed before execution')
        started = dt.datetime.now().isoformat()
        start = time.monotonic()
        code, error = None, None
        print('RUN seed ' + str(seed), flush=True)
        with (target / 'console_full.log').open('wb') as log:
            try:
                proc = subprocess.Popen([str(shell), '-file', 'run_trial.tcl'], cwd=target,
                                        stdout=log, stderr=subprocess.STDOUT)
                try:
                    code = proc.wait(timeout=10800)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    code = proc.wait()
                    error = 'PDS shell timeout (10800s); inspect for remaining child processes'
            except OSError as exc:
                error = repr(exc)
        after = inputs(target)
        artifacts = {p.relative_to(target).as_posix(): sha(p) for p in target.rglob('*')
                     if p.is_file() and p.suffix.lower() in ('.csv', '.txt', '.db', '.sbit', '.prr', '.pcf', '.fdc', '.log', '.vm')}
        dump(target / 'process_receipt.json', dict(seed=seed, placement_seed=seed, route_seed=seed,
             pds_shell=str(shell), started=started, finished=dt.datetime.now().isoformat(),
             seconds=round(time.monotonic() - start, 3), exit_code=code, error=error,
             inputs_unchanged=(after == expected), inputs_before=expected, inputs_after=after,
             artifacts_sha256=artifacts))
        completed += 1
        print('DONE seed %s exit=%s; receipt preserved' % (seed, code), flush=True)
        if error is not None:
            break


def unique(root, pattern):
    found = [p for p in root.rglob(pattern) if p.is_file() and p.stat().st_size]
    need(len(found) == 1, 'Expected one nonempty ' + pattern + '; got ' + str(len(found)))
    return found[0]


def assess(root, console_policy='strict'):
    root = root.resolve()
    plan = json.loads((root / 'run_plan.json').read_text(encoding='utf-8'))
    seeds = plan['seeds']
    need(len(seeds) == len(set(seeds)), 'Duplicate seeds in plan')
    rows = []
    for seed in seeds:
        target = root / ('seed_' + str(seed))
        row = dict(seed=seed, valid=False)
        rows.append(row)
        try:
            receipt = json.loads((target / 'process_receipt.json').read_text(encoding='utf-8'))
            need(receipt['seed'] == receipt['placement_seed'] == receipt['route_seed'] == seed, 'Seed receipt mismatch')
            flow = read(target / 'run_trial.tcl')
            need(('pnr -gplace_seed %d -groute_seed %d\n' % (seed, seed)) in flow, 'Seed script mismatch')
            need(receipt['exit_code'] == 0 and receipt['error'] is None, 'PDS process failed')
            expected = json.loads((target / 'trial_inputs_sha256.json').read_text())
            need(receipt['inputs_unchanged'] and inputs(target) == expected == receipt['inputs_before'] == receipt['inputs_after'],
                 'Input drift detected')
            artifacts = receipt['artifacts_sha256']
            for name, digest in artifacts.items():
                need(sha(target / name) == digest, 'Artifact hash mismatch: ' + name)
            console = read(target / 'console_full.log')
            need(re.search(r'(?m)^G6_PHASE=FINISHED\s*$', console) is not None, 'Flow completion marker missing')
            required = [unique(target, pattern) for pattern in ('rtr.db', 'multiseed_summary.csv',
                        '*_timing_summary_after_hold_fix.txt', '*.sbit')]
            for path in required + [target / 'console_full.log']:
                need(path.relative_to(target).as_posix() in artifacts, 'Unreceipted artifact: ' + path.name)
            need(ET.parse(required[0]).getroot() is not None, 'Invalid timing XML')
            post = parse_csv(required[1])
            final = parse_final(required[2])
            row['console_gate'] = classify(console, seed, receipt, console_policy)
            need(row['console_gate']['accepted'], row['console_gate']['reason'])
            row.update(valid=True, postroute=post, after_hold_fix=final, binding=binding_evidence(target))
        except (ValueError, KeyError, OSError, ET.ParseError) as exc:
            row['invalid_reason'] = str(exc)
    valid = [r for r in rows if r['valid']]
    # Only the seed-specific driver may differ. A source/constraint mismatch invalidates
    # comparability even if all individual receipts are internally consistent.
    comparisons = []
    for seed in seeds:
        p = root / ('seed_' + str(seed)) / 'trial_inputs_sha256.json'
        if p.is_file():
            obj = json.loads(p.read_text())
            comparisons.append({k: v for k, v in obj.items() if k != 'run_trial.tcl'})
    comparable = len(comparisons) == len(seeds) and bool(comparisons) and all(c == comparisons[0] for c in comparisons)
    closed = [r for r in valid if r['postroute']['Setup(Slow)'] >= 0 and r['postroute']['ep'] == 0 and r['postroute']['tns'] == 0]
    ratio = len(closed) / len(valid) if valid else 0
    s1 = len(valid) >= 8 and ratio >= .8 and all(r['postroute']['Setup(Slow)'] >= -.10 for r in valid)
    s2 = True
    for row in valid:
        p, q = row['postroute'], row['after_hold_fix']['sections']
        # Setup must keep the same pass/fail direction after hold fix; fast setup and both holds must meet.
        pc = p['Setup(Slow)'] >= 0 and p['ep'] == 0 and p['tns'] == 0
        fc = q['Setup(Slow)']['wns'] >= 0 and q['Setup(Slow)']['ep'] == 0 and q['Setup(Slow)']['tns'] == 0
        row['two_views_consistent'] = pc == fc
        row['other_quadrants_met'] = (p['Setup(Fast)'] >= 0 and p['Hold(Slow)'] >= 0 and p['Hold(Fast)'] >= 0
              and p['hold_ep'] == 0 and p['hold_tns'] == 0 and all(
                  q[k]['wns'] >= 0 and q[k]['ep'] == 0 and q[k]['tns'] == 0
                  for k in ('Setup(Fast)', 'Hold(Slow)', 'Hold(Fast)')))
        row['final_summary_consistent'] = not ('No Constraints Violated' in row['after_hold_fix']['design_summary'] and
              any(section['ep'] or section['wns'] < 0 for section in q.values()))
        s2 &= row['two_views_consistent'] and row['other_quadrants_met'] and row['final_summary_consistent']
    binding = bool(valid) and all(r['binding']['confirmed'] for r in valid)
    complete = len(valid) == len(seeds) and len(valid) >= 8
    return dict(console_policy=console_policy, validity_scope='Receipt/input/artifact/console/timing evidence only; binding and S1-S5 acceptance are separate', seeds=rows, planned=len(seeds), valid=len(valid), closed=len(closed), closure_ratio=ratio,
                S1_pass=s1, S2_pass=bool(valid) and bool(s2), S5_seed_evidence_complete=complete,
                binding_confirmed=binding, comparable_inputs=comparable,
                physical_trial_pass=s1 and s2 and complete and binding and comparable,
                S3_status='UNRESOLVED: cache DRM16 versus <=12; approved APM allocation and latency contract require review',
                S4_status='PENDING: prior functional evidence is bundled separately; new full regression not run by this tool',
                overall_G6_acceptance='NOT DECLARED; S3/S4 and package-wide S5 require separate review')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    cmd = parser.add_subparsers(dest='command', required=True)
    p = cmd.add_parser('prepare')
    p.add_argument('--package', type=Path, default=Path(__file__).resolve().parent.parent)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--seeds', type=int, nargs='+', default=[2, 3, 5, 7, 8, 9, 10, 11])
    p = cmd.add_parser('execute')
    p.add_argument('--run', type=Path, required=True)
    p.add_argument('--pds-shell', type=Path, required=True)
    p.add_argument('--limit', type=int, help='Optional pilot count; subsequent execute completes remaining seeds')
    p = cmd.add_parser('collect')
    p.add_argument('--run', type=Path, required=True)
    p.add_argument('--console-policy', choices=('strict', 'startup-db-v1'), default='strict')
    p.add_argument('--output', type=Path, required=True, help='New output outside run evidence directory')
    args = parser.parse_args()
    if args.command == 'prepare':
        prepare(args.package, args.out, args.seeds)
    elif args.command == 'execute':
        need(args.limit is None or args.limit > 0, 'Limit must be positive')
        execute(args.run, args.pds_shell, args.limit)
    else:
        output = args.output.resolve()
        need(not output.exists(), 'Output already exists; preserve earlier results')
        need(not output.is_relative_to(args.run.resolve()), 'Output must be outside original run evidence')
        result = assess(args.run, args.console_policy)
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open('x', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(json.dumps({k: v for k, v in result.items() if k != 'seeds'}, ensure_ascii=False, indent=2))
        raise SystemExit(0 if result['physical_trial_pass'] else 2)


if __name__ == '__main__':
    main()
