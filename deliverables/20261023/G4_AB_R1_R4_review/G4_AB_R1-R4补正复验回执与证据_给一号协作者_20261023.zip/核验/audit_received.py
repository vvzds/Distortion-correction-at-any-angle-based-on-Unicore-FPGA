from pathlib import Path
import hashlib,json,zipfile,shutil,datetime
W=Path(__file__).resolve().parent;R=W/'received/G4_AB_R1_R4_20261023';A=Path('D:/FPGA_management/incoming/G4_AB_R1_R4_20261023')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((R/'delivery_manifest.json').read_text(encoding='utf-8'))
rows=m['files'];fail=[]
for row in rows:
 p=(R/row['file']).resolve()
 if not p.is_relative_to(R.resolve()) or not p.is_file() or p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:fail.append(row['file'])
actual={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()}
listed={r['file'] for r in rows}
with zipfile.ZipFile(A/'G4_AB_R1_R4补正回传包_20261023.zip') as z:
 names=[i.filename.casefold() for i in z.infolist()];assert len(names)==len(set(names))
doc_equal=(A/'补正回传表.md').read_bytes()==(R/'docs/补正回传表.md').read_bytes()
report=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),manifest_files=len(rows),actual_files=len(actual),failed=fail,unlisted=sorted(actual-listed),missing=sorted(listed-actual),separate_report_byte_equal=doc_equal,manifest_sha256=sha(R/'delivery_manifest.json'))
(W/'receive_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
checks=[]
for line in (R/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
 h,name=line.split('  ',1);p=(R/name).resolve();assert p.is_relative_to(R.resolve()) and sha(p)==h;checks.append(name)
report['sha256sums_verified']=len(checks)
assert set(checks)==actual-{'SHA256SUMS.txt'}
assert not fail and doc_equal and actual-listed=={'delivery_manifest.json','SHA256SUMS.txt'} and not listed-actual
(W/'receive_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
E=W/'execution';shutil.copytree(R,E)
