from pathlib import Path
import json,hashlib,re,difflib,datetime
W=Path(__file__).resolve().parent;R=W/'received/G4_AB_R1_R4_20261023';E=W/'execution'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
summ=json.loads((W/'modelsim_fixed/summary.json').read_text(encoding='utf-8'));rows=[]
for r in summ['results']:
 name=r['case'];d=W/'modelsim_fixed'/name;i=json.loads((d/'inputs.json').read_text(encoding='utf-8'))
 assert r['status']=='PASS' and r['inputs_unchanged'] and r['tool_hashes_before']==r['tool_hashes_after']
 for x in i['inputs']:assert sha(E/x['file'])==x['sha256']
 for s in r['steps']:assert s['exit_code']==0 and sha(d/s['log'])==s['log_sha256']
 body=(d/'simulation.log').read_text(encoding='utf-8');assert '$finish' in body and r['terminal_marker'] in body
 assert not re.search(r'\b(?:FATAL|FAIL|FAILED|TIMEOUT|MISMATCH|ERROR)\b',body,re.I)
 history={'identity':'r4_latency_matrix/identity','real_joint':'r4_latency_matrix/real_joint','c6_host_arb':'original_matrix_v2/c6_host_arb','r3_boundary':'r3_boundary/r3_boundary'}[name]
 previous=(R/'evidence'/history/'simulation.log').read_text(encoding='utf-8')
 selected=[s.removeprefix('# ') for s in body.splitlines() if any(k in s for k in ['CORE PASS','R4_ACTUAL','R3_CORE_DRAIN','R3_BOUNDARY PASS','C6_HOST_ARB PASS','HOST_ARBITRATION'])]
 assert all(s in previous for s in selected)
 warnings=re.findall(r'^# \*\* Warning:.*$',body,re.M)
 rows.append(dict(case=name,status='PASS',inputs=len(i['inputs']),results_match_received_icarus=True,summary_lines=selected,warnings=warnings,simulation_log_sha256=sha(d/'simulation.log'),result_sha256=sha(d/'result.json')))
m=json.loads((R/'delivery_manifest.json').read_text(encoding='utf-8'))
changed=[]
for row in m['files']:
 assert sha(R/row['file'])==row['sha256']
 if sha(E/row['file'])!=row['sha256']:changed.append(row['file'])
assert changed==['tools/run_modelsim_validation.py']
orig=(R/'tools/run_modelsim_validation.py').read_text(encoding='utf-8');fixed=(E/'tools/run_modelsim_validation.py').read_text(encoding='utf-8')
(W/'ModelSim_launcher_path_fix.diff').write_text(''.join(difflib.unified_diff(orig.splitlines(True),fixed.splitlines(True),fromfile='received/tools/run_modelsim_validation.py',tofile='execution/tools/run_modelsim_validation.py')),encoding='utf-8')
docs={
'D:/FPGA项目文档/总说明/模块分工与工作包交付总说明_v2.0.3.md':'2d36c72f80c80ad977d2b6a2080bc66bab0e3ff876dc508bbdee39dc8b3903fe',
'D:/FPGA项目文档/任务清单/各协作者当前任务清单_v2.0.3_20261023.md':'f5be22dea0495db187857f4b5969c2f9deb85815743c3f3176cb52f3fe00c837'}
for p,h in docs.items():assert sha(Path(p))==h
out=dict(status='PASS',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),local_timezone='Asia/Shanghai',cases=rows,local_modelsim_pass_count=4,received_manifest_still_matches=True,execution_copy_changed_files=changed,patched_launcher_sha256=sha(E/'tools/run_modelsim_validation.py'),received_launcher_sha256=sha(R/'tools/run_modelsim_validation.py'),initial_runner_failure='All four original runner cases exit 12 before RTL simulation: ModelSim vsim-7 invalid backslash -modelsimini path. Kept under modelsim_key. Fixed in execution copy only.',versioned_documents_unchanged=docs)
(W/'modelsim_audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
