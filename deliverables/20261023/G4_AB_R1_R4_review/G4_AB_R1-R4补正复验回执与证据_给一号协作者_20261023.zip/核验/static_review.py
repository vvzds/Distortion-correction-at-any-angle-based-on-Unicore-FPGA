from pathlib import Path
import json,hashlib,importlib.util,re,difflib,shutil,subprocess,sys,datetime
W=Path(__file__).resolve().parent;R=W/'received/G4_AB_R1_R4_20261023';C=R/'candidate'
OLD=Path('D:/FPGA_management/work/G4_AB_review_20261023/extracted/G4_AB_candidate_20261022')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
spec=importlib.util.spec_from_file_location('received_runner',C/'run_validation_exact64.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
final=json.loads((R/'evidence/final_evidence.json').read_text(encoding='utf-8'));results=[]
for entry in final['local_simulations']:
 p=R/entry['result'];d=p.parent;j=json.loads(p.read_text(encoding='utf-8'));inputs=json.loads((d/'inputs.json').read_text(encoding='utf-8'))
 assert sha(p)==entry['result_sha256'] and j['passed'] and j['inputs_unchanged']
 assert all(sha(C/x['file'])==x['sha256'] for x in inputs['inputs'])
 assert all(sha(C/x['file'])==x['sha256'] for x in j['inputs_after'])
 assert {x['file']:x['sha256'] for x in inputs['inputs']}=={x['file']:x['sha256'] for x in j['inputs_after']}
 for s in j['steps']:
  assert s['exit_code']==0 and sha(d/s['log'])==s['log_sha256']
  assert s['command'] and s['cwd'] and s['start_utc']<=s['end_utc']
 body=(d/'simulation.log').read_text(encoding='utf-8',errors='replace')
 assert j['terminal_marker'] in body and not re.search(r'\b(?:FATAL|FAIL|FAILED|TIMEOUT|MISMATCH|ERROR)\b',body,re.I)
 plan=runner.plan(entry['case']);expected={x.relative_to(C).as_posix() for x in runner.dependencies(plan['files'])+plan['vectors']}
 recorded={x['file'] for x in inputs['inputs']}
 assert expected<=recorded
 assert inputs['plusargs']==plan['plusargs'] and inputs['compile_files']==[p.relative_to(C).as_posix() for p in plan['files']]
 results.append(dict(case=entry['case'],result=entry['result'],input_count=len(recorded),dependencies_and_vectors_recorded=True,log_hashes_verified=True,result_sha256=sha(p),summary_lines=[s for s in body.splitlines() if any(k in s for k in ['PASS','R3_','R4_','AB_STATS'])]))
same=['source/rtl/undistort_map.v','source/rtl/undistort_bilinear.v','source/rtl/undistort_cache_ab.v','host_ab/HDMI_DDR3_OV5640_test.fdc','host_g4/HDMI_DDR3_OV5640_test.fdc']
for f in same:assert (OLD/f).read_bytes()==(C/f).read_bytes()
for f in ['undistort_core.v','undistort_map.v','undistort_bilinear.v','undistort_cache_ab.v']:assert (C/'source/rtl'/f).read_bytes()==(C/'host_ab/source/rtl'/f).read_bytes()
old=(OLD/'source/rtl/undistort_core.v').read_text(encoding='utf-8-sig');new=(C/'source/rtl/undistort_core.v').read_text(encoding='utf-8-sig')
(W/'R1_core_review.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='prior/source/rtl/undistort_core.v',tofile='corrected/source/rtl/undistort_core.v')),encoding='utf-8')
def normalize(s):
 for text in ['reg head_valid;','reg [31:0] head_ids_reg;','wire lookup_busy,lookup_done,ids_ready,fetch_req;']:
  assert s.count(text)==1;s=s.replace(text,'')
 s=s.replace('wire sample_dispatch=identity_mode?line_sample_dispatch:seg_sample_dispatch;','')
 s=s.replace('wire sample_dispatch;','').replace('assign sample_dispatch=identity_mode?line_sample_dispatch:seg_sample_dispatch;','')
 return re.sub(r'\s+','',s)
assert normalize(old)==normalize(new)
gen=W/'generator_reproduction';gen.mkdir(exist_ok=False)
for f in ['build_candidate_sources.py','reference/undistort_core.v','reference/undistort_line_cache_tb.v']:
 dest=gen/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(C/f,dest)
(gen/'source/rtl').mkdir(parents=True);(gen/'sim').mkdir()
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
cmd=[sys.executable,'-B','-X','utf8',str(gen/'build_candidate_sources.py')]
with (gen/'run.log').open('wb') as log:code=subprocess.run(cmd,cwd=gen,stdout=log,stderr=subprocess.STDOUT).returncode
assert code==0
for f in ['source/rtl/undistort_core.v','sim/cache72_ab_tb.v']:assert (gen/f).read_bytes()==(C/f).read_bytes()
save(gen/'result.json',dict(command=cmd,cwd=str(gen),start_utc=start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=code,log_sha256=sha(gen/'run.log'),input_hashes={f:sha(gen/f) for f in ['build_candidate_sources.py','reference/undistort_core.v','reference/undistort_line_cache_tb.v']},byte_reproduction=True,output_hashes={f:sha(gen/f) for f in ['source/rtl/undistort_core.v','sim/cache72_ab_tb.v']}))
save(W/'static_review.json',dict(status='PASS',received_icarus_cases_verified=len(results),cases=results,core_sha256=sha(C/'source/rtl/undistort_core.v'),only_core_declaration_order_and_equivalent_assign_changed=True,unchanged_scope={f:sha(C/f) for f in same},host_copies_equal=True,generator_byte_reproduction=True,model_sim_runner_local_path_adapter=True))
print('STATIC PASS: 16 received Icarus records, input and log hashes, dependencies, source scope and generator reproduction')
