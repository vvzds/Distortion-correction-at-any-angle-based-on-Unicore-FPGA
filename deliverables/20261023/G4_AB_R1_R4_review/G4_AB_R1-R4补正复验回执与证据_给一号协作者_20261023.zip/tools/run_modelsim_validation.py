"""ModelSim 10.7 handoff runner. Not a claim of execution without that tool."""
import argparse
import importlib.util
import json
from pathlib import Path
import re
import sys

ROOT=Path(__file__).resolve().parents[1]
CANDIDATE=ROOT/'candidate'
spec=importlib.util.spec_from_file_location('ab_evidence_runner',CANDIDATE/'run_validation_exact64.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)

# Local execution adapter: ModelSim 10.7 Tcl rejects backslash path arguments
# to -modelsimini/-do. Preserve the received runner; normalize Path arguments
# only in this execution copy, without changing RTL, stimulus or assertions.
_execute_original = runner.execute
def execute_portable(command, cwd, log, timeout):
    return _execute_original([v.as_posix() if isinstance(v, Path) else v for v in command], cwd, log, timeout)
runner.execute = execute_portable

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tool-root',type=Path,help='ModelSim win64 directory')
    parser.add_argument('--cases',nargs='+',default=['identity','real_joint','c6_host_arb','r3_boundary'])
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--inspect-only',action='store_true',help='resolve inputs only; never label PASS')
    parser.add_argument('--timeout',type=int,default=7200)
    args=parser.parse_args()
    if not args.inspect_only:
        if args.tool_root is None:parser.error('--tool-root required for actual execution')
        args.tool_root=args.tool_root.resolve()
        for name in ('vlib','vmap','vlog','vsim'):
            if not (args.tool_root/(name+'.exe')).is_file():parser.error('tool unavailable: '+name)
    out=args.out.resolve();out.mkdir(parents=True,exist_ok=False)
    results=[]
    for case in args.cases:
        dest=out/case;dest.mkdir()
        plan=runner.plan(case)
        sources=runner.dependencies(plan['files'])+plan['vectors']+[
            Path(__file__).resolve(),CANDIDATE/'run_validation_exact64.py',
            CANDIDATE/'run_sim.ps1',CANDIDATE/'build_candidate_sources.py']
        before=[dict(file=p.relative_to(ROOT).as_posix(),sha256=runner.sha(p)) for p in sorted(set(sources))]
        cwd=CANDIDATE/'verification_data' if plan['data_cwd'] else dest
        runner.dump(dest/'inputs.json',dict(case=case,recorded_at_utc=runner.now(),inputs=before,
                    working_directory=str(cwd),plusargs=plan['plusargs'],top=plan['top'],
                    compile_files=[p.relative_to(ROOT).as_posix() for p in plan['files']]))
        if args.inspect_only:
            result=dict(case=case,status='NOT_TESTED',reason='input resolution only; no ModelSim execution')
        else:
            tool=args.tool_root
            tool_before={n:runner.sha(tool/(n+'.exe')) for n in ('vlib','vmap','vlog','vsim')}
            steps=[]
            steps.append(runner.execute([tool/'vlog.exe','-version'],dest,dest/'tool_version.log',60))
            steps.append(runner.execute([tool/'vlib.exe',dest/'work'],dest,dest/'vlib.log',60))
            # Create a local INI and explicitly map work. This avoids relying
            # on the caller CWD or an unverified physical-library.top syntax.
            steps.append(runner.execute([tool/'vmap.exe','-c'],dest,dest/'vmap_create.log',60))
            steps.append(runner.execute([tool/'vmap.exe','work',dest/'work'],dest,dest/'vmap_work.log',60))
            ini=dest/'modelsim.ini'
            for tb in (False,True):
                files=[p for p in plan['files'] if p.name.endswith('_tb.v')==tb]
                cmd=[tool/'vlog.exe','-modelsimini',ini]+(['-sv'] if tb else [])+['-work','work']
                cmd+=['+incdir+'+p.as_posix() for p in runner.INC]+files
                steps.append(runner.execute(cmd,dest,dest/('compile_tb.log' if tb else 'compile_rtl.log'),120))
            if all(s['exit_code']==0 for s in steps):
                do=dest/'run.do'
                do.write_text('onerror {quit -code 2 -f}\nonbreak {quit -code 0 -f}\nrun -all\nquit -code 0 -f\n',encoding='ascii')
                cmd=[tool/'vsim.exe','-modelsimini',ini,'-c','-onfinish','stop','-voptargs=+acc',
                     'work.'+plan['top'],'-l',dest/'transcript.log','-do',do]+plan['plusargs']
                steps.append(runner.execute(cmd,cwd,dest/'simulation.log',args.timeout))
            body=(dest/'simulation.log').read_text(encoding='utf-8',errors='replace') if (dest/'simulation.log').exists() else ''
            marker={'c6_host_arb':'C6_HOST_ARB PASS','r3_boundary':'R3_BOUNDARY PASS',
                    'integration':'ALL TESTS PASSED (err=0)'}.get(case,'CORE PASS')
            unchanged=all(runner.sha(ROOT/r['file'])==r['sha256'] for r in before)
            tool_after={n:runner.sha(tool/(n+'.exe')) for n in tool_before}
            bad=re.findall(r'\b(?:FATAL|FAIL|FAILED|TIMEOUT|MISMATCH|ERROR)\b',body,re.I)
            passed=all(s['exit_code']==0 for s in steps) and marker in body and '$finish' in body and not bad and unchanged and tool_before==tool_after
            result=dict(case=case,status='PASS' if passed else 'FAIL',steps=steps,
                        inputs_unchanged=unchanged,tool_hashes_before=tool_before,tool_hashes_after=tool_after,
                        bad_tokens=bad,terminal_marker=marker)
        runner.dump(dest/'result.json',result);results.append(result)
        print(case,result['status'],flush=True)
    runner.dump(out/'summary.json',dict(engine='modelsim',inspect_only=args.inspect_only,results=results))
    return 0 if args.inspect_only or all(r['status']=='PASS' for r in results) else 1
if __name__=='__main__':sys.exit(main())
