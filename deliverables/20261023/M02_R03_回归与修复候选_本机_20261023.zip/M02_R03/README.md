# M02：R03 标定异常端到端回归交付

版本：M02 1.0.0，2026-10-23。状态：验证模块已实现并执行；原版缺陷已复现，独立 calibrate 修复候选已通过矩阵。现用/归档参考版本未覆盖，R03 对原版的缺陷关闭仍待修复件接收与应用确认。

## 快速复现

建议 Python 3.12，依赖版本见 reference/requirements-reference.txt；本轮实测 Python 3.12.10、numpy 2.5.4、OpenCV 5.0.0、pyserial 3.5。仅使用已存在的本机依赖，未联网安装。

解压后在包根执行，out 必须是尚不存在的目录；已经存在的结果不会覆盖：

```powershell
python -B verify_delivery.py
python -B reference/verify_package.py
python -B implementation/run_r03.py --offline --out rerun/reference
python -B implementation/run_r03.py --offline --source candidate --out rerun/candidate
python -B reference/current/uart/uart_tool.py selftest
python -B candidate/uart_tool.py selftest
```

原版回归预期返回 1（普通模式414通过、优化模式406通过/8失败），候选返回0（828全部通过）；基础设施/驱动内部异常返回2并标BLOCKED。每次父进程自动用普通和 `-O` 两个子进程执行同一414案矩阵，完整控制台和子进程退出码写入结果目录。运行结果的日期、绝对路径、运行时间以及NPZ容器哈希可能变化，以用例结论和输入/源码对应关系复核，不比较整包二进制哈希是否跨运行一致。

测试拒绝真实设备：UART main 使用注入的 serial 模块，原始 open_serial 默认参数也会导向该模块，唯一允许端口为 FAKE_ONLY；OpenCV VideoCapture 与 socket 被禁用。serial短写/异常测试记录的是替身调用与模拟接受字节，不能称为物理发送成功或参数已经生效。该限制针对本驱动的执行路径，不是系统级通用沙箱。

## 文件布局

- `implementation/run_r03.py`：实际主入口验证驱动、独立字节级oracle、结果关联/校验编排器、参数/文件/图像/串口异常矩阵。
- `implementation/prepare_candidate.py`：从原件创建当前最小修复候选的可复现脚本；仅在 candidate 为空时使用，禁止覆盖已有候选。
- `reference/`：上一轮 M02 资料包，200个被清单覆盖的原件保持不变；内嵌历史日志只作参考，不计本轮PASS。
- `candidate/calibrate.py` 与 `.diff`：仅6处assert改为显式检查及ValueError；UART源码和tests与已验收tlimfix完全相同。candidate中随附UART原包文档/verification仍为历史材料，本轮自测看顶层verification。
- `results/reference_verified/`、`results/candidate_verified/`：最终同一驱动/同一用例矩阵的两套机器结果、每案原始日志、输入与实际产物，正常和优化模式分别保存。图片目录是故障注入占位文件，不是真实PNG；不要用它们做图像质量评估。
- `verification/`：本次UART U0–U5与reference完整性日志、命令/退出码。
- `M02_R03_执行报告_管理方_20261023.md`：结论、覆盖映射、缺陷与边界勘误。
- `MANIFEST_SHA256.json` 与 `verify_delivery.py`：本交付文件集合和哈希；清单自身不自引用，ZIP及清单哈希另附包外锚点。

## 验证方法与边界

多数标定异常案替换图像/角点、calibrateCamera返回值及projectPoints；实际calibrate.main参数解析、G02、量化及写文件全部执行。真实求解案只替换图像/角点提供者，保留真实OpenCV求解与投影；20视角夹具沿用历史test_cv_paths.py数值构造。另用14视角真实求解复现-O绕过最低张数。所有这些都是合成数值证据，不含实拍标定精度或板端验收。

标定器不直接发串口。`consume` 是本次新建的**测试编排器**：检查本次调用状态、运行ID、产物新鲜性和哈希、严格JSON、明确布尔g02_pass、帧头/长度/checksum/参数一致性后调用真实UART main。拒绝旧文件/坏帧的用例证明该编排器行为，不伪称原产品已有生产自动上传链路。

原版和候选在某些失败路径仍保留同目录上次成功结果；本测试保存旧文件快照，不改原输出掩盖事实。测试编排器隔离各案并在复用目录时拒绝未更新产物。真实人工/其他自动化工具不得只凭“calib_result.json存在”发送。原版G02拒绝分支返回None/进程0并不表示标定成功；以明确g02_pass和本次产物判断。

浮点G02表与定点表在fx/fy上界的写法不同。冻结协议定点上界0x7FFFFFFF及旧U2允许32767.99编码；现有calibrate另有“解码后≤32767.99”校验。本矩阵分别覆盖这两种现有行为，不把UART成功当硬件越界，也不放宽calibrate既有检查。统一两工具边界是单独口径事项。

R03-09是全部414案的普通/-O对照，另有显式14视角真实求解案。重复键属于观察兼容性项，记录现有CLI拒绝，不新立协议要求。force可发送可表示域外值；NaN/Inf/有符号Q16溢出仍拒绝，能力未删除。

待您转交：二号优先复核候选与证据；一号同步报告，按需查阅包内UART边界说明。若无错误不进行回复。

本次工作主要由 GPT-6 模型完成。
