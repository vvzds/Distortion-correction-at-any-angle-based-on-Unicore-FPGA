"""Verify the immutable delivered set; allow only separate rerun/ output."""
from pathlib import Path, PurePosixPath
import hashlib,json,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
expected=set(manifest)
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and not p.relative_to(root).parts[0]=='rerun' and p.relative_to(root).as_posix()!='MANIFEST_SHA256.json'}
errors=[]
if actual!=expected:errors.append({'missing':sorted(expected-actual),'extra':sorted(actual-expected)})
for name,item in manifest.items():
 p=PurePosixPath(name)
 if p.is_absolute() or '..' in p.parts or ':' in name:raise ValueError('Unsafe manifest path')
 f=root.joinpath(*p.parts)
 if not f.is_file() or f.stat().st_size!=item['bytes'] or hashlib.sha256(f.read_bytes()).hexdigest()!=item['sha256']:errors.append(name)
print('DELIVERY_INTEGRITY', 'FAIL' if errors else 'PASS', 'files=',len(expected))
if errors:print(json.dumps(errors,ensure_ascii=False,indent=2))
sys.exit(1 if errors else 0)
