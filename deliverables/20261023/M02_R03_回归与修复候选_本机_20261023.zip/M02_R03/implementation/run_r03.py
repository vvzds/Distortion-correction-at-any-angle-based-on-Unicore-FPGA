"""Offline R03 main-entry regression. No camera/network/real serial access.

Run from any cwd: python -B implementation/run_r03.py --offline --out results/baseline
The parent executes independent normal and -O child interpreters. Exit 1 preserves
product failures; exit 2 denotes a harness/infrastructure failure.
"""
from pathlib import Path
import argparse, contextlib, csv, hashlib, importlib.util, io, json, math
import os, struct, subprocess, sys, traceback, types
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
REF = ROOT / 'reference'
NAMES = ('fx','fy','cx','cy','k1','k2','p1','p2')
LIMITS = dict(zip(NAMES, [(128.,32767.99),(128.,32767.99),(0.,1919.),(0.,1079.),(-.5,.5),(-.5,.5),(-.01,.01),(-.01,.01)]))
BASE = dict(zip(NAMES,[1000.,980.,960.,540.,-.1,.03,.002,-.001]))
LSB=1/65536

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def clean(x):
    if isinstance(x,float) and not math.isfinite(x):return str(x)
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [clean(v) for v in x]
    return x
def dump(p,obj): Path(p).write_text(json.dumps(clean(obj),ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def strict_json(p):
    def bad(s):raise ValueError('Non-standard JSON constant: '+s)
    return json.loads(Path(p).read_text(encoding='utf-8'),parse_constant=bad)
def require(ok,msg):
    if not ok:raise ValueError(msg)
def oracle(values,force=False,encoded_domain='float'):
    """Independent signed integer/frame oracle, no production helpers."""
    raw=[]
    for name in NAMES:
        v=float(values[name]);require(math.isfinite(v),'nonfinite '+name)
        scaled=v*65536;require(math.isfinite(scaled),'overflow '+name)
        n=round(scaled);require(-2**31<=n<2**31,'Q16 overflow '+name)
        lo,hi=LIMITS[name]
        if not force:
            require(lo<=v<=hi,'source range '+name)
            # Frozen UART protocol gives fx/fy integer upper bound 0x7fffffff;
            # calibrate explicitly rechecks decoded floats against 32767.99.
            # Keep both current contracts visible rather than invent equality.
            encoded_hi=(2**31-1)/65536 if encoded_domain=='wire' and name in ('fx','fy') else hi
            require(lo<=n/65536<=encoded_hi,'encoded range '+name)
        require(abs(n/65536-v)<=.5*LSB,'roundtrip '+name)
        raw.append(n)
    payload=struct.pack('<8i',*raw)
    return b'\xaa\x55\x01\x20'+payload+bytes([sum(payload)%256])
def decode_check(frame,values):
    require(len(frame)==37 and frame[:4]==b'\xaa\x55\x01\x20','frame shape')
    require(frame[-1]==sum(frame[4:-1])%256,'checksum')
    require(frame==oracle(values),'frame disagrees with independent oracle')

class Wire:
    def reset(self,mode='normal'):
        self.mode=mode;self.opens=[];self.writes=[];self.accepted=[];self.flushes=0
    def serial(self,**kw):
        require(kw.get('port')=='FAKE_ONLY','Real serial port forbidden')
        self.opens.append(kw)
        if self.mode=='open_error':raise OSError('INJECTED open failure')
        return self
    def __enter__(self):return self
    def __exit__(self,*a):return False
    def write(self,data):
        self.writes.append(bytes(data).hex())
        if self.mode=='write_error':raise OSError('INJECTED write failure')
        n=len(data)-1 if self.mode=='short' else len(data)
        self.accepted.append(n);return n
    def flush(self):
        self.flushes+=1
        if self.mode=='flush_error':raise OSError('INJECTED flush failure')
    def snapshot(self):return dict(opener_count=len(self.opens),open_args=self.opens,write_count=len(self.writes),writes_hex=self.writes,accepted_bytes=self.accepted,flush_count=self.flushes)

def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def cases():
    result=[]
    def add(id,kind,group,**kw):result.append(dict(case_id=id,kind=kind,group=group,**kw))
    for title,p in [('identity',dict(BASE,k1=0.,k2=0.,p1=0.,p2=0.)),('negative',BASE)]:
        add('valid_'+title,'cal','R03-01',params=p)
    for title in ['identity','real']:
        pth=REF/'parameters_reference/parameters'/f'{title}_parameters.csv'
        row=next(csv.DictReader(pth.open(encoding='utf-8-sig')))
        add('frozen_'+title,'cal','R03-01',params={n:float(row[n]) for n in NAMES},fixture_sha256=sha(pth))
    for name,(lo,hi) in LIMITS.items():
        for side,bound in [('lo',lo),('hi',hi)]:
            for label,delta in [('minus1',-1),('minus_half_out',-.500001),('minus_half',-.5),('zero',0),('plus_half',.5),('plus_half_out',.500001),('plus1',1)]:
                p=dict(BASE,**{name:bound+delta*LSB})
                for kind in ['cal','uart']:
                    add(f'{kind}_{name}_{side}_{label}',kind,'R03-03',params=p)
        for label,value in [('nan','nan'),('posinf','inf'),('neginf','-inf'),('huge','1e308'),('negative_huge','-1e308')]:
            p=dict(BASE,**{name:value})
            for kind in ['cal','uart']:
                add(f'{kind}_{name}_{label}',kind,'R03-02',params=p)
            add(f'force_{name}_{label}','uart','R03-07',params=p,force=True)
        for side,v in [('low',lo-1),('high',hi+1)]:
            add(f'force_{name}_{side}','uart','R03-07',params=dict(BASE,**{name:v}),force=True)
    for name in ['fx','fy','cx','cy']:
        add('missing_'+name,'uart','R03-04',params={k:v for k,v in BASE.items() if k!=name},reject=True)
    for label,txt in [('unknown','fx=1000,fy=980,cx=960,cy=540,z=1'),('badnumber','fx=oops,fy=980,cx=960,cy=540'),('empty',''),('missing_equals','fx1000'),('duplicate','fx=1000,fy=980,cx=960,cy=540,fx=1001')]:
        add('cli_'+label,'uart','R03-04',params=BASE,params_text=txt,reject=True)
    add('optional_defaults','uart','R03-04',params=dict(BASE,k1=0.,k2=0.,p1=0.,p2=0.),params_text='fx=1000,fy=980,cx=960,cy=540')
    header='fx,fy,cx,cy,k1,k2,p1,p2,a11,a12,a21,a22,tx,ty,aff_en,gamma_en'
    good='1000,980,960,540,-0.1,0.03,0.002,-0.001,1,0,0,1,0,0,0,0'
    for label,txt in [('empty',''),('header','wrong\n1'),('no_rows',header+'\n'),('columns',header+'\n1,2'),('number',header+'\n'+good.replace('1000','oops')),('flag',header+'\n'+good[:-1]+'2'),('second_bad',header+'\n'+good+'\n'+good.replace('1000','NaN'))]:
        add('csv_'+label,'uart','R03-04',params=BASE,csv=txt,reject=True)
    for scenario in ['empty_images','few_images','first_unreadable','first_size','first_no_corners','filtered_size','filtered_unreadable','filtered_corners','opencv_error','projection_error']:
        add('images_'+scenario,'cal','R03-05',params=BASE,scenario=scenario,reject=True)
    for scenario in ['few_images','first_unreadable','opencv_error']:
        add('stale_'+scenario,'cal','R03-06',params=BASE,scenario=scenario,reject=True,stale=True)
    for mode in ['short','write_error','flush_error','open_error']:
        add('serial_'+mode,'cal','R03-08',params=BASE,wire=mode,transport_failure=True)
    for corrupt in ['bad_json','missing_g02','false_g02','string_g02','missing_frame','bad_hex','checksum','truncated','wrong_header','wrong_params','nonfinite','missing_param','old_run','old_hash']:
        add('artifact_'+corrupt,'guard','R03-08',params=BASE,corrupt=corrupt,reject=True)
    add('synthetic_real_solver','cal','R03-10',params=BASE,scenario='real_solver')
    add('too_few_real_solver','cal','R03-09',params=BASE,scenario='few_real_solver',reject=True)
    return result

def invoke(fn,record,label,argv):
    out=io.StringIO();err=io.StringIO();exc=None;code=0
    with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
        try:
            rc=fn();code=0 if rc is None else int(rc)
        except SystemExit as e:code=e.code if isinstance(e.code,int) else 1;exc=repr(e)
        except Exception as e:code=1;exc=repr(e);traceback.print_exc(file=err)
    Path(label+'.stdout.log').write_text(out.getvalue(),encoding='utf-8')
    Path(label+'.stderr.log').write_text(err.getvalue(),encoding='utf-8')
    record.append(dict(entry=label,argv=argv,returncode=code,exception=exc,stdout=label+'.stdout.log',stderr=label+'.stderr.log'))
    return code

def consume(path,receipt,run_id,uart):
    """New TEST orchestration guard, not an existing production uploader."""
    require(receipt['run_id']==run_id,'stale run ID')
    require(receipt['calibration_returncode']==0 and receipt['fresh'],'failed/stale producer')
    require(path.is_file() and sha(path)==receipt['sha256'],'artifact hash mismatch')
    obj=strict_json(path)
    require(isinstance(obj,dict) and obj.get('g02_pass') is True,'g02_pass must be true')
    values={n:obj[n] for n in NAMES}
    frame=bytes.fromhex(obj['uart01_frame']);decode_check(frame,values)
    text=','.join(f'{n}={values[n]!r}' for n in NAMES)
    return uart.main(['send-0x01','--port','FAKE_ONLY','--params',text])

def worker(args):
    import numpy as np
    import cv2
    cv2.setNumThreads(1)
    sys.dont_write_bytecode=True
    wire=Wire();wire.reset()
    sys.modules['serial']=types.SimpleNamespace(Serial=wire.serial,SerialException=OSError,EIGHTBITS=8,PARITY_NONE='N',STOPBITS_ONE=1)
    def blocked(*a,**kw):raise RuntimeError('Hardware/network prohibited by offline harness')
    cv2.VideoCapture=blocked
    import socket
    socket.socket=blocked;socket.create_connection=blocked
    calpath=(REF/'current/host/calibration_tools/calibrate.py') if args.source=='reference' else ROOT/'candidate/calibrate.py'
    uartpath=(REF/'current/uart/uart_tool.py') if args.source=='reference' else ROOT/'candidate/uart_tool.py'
    cal=load(calpath,'r03_cal');uart=load(uartpath,'r03_uart')
    sources={str(p.relative_to(ROOT)):sha(p) for p in [calpath,uartpath,Path(__file__)]}
    output=Path(args.out).resolve();output.mkdir(parents=True,exist_ok=False)
    allcases=cases();dump(output/'cases.json',allcases)
    # Same 20-view numerical fixture as historical test_cv_paths.py. Real
    # projectPoints produces corners; real calibrateCamera solves only R03-10.
    K=np.array([[1000.,0,960.],[0,980.,540.],[0,0,1.]])
    dist=np.array([-.1,.03,.002,-.001,0.])
    obj=np.zeros((108,3),np.float32);obj[:,:2]=np.mgrid[0:12,0:9].T.reshape(-1,2)*.025
    views=[]
    for i in range(20):
        rv=np.array([-.25+.025*i,.18*math.sin(i),-.1+.01*i]);tv=np.array([-.18+.018*(i%5),-.13+.012*(i%4),.65+.018*i])
        views.append(cv2.projectPoints(obj,rv,tv,K,dist)[0].astype(np.float32))
    np.savez(output/'synthetic_corners.npz',corners=np.array(views),K=K,dist=dist)
    rows=[]
    origin=Path.cwd()
    for spec in allcases:
        work=output/spec['case_id'];work.mkdir();os.chdir(work)
        dump(work/'input.json',spec)
        record=[];wire.reset(spec.get('wire','normal'));issues=[];observations=[]
        p={n:float(v) for n,v in spec['params'].items()};force=spec.get('force',False)
        try:expected=oracle(p,force,'wire' if spec['kind']=='uart' else 'float');valid=True
        except (ValueError,KeyError,OverflowError):expected=None;valid=False
        if spec.get('reject'):valid=False
        row=dict(case_id=spec['case_id'],group=spec['group'],source=args.source,optimize=sys.flags.optimize,source_sha256=sources,encoded_domain='UART frozen integer domain' if spec['kind']=='uart' else 'calibrate current decoded-float guard',expected='EXPLICIT_FORCE_EXPECTED' if force and valid else 'ACCEPT' if valid else 'DEFAULT_REJECT',calls=record,issues=issues,observations=observations)
        try:
            if spec['kind']=='uart':
                txt=spec.get('params_text',','.join(f'{n}={v}' for n,v in spec['params'].items()))
                argv=['send-0x01','--port','FAKE_ONLY','--params',txt]
                if 'csv' in spec:
                    Path('input.csv').write_text(spec['csv'],encoding='utf-8');argv=['send-file','--port','FAKE_ONLY','--csv','input.csv']
                if force:argv+=['--force']
                rc=invoke(lambda:uart.main(argv),record,'uart',argv)
                row['injection']='serial module only; real UART main/parse/encode/send'
                if valid:
                    if rc!=0 or wire.writes!=[expected.hex()] or wire.accepted!=[37]:issues.append('legal/force frame not sent exactly once')
                elif rc==0 or wire.opens or wire.writes:issues.append('invalid CLI parameters reached serial or returned success')
            elif spec['kind']=='guard':
                row['injection']='result corruption into NEW test-only orchestration guard'
                artifact=Path('calib_result.json');data=dict(p,g02_pass=True,uart01_frame=oracle(p).hex())
                corrupt=spec['corrupt']
                if corrupt=='missing_g02':data.pop('g02_pass')
                if corrupt=='false_g02':data['g02_pass']=False
                if corrupt=='string_g02':data['g02_pass']='true'
                if corrupt=='missing_frame':data.pop('uart01_frame')
                if corrupt=='bad_hex':data['uart01_frame']='not hex'
                if corrupt=='checksum':data['uart01_frame']=data['uart01_frame'][:-2]+'00'
                if corrupt=='truncated':data['uart01_frame']=data['uart01_frame'][:-2]
                if corrupt=='wrong_header':data['uart01_frame']='00'+data['uart01_frame'][2:]
                if corrupt=='wrong_params':data['fx']=1001
                if corrupt=='nonfinite':data['fx']='nan'
                if corrupt=='missing_param':data.pop('fx')
                dump(artifact,data)
                if corrupt=='bad_json':artifact.write_text('{',encoding='utf-8')
                receipt=dict(run_id='old' if corrupt=='old_run' else spec['case_id'],calibration_returncode=0,fresh=True,sha256='0'*64 if corrupt=='old_hash' else sha(artifact))
                rc=invoke(lambda:consume(artifact,receipt,spec['case_id'],uart),record,'guard',['result',str(artifact)])
                if rc==0 or wire.opens or wire.writes:issues.append('corrupt result not rejected before serial')
            else:
                scenario=spec.get('scenario','injected')
                row['injection']='image/corner providers only; REAL OpenCV solver/projectPoints' if scenario in ['real_solver','few_real_solver'] else 'image/corner providers + calibrateCamera result + projectPoints; real main/G02/encode/write'
                image_dir=Path('images');image_dir.mkdir()
                count=0 if scenario=='empty_images' else 14 if scenario in ['few_images','few_real_solver'] else 20
                for i in range(count):(image_dir/f'{i:02d}.png').write_bytes(b'R03 SYNTHETIC PLACEHOLDER; not an image')
                cursor={'i':0};calls={'solver':0,'project':0}
                def imread(path,*a,**kw):
                    i=int(Path(path).stem);cursor['i']=i
                    if (scenario=='first_unreadable' and i==0) or (scenario=='filtered_unreadable' and i>=14):return None
                    shape=(720,1280,3) if (scenario=='first_size' and i==0) or (scenario=='filtered_size' and i>=14) else (1080,1920,3)
                    return np.broadcast_to(np.uint8(0),shape)
                def detect(gray,cb,*a,**kw):
                    # Invalid first input remains invalid; do not fake a corner
                    # success for None simply to produce an optimized-mode bug.
                    ok=gray is not None and tuple(cb)==(12,9) and not(scenario=='first_no_corners' and cursor['i']==0) and not(scenario=='filtered_corners' and cursor['i']>=14)
                    return ok,views[min(cursor['i'],19)].copy() if ok else None
                def solve(objs,imgs,size,mat,d0,flags):
                    calls['solver']+=1
                    if scenario=='opencv_error':raise cv2.error('INJECTED calibrateCamera failure')
                    if scenario in ['real_solver','few_real_solver']:return cv2.calibrateCamera(objs,imgs,size,mat,d0,flags=flags)
                    k=np.array([[p['fx'],0,p['cx']],[0,p['fy'],p['cy']],[0,0,1.]])
                    d=np.array([p['k1'],p['k2'],p['p1'],p['p2'],0.])
                    return .1,k,d,[np.zeros(3) for _ in imgs],[np.array([0.,0.,1.]) for _ in imgs]
                def project(*a,**kw):
                    calls['project']+=1
                    if scenario=='projection_error':raise cv2.error('INJECTED projectPoints failure')
                    if scenario in ['real_solver','few_real_solver']:return cv2.projectPoints(*a,**kw)
                    return views[(calls['project']-1)%20],None
                fakecv=types.SimpleNamespace(CALIB_FIX_K3=cv2.CALIB_FIX_K3,COLOR_BGR2GRAY=cv2.COLOR_BGR2GRAY,imread=imread,cvtColor=lambda x,c:x[:,:,0],findChessboardCornersSB=detect,calibrateCamera=solve,projectPoints=project)
                artifact=Path('calib_result.json');oldhash=None
                if spec.get('stale'):
                    # Genuine previous successful main() result in SAME directory.
                    current=scenario;scenario='injected'
                    for i in range(20):(image_dir/f'{i:02d}.png').write_bytes(b'R03 SYNTHETIC PLACEHOLDER')
                    with patch.object(cal,'cv2',fakecv),patch.object(sys,'argv',[str(calpath),'--dir','images']):
                        pre=invoke(cal.main,record,'previous_success',[str(calpath),'--dir','images'])
                    require(pre==0 and artifact.exists(),'stale fixture setup failed')
                    oldhash=sha(artifact);dump('previous_success_snapshot.json',strict_json(artifact))
                    scenario=current;calls={'solver':0,'project':0}
                    if scenario=='few_images':
                        for i in range(14,20):(image_dir/f'{i:02d}.png').unlink()
                with patch.object(cal,'cv2',fakecv),patch.object(sys,'argv',[str(calpath),'--dir','images']):
                    rc=invoke(cal.main,record,'calibrate',[str(calpath),'--dir','images'])
                fresh=artifact.exists() and (oldhash is None or sha(artifact)!=oldhash)
                row['solver_calls']=calls;row['stale_preserved']=bool(oldhash and artifact.exists() and sha(artifact)==oldhash)
                if row['stale_preserved']:observations.append('original successful output remains after failed invocation; run association guard blocks reuse')
                receipt=dict(run_id=spec['case_id'],calibration_returncode=rc,fresh=fresh,sha256=sha(artifact) if artifact.exists() else None)
                dump('invocation_receipt.json',receipt)
                produced=None
                if artifact.exists() and fresh:
                    try:produced=strict_json(artifact)
                    except ValueError as e:observations.append('diagnostic file is not strict JSON: '+str(e))
                if not valid:
                    if produced and (produced.get('g02_pass') is True or 'uart01_frame' in produced):issues.append('invalid calibration produced sendable success fields')
                    if scenario in ['few_images','few_real_solver','first_unreadable','first_size','first_no_corners','filtered_size','filtered_unreadable','filtered_corners','empty_images'] and calls['solver']:
                        issues.append('invalid image precondition reached solver (assert removed under -O)')
                elif rc!=0 or not produced or produced.get('g02_pass') is not True:issues.append('legal calibration did not produce success')
                if produced and produced.get('g02_pass') is True:
                    try:decode_check(bytes.fromhex(produced['uart01_frame']),{n:produced[n] for n in NAMES})
                    except Exception as e:issues.append('producer frame invalid: '+str(e))
                if scenario=='real_solver' and produced:
                    row['real_solver_metrics']={k:produced[k] for k in ['rms','dist_full','enc_roundtrip_max_lsb']}
                    if produced['rms']>=.01 or len(produced['dist_full'])!=5 or produced['dist_full'][4]!=0:issues.append('real synthetic solver numerical/k3 check failed')
                chain=invoke(lambda:consume(artifact,receipt,spec['case_id'],uart),record,'chain',['result',str(artifact)])
                if valid and not spec.get('transport_failure'):
                    correct=oracle({n:produced[n] for n in NAMES}) if produced and produced.get('g02_pass') is True else expected
                    if chain!=0 or wire.writes!=[correct.hex()] or wire.accepted!=[37]:issues.append('legal end-to-end chain failed')
                elif spec.get('transport_failure'):
                    if chain==0:issues.append('transport failure reported success')
                    if len(wire.opens)!=1 or len(wire.writes)!=(0 if spec['wire']=='open_error' else 1):issues.append('unexpected transport retry/open count')
                elif wire.opens or wire.writes:issues.append('invalid/stale calibration reached serial')
        except Exception as e:
            row['harness_exception']=repr(e);issues.append('HARNESS_ERROR');Path('harness_error.log').write_text(traceback.format_exc(),encoding='utf-8')
        row['serial']=wire.snapshot()
        row['status']='BLOCKED' if 'HARNESS_ERROR' in issues else 'FAIL' if issues else 'PASS'
        row['artifacts']=[dict(path=f.relative_to(work).as_posix(),sha256=sha(f),bytes=f.stat().st_size) for f in sorted(work.rglob('*')) if f.is_file()]
        dump(work/'result.json',row);rows.append(row)
        print(row['status'],spec['case_id'],flush=True)
        os.chdir(origin)
    summary=dict(source=args.source,optimize=sys.flags.optimize,environment=dict(python=sys.version,numpy=np.__version__,opencv=cv2.__version__),source_sha256=sources,counts={s:sum(r['status']==s for r in rows) for s in ['PASS','FAIL','BLOCKED','NOT_TESTED']},cases=rows)
    dump(output/'results.json',summary)
    return 2 if summary['counts']['BLOCKED'] else 1 if summary['counts']['FAIL'] else 0

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--offline',action='store_true',required=True);ap.add_argument('--out',required=True);ap.add_argument('--source',choices=['reference','candidate'],default='reference');ap.add_argument('--worker',action='store_true');a=ap.parse_args()
    if a.worker:return worker(a)
    out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=False)
    receipts=[];combined=[]
    for label,flags in [('normal',[]),('optimized',['-O'])]:
        cmd=[sys.executable,'-B',*flags,str(Path(__file__).resolve()),'--offline','--worker','--source',a.source,'--out',str(out/label)]
        with (out/(label+'.console.log')).open('wb') as log:
            run=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=600,env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1'))
        receipts.append(dict(argv=cmd,exit_code=run.returncode))
        if not (out/label/'results.json').exists():dump(out/'process_receipts.json',receipts);return 2
        summary=strict_json(out/label/'results.json');combined+=summary['cases']
        print(label,summary['counts'],flush=True)
    dump(out/'process_receipts.json',receipts)
    counts={s:sum(r['status']==s for r in combined) for s in ['PASS','FAIL','BLOCKED','NOT_TESTED']}
    dump(out/'summary.json',dict(source=a.source,counts=counts,groups={g:{s:sum(r['group']==g and r['status']==s for r in combined) for s in counts} for g in sorted({r['group'] for r in combined})},assert_mode_coverage='all cases run in normal and -O; covers R03-09',failures=[dict(case_id=r['case_id'],optimize=r['optimize'],status=r['status'],issues=r['issues'],exception=r.get('harness_exception')) for r in combined if r['status']!='PASS']))
    print('TOTAL',counts)
    return 2 if counts['BLOCKED'] else 1 if counts['FAIL'] else 0

if __name__=='__main__':sys.exit(main())
