"""Create isolated minimal candidates; never overwrite archived reference files."""
from pathlib import Path
import difflib, shutil

ROOT=Path(__file__).resolve().parents[1]
ref=ROOT/'reference/current'
cal=(ref/'host/calibration_tools/calibrate.py').read_text(encoding='utf-8-sig')
original_cal=cal
checks=[
    ("    assert len(files) >= 15, '标定图像不足 15 张，请先按采集 SOP 完成 20+ 张采集'", "    if len(files) < 15:\n        raise ValueError('标定图像不足 15 张，请先按采集 SOP 完成 20+ 张采集')"),
    ("    assert g0 is not None, '首张图不可读或非 1920x1080，不得用于标定（坐标系作废）'", "    if g0 is None:\n        raise ValueError('首张图不可读或非 1920x1080，不得用于标定（坐标系作废）')"),
    ("    assert CB is not None, f'首张图按 {cands} 均未检出棋盘，检查图像与标定板'", "    if CB is None:\n        raise ValueError(f'首张图按 {cands} 均未检出棋盘，检查图像与标定板')"),
    ("    assert len(used) >= 15, '有效张数不足 15，补拍（棋盘需完整、清晰、无反光）'", "    if len(used) < 15:\n        raise ValueError('有效张数不足 15，补拍（棋盘需完整、清晰、无反光）')"),
    ("        assert enc_chk[nm] <= 0.5 / 65536.0, f'{nm} 量化往返误差超 0.5 LSB'", "        if not enc_chk[nm] <= 0.5 / 65536.0:\n            raise ValueError(f'{nm} 量化往返误差超 0.5 LSB')"),
    ("    assert not g02_violations({n: q16_dec(q16_16(p[n])) for n in names}), \\\n        '量化后参数越出 G02 域，禁止发送'", "    if g02_violations({n: q16_dec(q16_16(p[n])) for n in names}):\n        raise ValueError('量化后参数越出 G02 域，禁止发送')"),
]
for before,after in checks:
    if cal.count(before)!=1:raise RuntimeError('Unexpected calibrate source: '+before)
    cal=cal.replace(before,after)
target=ROOT/'candidate'
if target.exists() and any(target.iterdir()):raise RuntimeError('Candidate directory must be empty')
shutil.copytree(ref/'uart',target,dirs_exist_ok=True)
(target/'calibrate.py').write_text(cal,encoding='utf-8')
(target/'calibrate.py.diff').write_text(''.join(difflib.unified_diff(original_cal.splitlines(True),cal.splitlines(True),fromfile='reference/calibrate.py',tofile='candidate/calibrate.py')),encoding='utf-8')
print('Candidate calibrate uses explicit checks; UART and its selftests are unchanged.')
