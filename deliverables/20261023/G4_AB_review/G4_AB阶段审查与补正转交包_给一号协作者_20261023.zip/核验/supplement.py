from pathlib import Path
import hashlib,json,shutil,subprocess,sys
W=Path(__file__).resolve().parent;R=W/'extracted/G4_AB_candidate_20261022'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
G=W/'generator_reproduction';G.mkdir(exist_ok=True)
for rel in ['build_candidate_sources.py','reference/undistort_core.v','reference/undistort_line_cache_tb.v']:
 dst=G/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,dst)
(G/'source/rtl').mkdir(parents=True,exist_ok=True);(G/'sim').mkdir(exist_ok=True)
p=subprocess.run([sys.executable,str(G/'build_candidate_sources.py')],cwd=G,capture_output=True,encoding='utf-8')
out=dict(generator_exit=p.returncode,generator_stdout=p.stdout,generator_stderr=p.stderr,
 generator_outputs={n:dict(incoming=sha(R/n),regenerated=sha(G/n),byte_equal=sha(R/n)==sha(G/n)) for n in ['source/rtl/undistort_core.v','sim/cache72_ab_tb.v']},
 host_core_copies={n:sha(R/'source/rtl'/n)==sha(R/'host_ab/source/rtl'/n) for n in ['undistort_core.v','undistort_map.v','undistort_bilinear.v','undistort_cache_ab.v']},
 fdc_ab_g4_byte_equal=sha(R/'host_ab/HDMI_DDR3_OV5640_test.fdc')==sha(R/'host_g4/HDMI_DDR3_OV5640_test.fdc'),
 fps={str(c):125000000/c for c in [4147487,4147519,4161845,4147513]},
 stress_margin_to_30fps_cycles=125000000/30-4161845,
 stress_margin_percent=(125000000/30-4161845)/(125000000/30)*100)
(W/'supplemental_checks.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
