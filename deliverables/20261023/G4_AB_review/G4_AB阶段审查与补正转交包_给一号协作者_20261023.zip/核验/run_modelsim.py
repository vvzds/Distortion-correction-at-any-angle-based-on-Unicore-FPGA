"""Independent ModelSim runner; never edits received source or historical evidence."""
from pathlib import Path
import json,hashlib,subprocess,time,sys,re,shutil
W=Path(__file__).resolve().parent; R=W/'extracted/G4_AB_candidate_20261022'
OUT=W/'modelsim_final';OUT.mkdir(exist_ok=True)
TOOL=Path('D:/FPGA/MODELSIM/win64')
tops={'cache72':'undistort_line_cache_tb','segment':'segment_cache_tb','mode_switch':'cache_mode_switch_tb','c6_display':'c6_display_bridge_tb','c6_host_arb':'c6_host_arb_tb','real_v7':'calibration_core_ab_tb','real_v7_resume_stress':'calibration_core_ab_tb','identity_v7_resume':'calibration_core_ab_tb','legacy_sim':'undistort_core_sim_tb','integration_v7_resume':'corr_top_tb','c6_real_subsystem_v2':'c6_real_subsystem_tb'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,cwd,log,timeout=1800):
 start=time.time()
 with log.open('wb') as f:
  try:p=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=timeout);code=p.returncode
  except subprocess.TimeoutExpired:code=124
 return dict(command=[str(a) for a in args],exit_code=code,elapsed_seconds=round(time.time()-start,3),log=str(log))
for case in sys.argv[1:]:
 out=OUT/case;out.mkdir(exist_ok=True)
 if (out/'result.json').exists():raise RuntimeError('Do not overwrite prior run '+case)
 inp=json.loads((R/f'reports/{case}.inputs.json').read_text(encoding='utf-8-sig'))
 files=[R/s['file'].replace('\\','/').split('G4_AB_candidate_20261022/')[1] for s in inp['sources']]
 compilefiles=[p for p in files if p.suffix=='.v']
 anchored=list(dict.fromkeys(files+list((R/'verification_data').rglob('*'))+list((R/'host_ab/source/rtl').glob('*.vh'))))
 hashes=[dict(file=p.relative_to(R).as_posix(),sha256=sha(p)) for p in anchored if p.is_file()]
 (out/'inputs.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
 steps=[]
 steps.append(run([TOOL/'vlib.exe',out/'work'],out,out/'vlib.log',60))
 for kind in ['rtl','tb']:
  selected=[p for p in compilefiles if (p.name.endswith('_tb.v'))==(kind=='tb')]
  cmd=[TOOL/'vlog.exe']+(['-sv'] if kind=='tb' else [])+['-work',out/'work','+incdir+'+(R/'verification_data').as_posix(),'+incdir+'+(R/'host_ab').as_posix()]+selected
  if selected:steps.append(run(cmd,out,out/f'compile_{kind}.log',120))
 if any(s['exit_code'] for s in steps):
  (out/'result.json').write_text(json.dumps(dict(pass_=False,steps=steps),indent=2));print(case,'COMPILE_FAIL',flush=True);continue
 args=[]
 if case in ['real_v7','real_v7_resume_stress','identity_v7_resume']:
  mode=int(not case.startswith('identity'));args=[f'+MODE={mode}','+PATTERN=1','+SLOT=3','+VECTOR=vectors/'+('real_pixels_1.hex' if mode else 'identity_pixels.hex')]
  if case.endswith('_stress'):args+=['+LATENCY=64','+PERIOD=2','+GRANT=32','+GATE=1']
 do=out/'run.do'
 if case not in ['cache72','segment','mode_switch','c6_display','legacy_sim','integration_v7_resume']:
  shutil.copytree(R/'verification_data/vectors',out/'vectors')
 do.write_text('onerror {quit -code 2 -f}\nonbreak {quit -code 0 -f}\nrun -all\nquit -code 0 -f\n',encoding='ascii')
 cmd=[TOOL/'vsim.exe','-c','-onfinish','stop','-voptargs=+acc','work.'+tops[case],'-l',out/'transcript.log','-wlf',out/'wave.wlf','-do',do]+args
 print('START',case,flush=True)
 steps.append(run(cmd,out,out/'console.log'))
 body=(out/'console.log').read_text(encoding='utf-8',errors='replace')
 passlines=[l for l in body.splitlines() if re.search(r'PASS|PASSED',l)]
 bad=re.findall(r'\b(?:Fatal|Error|FATAL|FAIL|FAILED|TIMEOUT|MISMATCH|ERROR)\b',body)
 # $finish triggers onbreak. Never use exit status alone: require the final TB marker and no errors.
 marker={'cache72':'ALL TESTS PASSED (err=0)','segment':'SEGMENT_CACHE PASS cache72=72','mode_switch':'CACHE_MODE_SWITCH PASS checks=10','c6_display':'C6_DISPLAY_BRIDGE PASS correction_txn=130084','c6_host_arb':'C6_HOST_ARB PASS','real_v7':'CORE PASS','real_v7_resume_stress':'CORE PASS','identity_v7_resume':'CORE PASS','legacy_sim':'ALL TESTS PASSED (err=0)','integration_v7_resume':'ALL TESTS PASSED (err=0)','c6_real_subsystem_v2':'C6_REAL_SUBSYSTEM PASS'}[case]
 finished='$finish' in body and marker in body
 ok=steps[-1]['exit_code']==0 and finished and not bad
 result=dict(case=case,pass_=ok,steps=steps,pass_lines=passlines,bad_tokens=bad,finish_seen=finished,inputs_unchanged=all(sha(R/e['file'])==e['sha256'] for e in hashes))
 (out/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(case,'PASS' if ok else 'FAIL',steps[-1]['elapsed_seconds'],passlines,flush=True)
