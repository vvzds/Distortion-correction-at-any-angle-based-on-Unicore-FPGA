from pathlib import Path
import hashlib,json,re,difflib
W=Path(__file__).resolve().parent
R=W/'extracted/G4_AB_candidate_20261022'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
checks=[]
for e in read(R/'package_manifest.json'):
 p=R/e['file'];checks.append(dict(file=e['file'],ok=p.exists() and p.stat().st_size==e['bytes'] and sha(p)==e['sha256']))
tracked={e['file'] for e in checks}
extras=[p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file() and p.relative_to(R).as_posix() not in tracked]
tests={}
for case in read(R/'reports/current_evidence.json')['tests']:
 inp=read(R/f'reports/{case}.inputs.json');result=read(R/f'reports/{case}.result.json')
 rows=[]
 for src in inp['sources']:
  rel=src['file'].replace('\\','/').split('G4_AB_candidate_20261022/')[1]
  rows.append(dict(file=rel,match=sha(R/rel)==src['sha256']))
 body=(R/f'logs/{case}.log').read_text(encoding='utf-8-sig')
 tests[case]=dict(input_rows=rows,result=result,pass_lines=[l for l in body.splitlines() if re.search(r'PASS|PASSED',l)],bad_tokens=re.findall(r'\b(?:FATAL|FAIL|FAILED|TIMEOUT|MISMATCH|ERROR)\b',body))
synth={}
for case in ['pds_v7','host_ab_synth_20261023']:
 obj=read(R/f'reports/{case}.inputs.json');rows=obj if isinstance(obj,list) else obj['sources'];out=[]
 for src in rows:
  name=src.get('file',src.get('Path')).replace('\\','/')
  rel=name.split('G4_AB_candidate_20261022/')[-1]
  if case.startswith('host'):rel='host_ab/'+rel
  p=R/rel
  out.append(dict(file=rel,exists=p.exists(),match=p.exists() and sha(p)==src.get('sha256',src.get('Hash'))))
 synth[case]=out
baseline=[]
for name in ['undistort_core.v','undistort_map.v','undistort_bilinear.v','undistort_line_cache.v']:
 old=Path('D:/oss_repo_20261020/source/rtl')/name
 new=R/('reference' if name in ['undistort_core.v','undistort_line_cache.v'] else 'source/rtl')/name
 baseline.append(dict(file=name,baseline=sha(old),incoming=sha(new),match=sha(old)==sha(new)))
prior=read(R/'verification_data/prior_reference_reports/inputs_sha256.json')
vectors=[]
for p in (R/'verification_data').rglob('*'):
 if p.is_file() and 'prior_reference_reports' not in p.parts:
  rel=p.relative_to(R/'verification_data').as_posix()
  vectors.append(dict(file=rel,sha256=sha(p),prior_hash=prior.get(rel),prior_match=sha(p)==prior[rel] if rel in prior else None))
enc=read(R/'verification_data/parameters/parameter_encoding.json')
frame=(R/'verification_data/parameters/real_0x01.bin').read_bytes()
hexframe=bytes.fromhex((R/'verification_data/vectors/real_uart_bytes.hex').read_text())
params=[int.from_bytes(frame[4+i*4:8+i*4],'little',signed=True) for i in range(8)]
uart=dict(length=len(frame),checksum=hex(frame[-1]),checksum_valid=sum(frame[4:36])%256==frame[-1],vectors_match=frame==hexframe,parameters_match=params==[e['signed_integer'] for e in enc['parameters']])
out=dict(manifest_count=len(checks),manifest_failures=[e for e in checks if not e['ok']],unlisted=extras,tests=tests,synthesis=synth,baseline=baseline,vectors=vectors,uart=uart)
(W/'static_audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
for name in ['undistort_core.v','undistort_map.v','undistort_bilinear.v']:
 a=Path('D:/oss_repo_20261020/source/rtl')/name;b=R/'source/rtl'/name
 diff=''.join(difflib.unified_diff(a.read_text(encoding='utf-8-sig').splitlines(True),b.read_text(encoding='utf-8-sig').splitlines(True),fromfile='G4/'+name,tofile='AB/'+name))
 (W/(name+'.diff')).write_text(diff,encoding='utf-8')
print(json.dumps(dict(manifest_count=len(checks),manifest_failures=out['manifest_failures'],unlisted=extras,tests={k:dict(inputs=len(v['input_rows']),mismatches=[x for x in v['input_rows'] if not x['match']],pass_lines=v['pass_lines'],bad=v['bad_tokens']) for k,v in tests.items()},synthesis={k:dict(count=len(v),failures=[x for x in v if not x['match']]) for k,v in synth.items()},baseline=baseline,vector_prior_mismatches=[v for v in vectors if v['prior_match'] is False],uart=uart),ensure_ascii=False,indent=2))
