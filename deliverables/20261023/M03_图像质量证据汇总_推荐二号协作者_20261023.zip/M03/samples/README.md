模板null为待填写，不是可通过输入。合成斜边/平坦/渐变与独立历史预期见historical_reviews/e8/synthetic及日志；真实素材目前未提供，必须NOT_TESTED。
