# M03 图像质量证据汇总与可比性检查：制作任务书

推荐二号协作者。复用已审查 capture、linearity 与 E8 mtf50，新增批处理/来源/可比性检查和报告；不新造 MTF/直线度计算公式，不重写 affine_track。

## 输入与候选接口

候选命令：`python implementation/quality_report.py --manifest samples/session_template.json --out results/quality`（待实现）。先支持本地离线文件；采图继续用现有 capture，不自动开启设备。每张图保留原始字节、相对路径、SHA256、尺寸、采集时间/时区、evidence_kind（SYNTHETIC/REAL_CAPTURE），参数与位流哈希可为空但必须标缺项。

session_template.json 是输入结构示例，图片 null 表示待采集，不能作为已存在输入或通过证据。实际合成图见 historical_reviews/e8/synthetic，几百像素只用于工具回归，不满足真实1080p输入。Host_review/synthetic/calibration 内的 .png 多为替身占位字节，不可当图。

每对 before/after 含对应实验模式、相机/镜头/焦距/曝光/白平衡/对焦、HDMI与采集分辨率、图卡/姿态、拍摄批次、Gamma/affine状态、实参来源、ROI列表和对应关系说明。几何变换会改变目标坐标，不能盲用同一像素框；前后 ROI 必须确认同一物理刃/直线。静止场景才能做顺序采集对比，不能把时间邻近当同步。

## 必须实现的行为

1. 预检清单、文件可读性、大小/hash、实际解码尺寸、ROI边界，拒绝路径越过材料根；重复图/相同hash提示，不宣称改进；缺标定原图等只列 MISSING，不补造。
2. 按图片/ROI调用现有 CLI，记录准确 argv、工具哈希、依赖版本、工作目录、stdout/stderr、退出码。MTF 每次写固定 mtf_curve.csv，故每次独立目录，随后按图/ROI保存曲线，禁止覆盖前一测量。
3. E8 exit2=读图/输入类失败，exit3=无有效测量；原始异常原样保存。linearity 在无有效线时可能 exit0 但无数值，必须判 INVALID，不可填0。NaN/Inf/缺字段都不能成为有效指标。缺图像时不得触发一堆假测量。
4. 输出 report.md + results.json + assets_manifest.csv + 原始 logs/curves。报告分“输入完整性”“测量是否有效”“前后是否可比”“质量是否满足已批准门槛”；四者不能共用一个 all_pass。
5. 默认不自动判定图像质量合格，quality_acceptance=NOT_EVALUATED。人工 SOP 的1–2px/RMS等原文随附，但不是本包新增正式门槛；如用户提供门槛，必须记录来源/版本/适用域，不自行把两倍模糊/15%极性测试阈值用于真实质量签收。
6. 合成图每处显示 SYNTHETIC，真实数据不得用未证实的仿真/估计参数冒充生效；params_valid=1 不足以证明某组生效。没拿到真实校正前后帧，board_quality_status=NOT_TESTED。冻结 FPGA 参数包只证明参数编码来源，不证明实际画面使用了该组。

## 验收矩阵

| ID | 覆盖 | 预期 |
|---|---|---|
| Q01 | E8 同版两种模糊度、双极性合成斜边 | 原有15/15回归维持；汇总值与原始CLI一致，证据标SYNTHETIC |
| Q02 | 平坦/渐变/坏图/不存在/越界ROI | INVALID或MISSING，保留exit/log，不输出伪MTF0 |
| Q03 | 无长直线/有效覆盖不足 | 即使工具exit0仍无有效直线结论，不填0px |
| Q04 | 两个ROI连续执行、重复输入与既有结果目录 | 曲线互不覆盖；输入原字节不变；重复检测与输出覆盖策略明确 |
| Q05 | 真实标签但非1920×1080、前后比例/曝光/靶标不同 | 明确不可比，仍保留数据；不自动缩放到1080p掩盖问题 |
| Q06 | 元数据缺失、哈希不符、ROI对应未知、位流/参数未证实 | 证据不完整/不可比；禁止全局通过 |
| Q07 | 中文/带空格路径、非法manifest、路径逃逸、工具失败 | 无无声跳过；安全临时英文工作目录仅可复制且保存原始路径/hash映射；不变更图像内容 |
| Q08 | 同一清单重复运行 | 除运行时间外结果稳定；所有数值可回溯到命令/工具/图片 |
| Q09 | 可选完整真实板测资料 | 人工评审单列；无资料明确NOT_TESTED；只完成软件不冒领实拍验收 |

## 交付物

implementation 源码/测试；输入 schema 与填写范例；至少一份合成正向和失败报告；机读矩阵；引用工具的哈希与依赖；原始CLI日志/曲线；真实证据缺件表。历史 E8 审查与旧 test_e8_independent 可作依据，不能把历史日志标成本次运行。不要为做报告而重新标定或改既有参数。

待您转交：二号协作者；若无错误不进行回复。

本次工作主要由 GPT-6 模型完成。
