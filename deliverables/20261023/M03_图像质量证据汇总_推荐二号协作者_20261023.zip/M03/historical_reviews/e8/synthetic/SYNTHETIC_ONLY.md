# SYNTHETIC ONLY

All images here are software-generated fixtures, not camera/calibration evidence.
