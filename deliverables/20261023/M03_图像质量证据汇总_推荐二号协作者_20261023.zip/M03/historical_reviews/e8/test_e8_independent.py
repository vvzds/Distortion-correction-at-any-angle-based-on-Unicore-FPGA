"""Run byte-exact E8 scripts and independent synthetic CLI cases; no hardware."""
from pathlib import Path
import hashlib
import json
import os
import re
import runpy
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
DEPS=ROOT.parent/'host_validation_deps'
sys.path.insert(0,str(DEPS))
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')
import cv2
import numpy as np

TOOL=ROOT/'incoming/calibration_tools/mtf50.py'
TEST=ROOT/'incoming/test_mtf50_e8.py'
OUT=ROOT/'synthetic'
OUT.mkdir(exist_ok=True)
(OUT/'SYNTHETIC_ONLY.md').write_text('# SYNTHETIC ONLY\n\nAll images here are software-generated fixtures, not camera/calibration evidence.\n',encoding='utf-8')
env=os.environ.copy()
env.update(PYTHONPATH=str(DEPS),PYTHONIOENCODING='utf-8',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
expected={
    'calibration_tools/mtf50.py':'157E32EFD266F1155AADC42439B0E1A30A6DFC76D88497827CD6B9359BC905D7',
    'test_mtf50_e8.py':'2E5960E9CFC256E150B889EF808CA49E68CF53FC021EF4E1FE3114BAA6C0CB2D',
    'selftest_e8_console_20261019.log':'8EDFA48E5078209329B776CBDE64BC402E25C6907320DD784C7FAC79BBA72413',
}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
for name,digest in expected.items():assert sha(ROOT/'incoming'/name)==digest
before={p.relative_to(ROOT/'incoming').as_posix():sha(p) for p in (ROOT/'incoming').rglob('*') if p.is_file()}
results=[]
def record(name,ok,**detail):
    row={'test':name,'pass':bool(ok),**detail}
    results.append(row)
    print(('PASS ' if ok else 'FAIL ')+name+': '+json.dumps(detail,ensure_ascii=False),flush=True)

def run(args,cwd,logname):
    p=subprocess.run([sys.executable,'-B',*map(str,args)],cwd=cwd,env=env,
                     stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
    text=p.stdout.decode('utf-8',errors='replace')
    (ROOT/logname).write_text(text,encoding='utf-8')
    return p.returncode,text

# First run as delivered, keeping environmental failures visible.
native=ROOT/'original_selftest_native';native.mkdir(exist_ok=True)
rc,text=run([TEST],native,'original_selftest_native.log')
record('original_selftest_native_environment',rc==0 and '15/15 PASS' in text and len(re.findall(r'^PASS ',text,re.M))==15,
       exit_code=rc,note='May fail on sandbox tempfile ACL or non-ASCII OpenCV path; see raw log.')
# Same unmodified selftest, only an isolated fixture directory provider differs.
compat=ROOT/'original_selftest_compat';compat.mkdir(exist_ok=True)
launcher=compat/'launch_fixture_compat.py'
launcher.write_text('import runpy,sys,tempfile\n'
                    '# Dedicated empty working directory; relative fixture paths avoid OpenCV Unicode path issue.\n'
                    'tempfile.mkdtemp=lambda *a,**k: "."\n'
                    'runpy.run_path(sys.argv[1],run_name="__main__")\n',encoding='ascii')
rc,text=run([launcher,TEST],compat,'original_selftest_fixture_compat.log')
record('original_selftest_fixture_compat',rc==0 and '15/15 PASS' in text and len(re.findall(r'^PASS ',text,re.M))==15,
       exit_code=rc,note='Only tempfile fixture path provider changed; incoming test/tool bytes unchanged.')

def save(name,image):
    ok,b=cv2.imencode('.png',image)
    assert ok
    (OUT/name).write_bytes(b.tobytes())

yy,xx=np.mgrid[:384,:384].astype(float)
values={}
for angle in (5,10,15):
    for sigma in (1.,3.):
        for polarity in (0,1):
            d=(xx-192)*np.cos(np.deg2rad(angle))+(yy-192)*np.sin(np.deg2rad(angle))
            g=np.where(d>=0,255.,0.)
            g=cv2.GaussianBlur(g,(0,0),sigma)
            if polarity:g=255-g
            name='edge_a%d_s%d_p%d.png'%(angle,sigma,polarity)
            save(name,np.clip(g,0,255).astype(np.uint8))
            rc,text=run([TOOL,name,'--roi',80,80,224,224],OUT,'cli_'+name+'.log')
            m=re.search(r'^MTF50 = ([\d.]+) cy/px',text,re.M)
            value=float(m.group(1)) if m else None
            values[(angle,sigma,polarity)]=value
            curve=OUT/'mtf_curve.csv'
            valid_curve=False
            if rc==0 and curve.exists():
                a=np.loadtxt(curve,delimiter=',',skiprows=1)
                valid_curve=np.isfinite(a).all() and np.all(np.diff(a[:,0])>0) and a[0,1]==1
                curve.rename(OUT/(name+'.curve.csv'))
            record('CLI_'+name,rc==0 and value is not None and value>0 and valid_curve,
                   exit_code=rc,mtf50=value,finite_curve=bool(valid_curve),synthetic=True)
for angle in (5,10,15):
    for polarity in (0,1):
        a,b=values[(angle,1.,polarity)],values[(angle,3.,polarity)]
        record('blur_order_a%d_p%d'%(angle,polarity),a is not None and b is not None and b<a,
               sigma1=a,sigma3=b)
    a,b=values[(angle,1.,0)],values[(angle,1.,1)]
    record('polarity_a%d'%angle,a is not None and b is not None and abs(a-b)/max(a,b)<.15,
           positive=a,negative=b)

save('flat.png',np.full((384,384),128,np.uint8))
save('sparse_dot.png',np.pad(np.array([[255]],dtype=np.uint8),((191,192),(191,192))))
save('linear_ramp.png',np.tile(np.arange(256,dtype=np.uint8),(256,1)))
save('linear_ramp_vertical.png',np.tile(np.arange(256,dtype=np.uint8)[:,None],(1,256)))
(OUT/'corrupt.png').write_bytes(b'not an image')
cases=[('flat','flat.png',(80,80,224,224),3),
       ('sparse_gradient','sparse_dot.png',(80,80,224,224),3),
       ('out_of_bounds','edge_a10_s1_p0.png',(300,300,224,224),3),
       ('negative_origin','edge_a10_s1_p0.png',(-1,1,128,128),3),
       ('zero_width','flat.png',(0,0,0,128),3),
       ('negative_height','flat.png',(0,0,128,-1),3),
       ('small_roi','flat.png',(0,0,63,63),3),
       ('missing','missing.png',(0,0,128,128),2),
       ('corrupt_image','corrupt.png',(0,0,128,128),2),
       ('uniform_gradient_ramp','linear_ramp.png',(32,32,192,192),3),
       ('uniform_gradient_ramp_vertical','linear_ramp_vertical.png',(32,32,192,192),3)]
for name,img,roi,code in cases:
    rc,text=run([TOOL,img,'--roi',*roi],OUT,'cli_invalid_'+name+'.log')
    no_measurement=re.search(r'^MTF50\s*=',text,re.M) is None
    record(name,rc==code and no_measurement and 'Traceback' not in text and '无有效测量:' in text,
           exit_code=rc,expected_exit=code,no_measurement=no_measurement,output=text.strip())

# Unicode path is accepted or explicitly rejected with exit2, never a traceback.
unicode_dir=OUT/'中文图像';unicode_dir.mkdir(exist_ok=True)
(unicode_dir/'斜边.png').write_bytes((OUT/'edge_a10_s1_p0.png').read_bytes())
rc,text=run([TOOL,str(unicode_dir/'斜边.png'),'--roi',80,80,224,224],OUT,'cli_unicode_path.log')
record('unicode_path_controlled_result',rc in (0,2) and 'Traceback' not in text,
       exit_code=rc,note='Exit2 is an explicit read rejection, not Unicode read support.',output=text.strip())
# Compare all twelve numeric results with the independently run E7 baseline.
prior=ROOT/'references'
old=json.loads((prior/'e7_test_results.json').read_text(encoding='utf-8'))
old_values={r['test']:r['mtf50'] for r in old['results'] if r['test'].startswith('CLI_')}
for (angle,sigma,polarity),value in values.items():
    name='CLI_edge_a%d_s%d_p%d.png'%(angle,sigma,polarity)
    record('unchanged_vs_E7_'+name,value==old_values[name],e8=value,e7=old_values[name])
# Reuse original E7 counterexample bytes, not only regenerated equivalents.
for name in ('linear_ramp.png','linear_ramp_vertical.png'):
    original=prior/'synthetic'/name
    assert original.read_bytes()==(OUT/name).read_bytes()
    # Read through a relative name; retain its prior-source SHA256.
    import shutil
    shutil.copy2(original,OUT/('original_'+name))
    rc,text=run([TOOL,'original_'+name,'--roi',32,32,192,192],OUT,'cli_original_'+name+'.log')
    record('E7_original_'+name,rc==3 and '无有效测量:' in text and 'Traceback' not in text and re.search(r'^MTF50\s*=',text,re.M) is None,
           exit_code=rc,source_sha256=sha(original),output=text.strip())

after={p.relative_to(ROOT/'incoming').as_posix():sha(p) for p in (ROOT/'incoming').rglob('*') if p.is_file()}
record('incoming_byte_immutable',before==after,files=len(before))
summary={'environment':{'python':sys.version,'cv2':cv2.__version__,'numpy':np.__version__},
         'synthetic_only':True,'results':results,
         'all_pass':all(r['pass'] for r in results if r['test']!='original_selftest_native_environment')}
(ROOT/'e8_test_results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print('E8 independent acceptance:',summary['all_pass'],flush=True)
sys.exit(0 if summary['all_pass'] else 1)
