import runpy,sys,tempfile
# Dedicated empty working directory; relative fixture paths avoid OpenCV Unicode path issue.
tempfile.mkdtemp=lambda *a,**k: "."
runpy.run_path(sys.argv[1],run_name="__main__")
