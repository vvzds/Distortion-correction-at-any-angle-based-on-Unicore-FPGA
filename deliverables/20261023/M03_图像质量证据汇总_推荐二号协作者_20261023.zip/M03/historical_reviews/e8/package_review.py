"""Collect E8/V1.5 evidence and verify every file in the resulting ZIP."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parent
def sha(data):return hashlib.sha256(data).hexdigest().upper()

source=Path(r'C:\Users\叶翔\xwechat_files\wxid_qanrp2aqlq8h22_bb90\msg\file\2026-10\模块分工与工作包交付总说明_v1.5(1).md')
shutil.copy2(source,ROOT/'raw'/source.name)
assert source.read_bytes()==(ROOT/'raw'/source.name).read_bytes()
ref=ROOT/'references'
ref.mkdir(exist_ok=True)
old=ROOT.parent/'e7_g5_review_20261019'
for name in ('e7_test_results.json','test_e7_independent.py','E7_修订复核回复_二号_20261019.md','G5_SP64_接收复核回复_二号_20261019.md'):
 shutil.copy2(old/name,ref/name)
for name in ('linear_ramp.png','linear_ramp_vertical.png'):
 (ref/'synthetic').mkdir(exist_ok=True)
 shutil.copy2(old/'synthetic'/name,ref/'synthetic'/name)
shutil.copytree(old/'e7_incoming',ref/'e7_incoming',dirs_exist_ok=True)
driver=ROOT/'test_e8_independent.py'
s=driver.read_text(encoding='utf-8')
s=s.replace("prior=ROOT.parent/'e7_g5_review_20261019'","prior=ROOT/'references'")
driver.write_text(s,encoding='utf-8')
ast.parse(s)
# Only relocated the byte-identical baseline; no test or expected value changed.
assert (ref/'e7_test_results.json').read_bytes()==(old/'e7_test_results.json').read_bytes()
r=json.loads((ROOT/'e8_test_results.json').read_text(encoding='utf-8'))
assert len(r['results'])==50 and r['all_pass']
bad=[x['test'] for x in r['results'] if not x['pass']]
assert bad==['original_selftest_native_environment']
assert sum(x['pass'] for x in r['results'])==49
assert len([x for x in r['results'] if x['test'].startswith('unchanged_vs_E7_')])==12
compat=(ROOT/'original_selftest_fixture_compat.log').read_text(encoding='utf-8')
assert sum(line.startswith('PASS ') for line in compat.splitlines())==15 and '15/15 PASS' in compat
subprocess.run([sys.executable,str(ROOT/'verify_receipt.py')],check=True)
(ROOT/'README.md').write_text('''# E8 独立复跑与 V1.5 接收复核

先读 `E8_复跑与V1.5接收回复_二号_20261019.md`。

结论：49/49非环境记录通过；另保留1条原自测Temp权限环境失败。夹具适配自测实际15/15通过。R06已登记软件缺陷可闭环，实拍计量验收不在本次范围。

完整证据含原件、CLI日志、合成图与曲线、独立驱动、前轮基线及哈希清单。没有RTL、PDS工程或位流改动。

复跑依赖既有Python/numpy/OpenCV，独立驱动DEPS默认相邻host_validation_deps；迁移环境时按实际位置调整依赖路径。产品与原自测不改动；兼容自测只改变临时夹具目录提供器。

驱动完成后运行 `verify_receipt.py` 检查E8原件。打包脚本保留原接收位置用于本机归档；移机验证回件只需逐行检查MANIFEST_SHA256.tsv，不必重走接收步骤。
''',encoding='utf-8')
mf=ROOT/'MANIFEST_SHA256.tsv'
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and p!=mf and '__pycache__' not in p.parts)
rows=[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]
with mf.open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['path','bytes','sha256'],delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
target=ROOT.parents[1]/'E8_V15_review_20261019.zip'
assert not target.exists(), 'Do not overwrite delivery'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[mf]:z.write(p,'E8_V15_review_20261019/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None and len(z.namelist())==len(rows)+1
 for row in rows:
  data=z.read('E8_V15_review_20261019/'+row['path'])
  assert len(data)==row['bytes'] and sha(data)==row['sha256']
digest=sha(target.read_bytes())
target.with_suffix('.zip.sha256').write_text(digest+'  '+target.name+'\n',encoding='ascii')
print(json.dumps({'zip':str(target),'bytes':target.stat().st_size,'sha256':digest,'manifest_rows':len(rows),'verified':True},ensure_ascii=False,indent=2))
