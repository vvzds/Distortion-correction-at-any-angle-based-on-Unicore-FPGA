"""Verify delivered E8 bytes and declared source hashes without executing them."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parent
EXPECTED={
 'calibration_tools/mtf50.py':(8854,'157E32EFD266F1155AADC42439B0E1A30A6DFC76D88497827CD6B9359BC905D7'),
 'test_mtf50_e8.py':(5672,'2E5960E9CFC256E150B889EF808CA49E68CF53FC021EF4E1FE3114BAA6C0CB2D'),
 'selftest_e8_console_20261019.log':(1758,'8EDFA48E5078209329B776CBDE64BC402E25C6907320DD784C7FAC79BBA72413'),
 'E8修订说明_设计方_20261019.md':(4149,'3DA84E0F93498B36EA6C3E67B6352A6E89CB51F682480F333E9B59E1E581D133'),
}
def sha(data): return hashlib.sha256(data).hexdigest().upper()

def main():
 p=ROOT/'raw/host_pc_pkg_E8修订_设计方_20261019(1).zip'
 assert p.stat().st_size==10228 and sha(p.read_bytes())=='D8D6B6BBCA0EA9A6858F9CC1D71F6F1004389BF7EC3C53AD9ABA167E34890071'
 rows=[]
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None and len(z.namelist())==4 and set(z.namelist())==set(EXPECTED)
  for name,(n,h) in EXPECTED.items():
   data=z.read(name)
   assert len(data)==n and sha(data)==h
   assert (ROOT/'incoming'/name).read_bytes()==data
   rows.append({'path':name,'bytes':n,'sha256':h})
 receipt={'archive':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'members':rows,
          'expected_hash_source':'Product/test hashes and lengths declared in E8 note; other member hashes computed at receipt',
          'raw_documents':[{'file':q.name,'bytes':q.stat().st_size,'sha256':sha(q.read_bytes())} for q in sorted((ROOT/'raw').glob('*.md'))]}
 (ROOT/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
 print('RECEIPT PASS: archive CRC; 4 byte-exact members; declared product/test SHA256')

if __name__=='__main__':main()
