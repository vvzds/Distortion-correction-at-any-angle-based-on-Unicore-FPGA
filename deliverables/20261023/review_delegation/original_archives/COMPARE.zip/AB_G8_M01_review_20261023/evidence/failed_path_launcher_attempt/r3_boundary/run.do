onerror {quit -code 2 -f}
onbreak {quit -code 0 -f}
run -all
quit -code 0 -f
