onerror {quit -code 1 -f}
transcript on
vlib work
vlog -work work undistort_cache_ab.v
vlog -sv -work work cache_boundary_r3_tb.v
vopt work.cache_boundary_r3_tb -o boundary_opt
vsim work.boundary_opt
onfinish stop
run -all
quit -sim
quit -code 0 -f
