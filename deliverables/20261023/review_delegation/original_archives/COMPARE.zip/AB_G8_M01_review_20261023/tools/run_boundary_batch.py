"""Batch Tcl adaptation for received R3 TB; no source or assertion changes."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

p=argparse.ArgumentParser()
p.add_argument('--ab',type=Path,required=True)
p.add_argument('--scratch',type=Path,required=True)
p.add_argument('--vsim',type=Path,required=True)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
cwd=a.scratch/'boundary_batch_v1'
cwd.mkdir(parents=True,exist_ok=False)
a.out.mkdir(parents=True,exist_ok=False)
sources=[a.ab/'candidate/source/rtl/undistort_cache_ab.v',a.ab/'candidate/sim/cache_boundary_r3_tb.v']
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
before={s.name:sha(s) for s in sources}
for s in sources:shutil.copy2(s,cwd)
commands=['onerror {quit -code 1 -f}','transcript on','vlib work',
          'vlog -work work undistort_cache_ab.v','vlog -sv -work work cache_boundary_r3_tb.v',
          'vopt work.cache_boundary_r3_tb -o boundary_opt','vsim work.boundary_opt',
          'onfinish stop','run -all','quit -sim','quit -code 0 -f']
(cwd/'run.do').write_text('\n'.join(commands)+'\n')
shutil.copy2(cwd/'run.do',a.out)
start=dt.datetime.now(dt.timezone.utc).isoformat()
with (a.out/'console.log').open('wb') as f:
    proc=subprocess.run([str(a.vsim),'-batch','-do','do run.do'],cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=120)
s=(a.out/'console.log').read_text(errors='replace')
after={f.name:sha(f) for f in sources}
ok=proc.returncode==0 and 'R3_BOUNDARY PASS' in s and before==after and not re.search(r'(?i)\b(?:FAIL|FATAL|TIMEOUT)\b',s)
result=dict(passed=ok,exit_code=proc.returncode,start_utc=start,end_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
            command=[str(a.vsim),'-batch','-do','do run.do'],cwd=str(cwd),before=before,after=after,
            input_unchanged=before==after,vsim_sha256=sha(a.vsim),console_sha256=sha(a.out/'console.log'))
(a.out/'result.json').write_text(json.dumps(result,indent=2))
print(s[-3500:]);print('R3_BATCH_PASS='+str(ok))
raise SystemExit(0 if ok else 1)
