"""Verify received parameters against AB vectors and freeze execution inputs."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct

p=argparse.ArgumentParser()
p.add_argument('--received',type=Path,required=True)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
ab=a.received/'AB/G4_AB_R1_R4_20261023'
par=a.received/'parameters/parameters'
def require(ok,msg):
    if not ok:raise ValueError(msg)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
n=0
for line in (ab/'SHA256SUMS.txt').read_text(encoding='utf-8-sig').splitlines():
    if not line.strip():continue
    expected,relative=line.split('  ',1)
    require(sha(ab/relative)==expected.lower(),'SHA mismatch: '+relative)
    n+=1
encoding=json.loads((par/'parameter_encoding.json').read_text())
frame=(par/'real_0x01.bin').read_bytes()
require(frame==bytes.fromhex(encoding['cmd01_hex']),'JSON UART frame mismatch')
require(frame[:4]==bytes.fromhex('AA550120') and len(frame)==37,'frame header/length')
require(sum(frame[4:-1])&255==frame[-1],'frame checksum')
values=list(struct.unpack('<8i',frame[4:-1]))
require(values==[v['signed_integer'] for v in encoding['parameters']],'Q16 mismatch')
vectors=ab/'candidate/verification_data'
for name in ('real','identity'):
    require((par/(name+'_0x01.bin')).read_bytes()==bytes.fromhex((vectors/('vectors/'+name+'_uart_bytes.hex')).read_text()),'AB UART differs: '+name)
require((par/'calibration_q16.vh').read_bytes()==(vectors/'parameters/calibration_q16.vh').read_bytes(),'Q16 include differs')
vh=(par/'calibration_q16.vh').read_text()
hexes=re.findall(r"CAL_\w+\s*=\s*32'sh([0-9A-Fa-f]+)",vh)
require([int(h,16) for h in hexes]==[v&0xffffffff for v in values],'include constants mismatch')
result=dict(status='PASS',AB_SHA256SUMS_verified=n,parameter_include_byte_equal=True,
            real_identity_UART_byte_equal=True,real_frame_length=len(frame),real_frame_sha256=sha(par/'real_0x01.bin'),
            Q16_signed_values=values,model=encoding['model'],scope='Offline byte linkage only; no UART transmission or board application')
a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
