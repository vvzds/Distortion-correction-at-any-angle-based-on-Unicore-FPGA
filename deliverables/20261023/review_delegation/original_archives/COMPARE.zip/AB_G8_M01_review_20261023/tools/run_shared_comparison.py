"""Read-only candidate sources; one shared Verilog-2001 external-port TB."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import time

p=argparse.ArgumentParser()
p.add_argument('--scratch',type=Path,required=True)
p.add_argument('--vsim',type=Path,required=True)
p.add_argument('--ab-rtl',type=Path,required=True)
p.add_argument('--g8-rtl',type=Path,required=True)
p.add_argument('--data',type=Path,required=True)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
root=Path(__file__).resolve().parents[1]
a.out.mkdir(parents=True,exist_ok=False)
run=a.scratch/'shared_external_v1'
run.mkdir(parents=True,exist_ok=False)
rows=[]
for name,rtl in [('AB',a.ab_rtl),('G8',a.g8_rtl)]:
    cwd=run/name
    cwd.mkdir()
    shutil.copytree(a.data/'parameters',cwd/'parameters')
    shutil.copytree(a.data/'vectors',cwd/'vectors')
    shutil.copytree(rtl,cwd/'rtl')
    shutil.copy2(root/'comparison/shared_ddr_tb.v',cwd)
    hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in rtl.glob('*.v')}
    (a.out/(name+'_source_sha256.json')).write_text(json.dumps(hashes,indent=2))
    for profile,mode,first,gap,grant in [('identity',0,4,1,0),('real_fast',1,4,1,0),('real_stress',1,64,2,32)]:
        label=name+'_'+profile
        commands=['onerror {quit -code 1 -f}', 'transcript on']
        if profile=='identity':
            commands+=['vlib work','vlog -work work '+' '.join('rtl/'+f.name for f in sorted(rtl.glob('*.v'))),'vlog -work work +incdir+. shared_ddr_tb.v','vopt work.shared_ddr_tb -o shared_opt']
        commands += [f'vsim work.shared_opt +MODE={mode} +FIRST={first} +GAP={gap} +GRANT={grant}','onfinish stop','run -all','quit -sim','quit -code 0 -f']
        (cwd/'run.do').write_text('\n'.join(commands)+'\n')
        log=a.out/(label+'.log')
        print('RUN '+label,flush=True)
        begin=time.monotonic()
        with log.open('wb') as f:
            proc=subprocess.run([str(a.vsim),'-batch','-do','do run.do'],cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=2400)
        s=log.read_text(errors='replace')
        ok=proc.returncode==0 and '=== ALL TESTS PASSED (err=0) ===' in s and not re.search(r'(?mi)(?:^#\s*)?(?:FAIL |\*\* (?:Error|Fatal))',s)
        match=re.search(r'RESULT (.*)',s)
        metrics={}
        if match:
            for k,v in re.findall(r'(\w+)=([\d.]+)',match[1]):
                metrics[k]=float(v) if '.' in v else int(v)
        rows.append(dict(candidate=name,profile=profile,passed=ok,exit_code=proc.returncode,seconds=round(time.monotonic()-begin,3),metrics=metrics,sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
        (a.out/'results.json').write_text(json.dumps(rows,indent=2))
        print(('PASS ' if ok else 'FAIL ')+label+' '+str(metrics),flush=True)
        if not ok:
            print(s[-5000:],flush=True)
            raise SystemExit(1)
print('=== SHARED DDR COMPARISON PASSED (err=0) ===',flush=True)
