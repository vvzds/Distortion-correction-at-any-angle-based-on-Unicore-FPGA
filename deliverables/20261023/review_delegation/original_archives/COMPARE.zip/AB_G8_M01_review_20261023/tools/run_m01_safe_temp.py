"""Environment-only temp-directory adapter; original tests and assertions unchanged."""
import argparse
from pathlib import Path
import runpy
import shutil
import sys
import tempfile
import uuid

p = argparse.ArgumentParser()
p.add_argument('--test', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
p.add_argument('--temp-root', type=Path, required=True)
a = p.parse_args()
a.temp_root.mkdir(parents=True, exist_ok=True)

class SafeTemporaryDirectory:
    def __init__(self, suffix=None, prefix=None, dir=None, **kwargs):
        self.path = a.temp_root / ((prefix or 'case_') + uuid.uuid4().hex + (suffix or ''))
        self.path.mkdir()
        self.name = str(self.path)
    def __enter__(self):
        return self.name
    def __exit__(self, *args):
        self.cleanup()
    def cleanup(self):
        if self.path.exists():
            shutil.rmtree(self.path)

tempfile.TemporaryDirectory = SafeTemporaryDirectory
sys.argv = [str(a.test), '--out', str(a.out)]
runpy.run_path(str(a.test), run_name='__main__')
