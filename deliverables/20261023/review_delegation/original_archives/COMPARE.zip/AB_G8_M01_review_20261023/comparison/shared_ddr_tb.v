`timescale 1ns/1ps
// 两套候选共用激励；只观测公共端口，不依赖内部层次。
module shared_ddr_tb;
    `include "parameters/calibration_q16.vh"
    reg clk=0; always #4 clk=~clk;
    reg rst_n=0,start=0,hold_gnt=0,held=0;
    integer mode=0,first_latency=4,beat_gap=1,grant_delay=0;
    wire busy,hold_req,rel,req,pv,sop,eop,sof,eof;
    wire [23:0] addr;
    wire [6:0] len;
    wire [15:0] pix;
    wire [31:0] frames,loads,hits,pixels;
    reg vld=0,last=0,active=0;
    reg [255:0] data=0;
    integer grant_wait=0,delay_count=0,gap_count=0,base=0,read_len=0,beat=0;
    wire gnt=rst_n&&!active&&!vld&&grant_wait==0;
    reg [15:0] expected[0:2073599];
    reg [255:0] source_words[0:129599];
    integer cycles=0,count=0,err=0,transactions=0,returns=0,releases=0;
    integer accepted_cycle=0,last_return=0,first_min=999999,first_max=0;
    integer gap_min=999999,gap_max=0,delta=0,outstanding=0,expected_returns=0;
    reg pending=0,stalled=0;
    reg [23:0] stalled_addr;
    reg [6:0] stalled_len;
    undistort_core #(.SIM_MODE(0),.LINES_PER_SET(2)) dut(
        .clk(clk),.rst_n(rst_n),.i_fx(CAL_FX),.i_fy(CAL_FY),.i_cx(CAL_CX),.i_cy(CAL_CY),
        .i_k1(mode==0?32'sd0:CAL_K1),.i_k2(mode==0?32'sd0:CAL_K2),
        .i_p1(mode==0?32'sd0:CAL_P1),.i_p2(mode==0?32'sd0:CAL_P2),
        .i_aff_a11(32'sh10000),.i_aff_a12(32'sd0),.i_aff_a21(32'sd0),
        .i_aff_a22(32'sh10000),.i_aff_tx(32'sd0),.i_aff_ty(32'sd0),.i_aff_en(1'b0),
        .i_frame_start(start),.o_frame_busy(busy),.o_corr_src_hold_req(hold_req),
        .i_corr_src_hold_gnt(hold_gnt),.i_corr_src_slot(2'd3),.o_corr_src_rel(rel),
        .o_corr_rd_addr(addr),.o_corr_rd_len(len),.o_corr_rd_req(req),
        .i_corr_rd_gnt(gnt),.i_corr_rd_vld(vld),.i_corr_rd_data(data),.i_corr_rd_last(last),
        .o_pix_vld(pv),.o_pix(pix),.o_sop(sop),.o_eop(eop),.o_sof(sof),.o_eof(eof),
        .o_stat_frame_cnt(frames),.o_stat_line_loads(loads),.o_stat_line_hits(hits),.o_stat_pix_cnt(pixels));
    task fail;
        input [8*120-1:0] message;
        begin $display("FAIL %0s cycles=%0d pixels=%0d",message,cycles,count);$finish;end
    endtask
    always @(posedge clk) if(rst_n) begin
        cycles=cycles+1;
        if(rel)begin held<=0;hold_gnt<=0;end
        else if(hold_req)begin held<=1;hold_gnt<=1;end
        vld<=0;last<=0;
        if(req&&!active&&grant_wait>0)grant_wait<=grant_wait-1;
        if(stalled&&(!req||addr!==stalled_addr||len!==stalled_len))fail("request changed while stalled");
        stalled<=req&&!gnt;stalled_addr<=addr;stalled_len<=len;
        // 在 DUT 采样沿统计实际延迟，避免 NBA 的一拍偏差。
        if(vld)begin
            if(!pending)fail("unsolicited response");
            returns=returns+1;
            if(outstanding==0)begin
                delta=cycles-accepted_cycle;
                if(delta!=first_latency)fail("actual first latency mismatch");
                if(delta<first_min)first_min=delta;
                if(delta>first_max)first_max=delta;
            end else begin
                delta=cycles-last_return;
                if(delta!=beat_gap)fail("actual response gap mismatch");
                if(delta<gap_min)gap_min=delta;
                if(delta>gap_max)gap_max=delta;
            end
            last_return=cycles;outstanding=outstanding+1;
            if(last!==(outstanding==expected_returns))fail("response last mismatch");
            if(last)pending=0;
        end
        if(req&&gnt)begin
            if(!held||pending||addr[23:20]!=3||addr[2:0]!=0||addr[19:0]>=1036800||
                (addr[19:0]%960)+(len+1)*8>960)fail("illegal DDR request");
            transactions=transactions+1;pending=1;outstanding=0;
            expected_returns=len+1;accepted_cycle=cycles;
            base=addr[19:0]>>3;read_len=len;beat<=0;
            delay_count<=first_latency-2;active<=1;gap_count<=0;
        end else if(active)begin
            if(delay_count>0)delay_count<=delay_count-1;
            else if(gap_count>0)gap_count<=gap_count-1;
            else begin
                vld<=1;data<=source_words[base+beat];last<=beat==read_len;
                gap_count<=beat_gap-1;
                if(beat==read_len)begin active<=0;grant_wait<=grant_delay;end
                else beat<=beat+1;
            end
        end
        if(rel)begin
            releases=releases+1;
            if(pending||active||vld||count!=2073600)fail("release before drain");
        end
    end
    always @(posedge clk) begin
        #1;
        if(pv)begin
            if(count>=2073600||!busy)fail("extra pixel");
            if(pix!==expected[count])begin
                if(err<8)$display("MISMATCH n=%0d got=%h expected=%h",count,pix,expected[count]);
                err=err+1;
            end
            if(sop!==(count%1920==0)||eop!==(count%1920==1919)||sof!==(count==0)||eof!==(count==2073599))fail("pixel marker mismatch");
            count=count+1;
            if(count%518400==0)$display("PROGRESS pixels=%0d cycles=%0d",count,cycles);
        end
    end
    initial begin
        if(!$value$plusargs("MODE=%d",mode))mode=0;
        if(!$value$plusargs("FIRST=%d",first_latency))first_latency=4;
        if(!$value$plusargs("GAP=%d",beat_gap))beat_gap=1;
        if(!$value$plusargs("GRANT=%d",grant_delay))grant_delay=0;
        if(first_latency<2||beat_gap<1)fail("invalid profile");
        grant_wait=grant_delay;
        if(mode==0)$readmemh("vectors/identity_pixels.hex",expected);
        else $readmemh("vectors/real_pixels_1.hex",expected);
        $readmemh("vectors/source_words_1.hex",source_words);
        #30;rst_n=1;@(negedge clk);start=1;@(negedge clk);start=0;
        wait(busy);wait(!busy);repeat(15)@(negedge clk);
        if(err!=0||count!=2073600||pixels!=2073600||frames!=1||releases!=1||pending||active||held||req||pv)fail("frame checks");
        $display("RESULT mode=%0d pixels=%0d errors=%0d cycles=%0d transactions=%0d beats=%0d first_min=%0d first_max=%0d gap_min=%0d gap_max=%0d cpp=%f fps125=%f read_MBps125=%f",mode,count,err,cycles,transactions,returns,first_min,first_max,gap_min,gap_max,cycles*1.0/count,125000000.0/cycles,returns*32.0*125.0/cycles);
        $display("=== ALL TESTS PASSED (err=0) ===");$finish;
    end
    initial begin #1000000000;fail("timeout");end
endmodule
