"""Read-only G7 S3 evidence analysis. Never rewrites gates or approves budgets."""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re

SEEDS=(2,3,5,7,8,9,10,11)
def need(ok,why):
    if not ok: raise ValueError(why)
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def num(s):
    v=float(s)
    need(math.isfinite(v) and v>=0,'Invalid resource count')
    return v
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')

def parse_resources(s):
    need(s.count('Device Utilization Summary :')==1,'Ambiguous device table')
    need(s.count('Device Utilization Summary Of Each Module:')==1,'Ambiguous module table')
    a,b=s.split('Device Utilization Summary Of Each Module:')
    a=a.split('Device Utilization Summary :')[1]
    device={}
    for kind in ('LUT','FF','APM','DRM'):
        prefix='   '+kind if kind in ('LUT','FF') else ' Use of '+kind
        rows=re.findall(r'^\|'+prefix+r'\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)\s*\|',a,re.M)
        need(len(rows)==(2 if kind in ('LUT','FF') else 1),'Resource rows missing/duplicated: '+kind)
        pairs=[(num(x),num(y)) for x,y in rows]
        need(all(x<=y and y>0 for x,y in pairs),'Invalid capacity')
        used=sum(x for x,y in pairs);cap=sum(y for x,y in pairs)
        device[kind]=dict(used=used,capacity=cap,percent=100*used/cap)
    modules={}
    for line in b.splitlines():
        cols=[x.strip() for x in line.split('|')]
        if len(cols)<7:continue
        name=cols[1].lstrip('+ ')
        if name not in ('hdmi_ddr_ov5640_top','u_core','u_map','u_cache','u_bilinear','u_interp'):continue
        need(name not in modules,'Duplicate module: '+name)
        modules[name]=dict(zip(('LUT','FF','Distributed_RAM','APM','DRM'),map(num,cols[2:7])))
    need(all(x in modules for x in ('hdmi_ddr_ov5640_top','u_core','u_map','u_cache')),'Missing module')
    delta={k:device[k]['used']-modules['hdmi_ddr_ov5640_top'][k] for k in device}
    return dict(device=device,modules=modules,device_minus_module=delta,
                tables_equal=all(v==0 for v in delta.values()),S3='UNRESOLVED')

def native_inventory(s):
    pattern=r'\(INSTANCE\s+([^\s()]+)\s+\(VIEWREF\s+[^\s()]+\s+\(CELLREF\s+([^\s()]+)\s+\(OPERAREF\s+([^\s()]+)'
    rows=[]
    line_number=0
    for line in s.splitlines():
        line_number+=1
        if '(INSTANCE ' not in line:continue
        m=re.search(pattern,line)
        need(m is not None,'Unsupported native instance syntax')
        n,c,o=m.groups()
        rows.append(dict(name=n.lstrip('\\'),cell=c,operator=o,line=line_number))
    need(bool(rows),'No native instances')
    need(len(rows)==len({r['name'] for r in rows}),'Duplicate native instance')
    counts=dict(sorted(Counter(r['operator'] for r in rows).items()))
    memory=[r for r in rows if r['operator'] in ('gopDRM','gopDRM18K')]
    apm=[r for r in rows if r['operator']=='gopAPM']
    by_scope={}
    for name,prefix in [('top',''),('map','u_corr_top/u_core/u_map/'),('cache','u_corr_top/u_core/u_cache/'),('core','u_corr_top/u_core/')]:
        chosen=[r for r in rows if r['name'].startswith(prefix)]
        c=Counter(r['operator'] for r in chosen)
        by_scope[name]=dict(APM=c['gopAPM'],DRM36_count=c['gopDRM'],DRM18_count=c['gopDRM18K'],DRM36_equivalent=c['gopDRM']+c['gopDRM18K']/2)
    return dict(instance_count=len(rows),operator_counts=counts,scope_counts=by_scope,
                memory_instances=memory,apm_instances=apm,
                limitation='LUT compound operators are not weighted into resource totals; these counts alone do not explain the +2/+1 discrepancy.')

def parse_fdc(s):
    ports={}
    for n,k,v in re.findall(r'define_attribute\s+\{p:([^}]+)\}\s+\{([^}]+)\}\s+\{([^}]+)\}',s):
        d=ports.setdefault(n,{})
        need(k not in d or d[k]==v,'Conflicting attribute '+n+'/'+k)
        d[k]=v
    uart={k:ports.get(k,{}) for k in ('uart_tx','uart_rx')}
    locs={}
    for name,d in ports.items():
        if 'PAP_IO_LOC' in d:locs.setdefault(d['PAP_IO_LOC'],[]).append(name)
    duplicate_locs={k:v for k,v in locs.items() if len(v)>1}
    return dict(uart=uart,tx_missing=[k for k in ('PAP_IO_DRIVE','PAP_IO_SLEW') if k not in uart['uart_tx']],
                duplicate_explicit_locations=duplicate_locs,
                timing_lines=[dict(line=i,text=x) for i,x in enumerate(s.splitlines(),1) if x.strip().startswith(('create_clock','create_generated_clock','set_input_delay','set_output_delay','set_clock_groups','set_false_path'))],
                electrical_approved=False)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();root=a.root.resolve();a.out.mkdir(parents=True,exist_ok=False)
    manifest=json.loads((root/'files_sha256.json').read_text(encoding='utf-8'))
    index={r['path']:r for r in manifest};need(len(index)==len(manifest),'Duplicate manifest path')
    checked={}
    def load(relative):
        name=PurePosixPath(relative)
        need(not name.is_absolute() and '..' not in name.parts and '\\' not in relative and ':' not in relative,'Unsafe path')
        f=(root/relative).resolve();need(f.is_relative_to(root),'Escaping root')
        row=index.get(relative);need(row is not None,'Unreceipted input '+relative)
        need(f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],'Input SHA mismatch '+relative)
        checked[relative]=row['sha256']
        return f.read_text(encoding='utf-8-sig')
    all_rows=[]
    for seed in SEEDS:
        prefix=f'physical_g7_original/seed_{seed}/'
        prr=prefix+'place_route/hdmi_ddr_ov5640_top.prr'
        resources=parse_resources(load(prr))
        native_root=f'native_g7/seed_{seed}/'
        er=json.loads(load(native_root+'export_receipt.json'))
        native={}
        for stage in ('mapped','routed'):
            relative=native_root+stage+'.txt'
            s=load(relative)
            need(checked[relative]==er['stages'][stage]['decoded_sha256'],'Export receipt mismatch')
            native[stage]=native_inventory(s)
            dump(a.out/f'seed_{seed}_{stage}_inventory.json',native[stage])
        fdc_name=prefix+'HDMI_DDR3_OV5640_test.fdc';fdc_text=load(fdc_name);fdc=parse_fdc(fdc_text)
        # Retain cited original small files for review, without editing them.
        dest=a.out/f'seed_{seed}_sources';dest.mkdir()
        (dest/'original.prr').write_bytes((root/prr).read_bytes())
        (dest/'original.fdc').write_bytes((root/fdc_name).read_bytes())
        phase={}
        for ph in ('compile','synthesize','place_route','report_timing'):
            text=load(prefix+ph+'/run.log')
            critical=[dict(line=i,text=x) for i,x in enumerate(text.splitlines(),1) if x.startswith('C:')]
            phase[ph]=dict(critical_count=len(critical),categories=dict(Counter(re.search(r'C:\s*([^:]+):',x['text'])[1] for x in critical)),lines=critical)
        summary=json.loads(load(f'physical_analysis/seed_{seed}.json'))
        scope=native['routed']['scope_counts']
        need(scope['top']['APM']==resources['device']['APM']['used'],'APM native/report mismatch')
        need(scope['top']['DRM36_equivalent']==resources['device']['DRM']['used'],'DRM native/report mismatch')
        need(scope['cache']['DRM36_equivalent']==resources['modules']['u_cache']['DRM'],'Cache DRM mismatch')
        need(scope['map']['APM']==resources['modules']['u_map']['APM'],'Map APM mismatch')
        row=dict(seed=seed,resources=resources,fdc=fdc,phase_critical=phase,
                 routed_scope=scope,postroute=summary['postroute'],holdfix=summary['after_hold_fix']['sections']['Setup(Slow)']['wns'])
        all_rows.append(row);print('AUDITED seed',seed,'LUT delta',resources['device_minus_module']['LUT'],flush=True)
    unchanged=all(sha(root/n)==h for n,h in checked.items());need(unchanged,'Inputs changed during audit')
    dump(a.out/'input_sha256.json',checked)
    dump(a.out/'audit.json',dict(status='ANALYSIS_COMPLETE',seeds=all_rows,inputs_unchanged=unchanged,
        new_physical_runs=0,gate_modified=False,resource_exception_granted=False,
        known_open=['seed10/11 LUT table cause unresolved','UART drive/slew electrical confirmation','cache DRM16 exceeds12','APM43.75% budget','SCCB SRB/unateness']))
    print('=== EVIDENCE AUDIT COMPLETED; S3 NOT ACCEPTED ===')
if __name__=='__main__':main()
