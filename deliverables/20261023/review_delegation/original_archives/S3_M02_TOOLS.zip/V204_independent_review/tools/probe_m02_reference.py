"""Isolated original validation expressions, not a camera or 828-case regression."""
import argparse
import ast
import hashlib
import json
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--source',type=Path,required=True)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
source=a.source.read_text(encoding='utf-8-sig');tree=ast.parse(source)
checks=[n for n in ast.walk(tree) if isinstance(n,ast.Assert)]
funcs={n.name:n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef)}
namespace={}
unit=ast.Module(body=[funcs[n] for n in ('q16_16','q16_dec','g02_violations')],type_ignores=[])
exec(compile(ast.fix_missing_locations(unit),'original_helpers','exec'),namespace)
results=[]
cases=[('too_few_images',next(n for n in checks if ast.unparse(n.test)=='len(files) >= 15'),dict(files=['synthetic']*14)),
       ('decoded_fx_upper_boundary',next(n for n in checks if isinstance(n.test,ast.UnaryOp)),
        dict(names=('fx','fy','cx','cy','k1','k2','p1','p2'),p=dict(fx=32767.99,fy=1500.0,cx=960.,cy=540.,k1=0.,k2=0.,p1=0.,p2=0.)))]
for name,check,values in cases:
    for optimize in (0,2):
        ns=dict(namespace);ns.update(values)
        code=compile(ast.fix_missing_locations(ast.Module(body=[check],type_ignores=[])),'original_assert', 'exec',optimize=optimize)
        try:exec(code,ns);outcome='PASSED_VALIDATION'
        except AssertionError:outcome='REJECTED'
        expected='REJECTED' if optimize==0 else 'PASSED_VALIDATION'
        if outcome!=expected:raise RuntimeError((name,optimize,outcome))
        results.append(dict(case=name,optimize=optimize,outcome=outcome,expected_behavior_observed=True))
decoded=namespace['q16_dec'](namespace['q16_16'](32767.99))
out=dict(source=str(a.source),source_sha256=hashlib.sha256(a.source.read_bytes()).hexdigest(),
         asserts=[dict(line=n.lineno,test=ast.unparse(n.test)) for n in checks],results=results,
         fx_input=32767.99,fx_decoded=decoded,
         scope='Isolated original AST checks with synthetic values. No calibrate.main execution, camera data, UART transmission or candidate acceptance.',
         original_defect='REPRODUCED_LIMITED',candidate_828='NOT_VERIFIED')
a.out.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
