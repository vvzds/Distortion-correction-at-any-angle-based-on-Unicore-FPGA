import ast
import hashlib
from pathlib import Path
import shutil
import unittest
from unittest.mock import patch
import uuid
import m02_candidate_review as m

class Tests(unittest.TestCase):
    def setUp(self):
        self.root=Path(__file__).resolve().parents[1]/'test_scratch'/uuid.uuid4().hex
        self.root.mkdir(parents=True)
        self.addCleanup(lambda:shutil.rmtree(self.root))
        self.ref=self.root/'ref.py';self.cand=self.root/'cand.py';self.uart=self.root/'uart.py'
        self.text='def check(x):\n'+''.join(f'    assert x > {i}, "check{i}"\n' for i in range(6))+'    return x*65536\n'
        self.ref.write_text(self.text);self.uart.write_text('frozen UART fixture\n')
        self.expected=m.digest(self.ref)
        self.patch=patch.object(m,'UART_SHA',m.digest(self.uart));self.patch.start();self.addCleanup(self.patch.stop)
        tree=ast.parse(self.text)
        class Replace(ast.NodeTransformer):
            def visit_Assert(self,n):return ast.If(test=ast.UnaryOp(op=ast.Not(),operand=n.test),body=[ast.Raise(exc=ast.Call(func=ast.Name(id='ValueError',ctx=ast.Load()),args=[n.msg],keywords=[]),cause=None)],orelse=[])
        self.good=ast.unparse(ast.fix_missing_locations(Replace().visit(tree)))
        self.cand.write_text(self.good)
    def run_review(self):return m.review(self.ref,self.cand,self.uart,self.expected)
    def test_valid(self):self.assertEqual(self.run_review()['structural_status'],'PASS')
    def test_optimized_checks_preserved(self):
        ns={};exec(compile(self.good,'fixture','exec',optimize=2),ns)
        with self.assertRaises(ValueError):ns['check'](0)
    def test_reference_sha(self):
        self.expected='0'*64
        with self.assertRaises(ValueError):self.run_review()
    def test_uart_drift(self):
        self.uart.write_text('changed')
        with self.assertRaises(ValueError):self.run_review()
    def test_still_assert(self):
        self.cand.write_text(self.text)
        with self.assertRaises(ValueError):self.run_review()
    def test_weakened_predicate(self):
        self.cand.write_text(self.good.replace('x > 0','x >= 0'))
        with self.assertRaises(ValueError):self.run_review()
    def test_encoding_changed(self):
        self.cand.write_text(self.good.replace('65536','65535'))
        with self.assertRaises(ValueError):self.run_review()
    def test_extra_side_effect(self):
        self.cand.write_text(self.good+'\nprint("side effect")')
        with self.assertRaises(ValueError):self.run_review()
    def test_message_changed(self):
        self.cand.write_text(self.good.replace('check0','different'))
        with self.assertRaises(ValueError):self.run_review()
    def test_bad_exception(self):
        self.cand.write_text(self.good.replace('ValueError','SystemExit'))
        with self.assertRaises(ValueError):self.run_review()
    def test_format_only(self):
        self.cand.write_text('# changed formatting\n'+self.good+'\n')
        self.assertEqual(self.run_review()['external_828_execution'],'NOT_VERIFIED')
if __name__=='__main__':unittest.main(verbosity=2)
