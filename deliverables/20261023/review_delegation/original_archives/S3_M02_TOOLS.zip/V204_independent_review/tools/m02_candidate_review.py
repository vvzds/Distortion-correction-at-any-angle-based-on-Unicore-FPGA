"""Read-only M02 structural intake. Does not claim the external 828-case execution."""
import argparse
import ast
import hashlib
import json
from pathlib import Path

UART_SHA='043f8076f3ee9b810081fa337b6ed0cdffa85131ee4a3c04f409534960331a57'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(ok,msg):
    if not ok:raise ValueError(msg)
def shape(node):return ast.dump(node,include_attributes=False)

def review(reference,candidate,uart,reference_sha):
    need(digest(reference)==reference_sha.lower(),'Reference SHA mismatch')
    need(digest(uart)==UART_SHA,'UART SHA mismatch; current tlimfix required')
    original=ast.parse(reference.read_text(encoding='utf-8-sig'))
    changed=ast.parse(candidate.read_text(encoding='utf-8-sig'))
    checks=[n for n in ast.walk(original) if isinstance(n,ast.Assert)]
    need(len(checks)==6,'Expected exactly six reference assertions')
    need(not any(isinstance(n,ast.Assert) for n in ast.walk(changed)),'Candidate still contains assert')
    expected={(shape(n.test),shape(n.msg) if n.msg else None) for n in checks}
    replacements=[]
    class Restore(ast.NodeTransformer):
        def visit_If(self,n):
            n=self.generic_visit(n)
            if not isinstance(n.test,ast.UnaryOp) or not isinstance(n.test.op,ast.Not):return n
            if len(n.body)!=1 or n.orelse or not isinstance(n.body[0],ast.Raise):return n
            r=n.body[0]
            if r.cause is not None or not isinstance(r.exc,ast.Call):return n
            e=r.exc
            if not isinstance(e.func,ast.Name) or e.func.id not in ('AssertionError','ValueError','RuntimeError') or e.keywords or len(e.args)>1:return n
            msg=e.args[0] if e.args else None
            key=(shape(n.test.operand),shape(msg) if msg else None)
            if key not in expected:return n
            replacements.append(dict(line=n.lineno,exception=e.func.id,condition=ast.unparse(n.test.operand)))
            return ast.copy_location(ast.Assert(test=n.test.operand,msg=msg),n)
    restored=Restore().visit(changed)
    need(len(replacements)==6,'Not six exact explicit-check replacements')
    need(shape(original)==shape(restored),'Extra semantic edits beyond six checks')
    return dict(structural_status='PASS',reference_sha256=digest(reference),candidate_sha256=digest(candidate),
                uart_sha256=digest(uart),replacements=replacements,external_828_execution='NOT_VERIFIED',
                live_application='NOT_PERFORMED',note='AST equivalence only, ignores comments/format. Exception class changes listed; dynamic rejection/artifact tests still required.')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('reference','candidate','uart','out'):p.add_argument('--'+n,type=Path,required=True)
    p.add_argument('--reference-sha256',required=True)
    a=p.parse_args()
    need(not a.out.exists(),'Output must be new')
    try:r=review(a.reference,a.candidate,a.uart,a.reference_sha256);code=0
    except (ValueError,SyntaxError,OSError) as e:r=dict(structural_status='REJECTED',reason=str(e));code=2
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(r,ensure_ascii=False,indent=2));return code
if __name__=='__main__':raise SystemExit(main())
