import unittest
from audit_core_evidence import parse_resources,parse_fdc,native_inventory

def report(delta=0):
    return '''Device Utilization Summary :
|   LUT | 10 | 100 |
|   LUT | 5 | 100 |
|   FF | 20 | 200 |
|   FF | 10 | 200 |
| Use of APM | 3 | 240 |
| Use of DRM | 2.5 | 155 |
Device Utilization Summary Of Each Module:
| hdmi_ddr_ov5640_top | %s | 30 | 0 | 3 | 2.5 |
| u_core | 10 | 20 | 0 | 3 | 2 |
| u_map | 5 | 10 | 0 | 3 | 0 |
| u_cache | 5 | 10 | 0 | 0 | 2 |
'''%(15-delta)
class AuditTest(unittest.TestCase):
    def test_equal(self):self.assertTrue(parse_resources(report())['tables_equal'])
    def test_delta1(self):self.assertEqual(parse_resources(report(1))['device_minus_module']['LUT'],1)
    def test_delta2_not_waived(self):self.assertFalse(parse_resources(report(2))['tables_equal'])
    def test_missing(self):
        with self.assertRaises(ValueError):parse_resources(report().replace('| Use of APM | 3 | 240 |',''))
    def test_duplicate(self):
        with self.assertRaises(ValueError):parse_resources(report()+'\nDevice Utilization Summary :')
    def test_duplicate_module(self):
        with self.assertRaises(ValueError):parse_resources(report()+'\n| u_map | 5 | 10 | 0 | 3 | 0 |')
    def test_capacity(self):
        with self.assertRaises(ValueError):parse_resources(report().replace('| 3 | 240 |','| 241 | 240 |'))
    def test_fdc_missing(self):self.assertEqual(len(parse_fdc('')['tx_missing']),2)
    def test_fdc_conflict(self):
        with self.assertRaises(ValueError):parse_fdc('define_attribute {p:uart_tx} {PAP_IO_LOC} {A1}\ndefine_attribute {p:uart_tx} {PAP_IO_LOC} {B2}')
    def test_fdc_duplicate_loc(self):
        x=parse_fdc('define_attribute {p:a} {PAP_IO_LOC} {A1}\ndefine_attribute {p:b} {PAP_IO_LOC} {A1}')
        self.assertEqual(x['duplicate_explicit_locations'],{'A1':['a','b']})
    def test_native_count(self):
        s='(INSTANCE \\u_corr_top/u_core/u_cache/ram (VIEWREF OPER (CELLREF c (OPERAREF gopDRM18K))))'
        self.assertEqual(native_inventory(s)['scope_counts']['cache']['DRM36_equivalent'],0.5)
    def test_native_duplicate(self):
        s='(INSTANCE x (VIEWREF OPER (CELLREF c (OPERAREF gopAPM))))'
        with self.assertRaises(ValueError):native_inventory(s+'\n'+s)
    def test_native_unknown(self):
        with self.assertRaises(ValueError):native_inventory('(INSTANCE x malformed)')
if __name__=='__main__':unittest.main(verbosity=2)
