"""Verify delivered files; never executes FPGA/serial tools."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
rows=json.loads((root/'delivery_manifest.json').read_text(encoding='utf-8'))
seen=set()
for row in rows:
    name=row['path'];p=(root/name).resolve()
    if not p.is_relative_to(root) or name.casefold() in seen:raise SystemExit('Unsafe/duplicate path')
    seen.add(name.casefold())
    if not p.is_file() or p.stat().st_size!=row['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:raise SystemExit('Mismatch: '+name)
print('PASS',len(rows),'files verified')
