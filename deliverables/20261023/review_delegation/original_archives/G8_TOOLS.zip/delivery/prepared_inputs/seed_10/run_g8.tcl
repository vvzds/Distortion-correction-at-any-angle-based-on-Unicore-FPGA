cd [file dirname [info script]]
source build.tcl
