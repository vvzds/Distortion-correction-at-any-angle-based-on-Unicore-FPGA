"""Strict readers for the supplied SP6.4 CSV/text/XML/resource report formats."""
import csv
import io
import math
import re
import xml.etree.ElementTree as ET


def need(ok, message):
    if not ok:
        raise ValueError(message)


def number(text):
    value = float(text)
    need(math.isfinite(value), 'Non-finite report number')
    return value


def count(text):
    need(re.fullmatch(r'\d+', text) is not None, 'Invalid endpoint count')
    return int(text)


def consistent(wns, tns, ep):
    need(tns <= 0, 'Positive total failing slack')
    need((wns >= 0 and tns == 0 and ep == 0) or (wns < 0 and tns < 0 and ep > 0),
         'Contradictory WNS/TNS/endpoint count')


def parse_csv(text, expected_seed=None):
    lines = text.splitlines()
    need(lines and lines[0] == 'version,2022.2-SP6.4<build 146967>', 'Unsupported PDS CSV version/build')
    headers = [i for i, s in enumerate(lines) if s.startswith('Seed,State,Convergence,')]
    need(len(headers) == 1, 'Missing or repeated CSV header')
    head = headers[0]
    trailers = [i for i, s in enumerate(lines) if s.startswith('Pass Rate/Convergence Rate,')]
    need(len(trailers) == 1 and trailers[0] > head, 'Missing or repeated native result trailer')
    all_rows = list(csv.reader(io.StringIO(text)))
    need(sum(bool(r) and r[0] == 'single' for r in all_rows) == 1, 'Extra native data row')
    if expected_seed is not None:
        commands = [r[1] for r in all_rows if r and r[0] == 'place & route' and len(r) == 2]
        need(len(commands) == 1, 'Missing native project seed configuration')
        need(re.fullmatch(r'\s*-gplace_seed\s+'+str(expected_seed)+r'\s+-groute_seed\s+'
                          +str(expected_seed)+r'\s*', commands[0]), 'Native CSV configured seed mismatch')
    fields = next(csv.reader([lines[head]]))
    need(len(fields) == len(set(fields)), 'Duplicate CSV column')
    rows = []
    for s in lines[head+1:trailers[0]]:
        if not s.strip():
            continue
        row = next(csv.reader([s]))
        need(len(row) == len(fields), 'Malformed or extra CSV record')
        rows.append(dict(zip(fields, row)))
    need(len(rows) == 1, 'Expected exactly one isolated native CSV result')
    row = rows[0]
    need(row['Seed'] == 'single' and row['State'] == 'OK', 'Unexpected native seed/state')
    result = {key: number(row[key]) for key in ('Setup(Slow)', 'Setup(Fast)', 'Hold(Slow)', 'Hold(Fast)')}
    result.update(tns=number(row['Setup(Slow) Total Failing TNS']),
                  ep=count(row['Setup(Slow) Total Failing Endpoints']),
                  hold_tns=number(row['Hold(Slow) Total Failing THS']),
                  hold_ep=count(row['Hold(Slow) Total Failing Endpoints']))
    consistent(result['Setup(Slow)'], result['tns'], result['ep'])
    consistent(result['Hold(Slow)'], result['hold_tns'], result['hold_ep'])
    result['closed'] = result['Setup(Slow)'] >= 0
    need(row['Convergence'] == ('OK' if result['closed'] else 'Fail'), 'CSV convergence contradicts slow setup')
    return result


def parse_final(text):
    summary = re.findall(r'(?m)^Design Summary\s*:\s*(.+)$', text)
    need(len(summary) == 1, 'Missing or repeated final Design Summary')
    matches = list(re.finditer(r'(?m)^(\w[\w ]*) Summary\((Slow|Fast) Corner\):\s*$', text))
    sections = {}
    for i, match in enumerate(matches):
        kind, corner = match.groups()
        name = kind + '(' + corner + ')'
        need(name not in sections, 'Duplicate final timing section')
        body = text[match.end():matches[i+1].start() if i+1 < len(matches) else len(text)]
        domains = []
        pairs = set()
        for s in body.splitlines():
            cols = s.split()
            if len(cols) != 6 or cols[0] in ('Launch', 'Clock'):
                continue
            # A domain row must be fully numeric. Bad numeric rows are never silently skipped.
            wns, tns = number(cols[2]), number(cols[3])
            ep, total = count(cols[4]), count(cols[5])
            need(total >= ep, 'Endpoint count exceeds total')
            consistent(wns, tns, ep)
            pair = tuple(cols[:2])
            need(pair not in pairs, 'Duplicate final clock pair')
            pairs.add(pair)
            domains.append(dict(launch=cols[0], capture=cols[1], wns=wns, tns=tns, ep=ep, total=total))
        sections[name] = dict(domains=domains)
        if domains:
            sections[name].update(wns=min(r['wns'] for r in domains),
                                  tns=round(sum(r['tns'] for r in domains), 6),
                                  ep=sum(r['ep'] for r in domains))
    required = ('Setup(Slow)', 'Setup(Fast)', 'Hold(Slow)', 'Hold(Fast)')
    need(all(k in sections and sections[k]['domains'] for k in required), 'Incomplete four final quadrants')
    need(all(any(r['launch'] == r['capture'] == 'ddrphy_sysclk' for r in sections[k]['domains'])
             for k in required), 'DDR clock domain missing from final timing')
    claimed_pass = summary[0].strip() in ('All Constraints Met.', 'No Constraints Violated.')
    any_failure = any(s.get('ep', 0) or s.get('wns', 0) < 0 for s in sections.values())
    need(not (claimed_pass and any_failure), 'Final all-met headline contradicts failing section')
    return dict(design_summary=summary[0].strip(), sections=sections)


def parse_rtr(text):
    need('<!DOCTYPE' not in text.upper() and '<!ENTITY' not in text.upper(), 'DTD/entity forbidden in report XML')
    root = ET.fromstring(text)
    need(root.tag == 'tables', 'Not a PDS timing table XML')
    tables = [t for t in root.iter('table') if t.get('id') == 'report_timing_clock_summary']
    need(len(tables) == 1, 'Missing or repeated timing clock summary')
    rows = [[(d.text or '').strip() for d in r.findall('data')] for r in tables[0].iter('row')]
    ddr = [r for r in rows if r and r[0] == 'ddrphy_sysclk']
    need(len(ddr) == 1 and len(ddr[0]) >= 4, 'Missing or repeated DDR clock row')
    need(number(ddr[0][2]) == 8.0 and ddr[0][3] == '125.0000MHz', 'DDR clock is not 125MHz / 8ns')
    return dict(ddr_clock='ddrphy_sysclk', period_ns=8.0, frequency_MHz=125.0,
                limitation='XML structure/clock checked; not a reconstruction of all critical paths')


def parse_resources(text):
    need('2022.2-SP6.4 <build 146967>' in text.splitlines()[0], 'Unsupported resource report version')
    need(text.count('Device Utilization Summary :') == 1 and
         text.count('Device Utilization Summary Of Each Module:') == 1, 'Missing or repeated resource tables')
    device, modules = text.split('Device Utilization Summary Of Each Module:')
    device = device.split('Device Utilization Summary :')[1]
    used = {}
    for kind in ('APM', 'DRM'):
        found = re.findall(r'(?m)^\| Use of '+kind+r'\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)\s*\|', device)
        need(len(found) == 1, 'Missing or repeated device resource '+kind)
        u, cap = map(number, found[0])
        need(0 <= u <= cap and cap > 0, 'Invalid resource capacity')
        used[kind] = dict(used=u, available=cap, percent=100*u/cap)
    capacities = {}
    for kind in ('LUT', 'FF'):
        found = re.findall(r'(?m)^\|   '+kind+r'\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)\s*\|', device)
        need(len(found) == 2, 'Expected CLMA and CLMS '+kind+' rows')
        nums = [tuple(map(number, r)) for r in found]
        need(all(0 <= a <= b and b > 0 for a, b in nums), 'Invalid LUT/FF usage')
        capacities[kind] = sum(b for a, b in nums)
        u = sum(a for a, b in nums)
        used[kind] = dict(used=u, available=capacities[kind], percent=100*u/capacities[kind])
    rows = {}
    for s in modules.splitlines():
        cols = [v.strip() for v in s.split('|')]
        if len(cols) < 7:
            continue
        name = cols[1].lstrip('+ ').strip()
        if name not in ('hdmi_ddr_ov5640_top', 'u_core', 'u_map', 'u_cache'):
            continue
        need(name not in rows, 'Ambiguous module resource row: '+name)
        values = dict(zip(('LUT', 'FF', 'Distributed_RAM', 'APM', 'DRM'), map(number, cols[2:7])))
        need(all(v >= 0 for v in values.values()), 'Negative module resource')
        rows[name] = values
    need(len(rows) == 4, 'Missing top/core/map/cache resource rows')
    need(all(rows['hdmi_ddr_ov5640_top'][k] == used[k]['used'] for k in used), 'Top/device resource totals disagree')
    return dict(device=used, modules=rows, S3_status='UNRESOLVED_APPROVAL_REQUIRED')
