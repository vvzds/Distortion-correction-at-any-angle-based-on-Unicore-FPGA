"""独立核对八轮执行记录与产物哈希；合法失败记录不等于构建通过。"""
from pathlib import Path
import argparse
import json
import sys
from g8_common import (SEEDS, baseline_id, check_inputs, check_plan, dump, hash_map,
                       inventory, need, safe_file, separate_output, sha, trusted_baseline)
from g8_execution_records import check_batch, check_record


def inspect(root, _test_baseline=None):
    base = trusted_baseline() if _test_baseline is None else _test_baseline
    plan_sha = check_plan(root, base)
    batch, batch_sha = check_batch(root, baseline_id(_test_baseline))
    rows, snapshots = [], {}
    for seed in SEEDS:
        target = root / f'seed_{seed}'
        try:
            expected = check_inputs(target, seed, base)
            record = check_record(target, seed, expected, batch,
                                  hash_map(batch['receipts_sha256'])[f'seed_{seed}/process_receipt.json'])
            artifacts = record['artifacts_sha256']
            need(isinstance(artifacts, dict), 'Artifact hash map required')
            artifacts = hash_map(artifacts) if artifacts else {}
            need(not set(artifacts) & (set(expected) | {'process_receipt.json', 'trial_inputs_sha256.json'}),
                 'Artifact/input overlap')
            need(set(inventory(target)) == set(expected) | set(artifacts) |
                 {'process_receipt.json', 'trial_inputs_sha256.json'}, 'Execution inventory differs')
            for name, digest in artifacts.items():
                # 超时/启动失败允许零字节console；门禁仍按成功证据严格拒空。
                path = target / name
                need(path.is_file() and sha(path) == digest, 'Execution artifact differs: ' + name)
            snapshots[seed] = {name: sha(path) for name, path in inventory(target).items()}
            rows.append({'seed': seed, 'record_valid': True, 'outcome': record['outcome'],
                         'build_success_claimed': record['outcome'] == 'FINISHED',
                         'artifact_count': len(artifacts)})
        except Exception as exc:
            rows.append({'seed': seed, 'record_valid': False, 'reason': type(exc).__name__ + ': ' + str(exc)})
    need(sha(root / 'run_plan.json') == plan_sha and sha(root / 'batch_receipt.json') == batch_sha,
         'Execution metadata changed during inspection')
    for row in rows:
        if not row['record_valid']:
            continue
        try:
            target = root / f"seed_{row['seed']}"
            paths = inventory(target)
            need(set(paths) == set(snapshots[row['seed']]) and
                 all(sha(paths[name]) == digest for name, digest in snapshots[row['seed']].items()),
                 'Execution evidence changed before inspection completed')
        except (ValueError, OSError) as exc:
            row.update(record_valid=False, reason=str(exc))
    valid = sum(row['record_valid'] for row in rows)
    completed = sum(row.get('outcome') == 'FINISHED' for row in rows)
    return {'schema': 'g8-execution-check-v1', 'baseline_sha256': baseline_id(_test_baseline),
            'records_valid': valid, 'planned': 8, 'completed': completed, 'seeds': rows,
            'status': 'RECORDS_VALID' if valid == 8 else 'RECORDS_INVALID',
            'all_processes_finished': valid == completed == 8,
            'physical_build_acceptance': 'NOT_DECLARED', 'exit_code': 0 if valid == 8 else 2}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    separate_output(args.run, args.out)
    result = inspect(args.run)
    args.out.mkdir(parents=True)
    dump(args.out / 'execution_check.json', result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result['exit_code']


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print('EXECUTION_CHECK_FAIL: ' + str(exc), file=sys.stderr)
        sys.exit(2)
