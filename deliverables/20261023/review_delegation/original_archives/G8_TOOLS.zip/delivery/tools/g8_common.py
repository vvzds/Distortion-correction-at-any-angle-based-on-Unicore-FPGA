"""G8冻结身份、只读路径及JSON检查；不执行PDS。"""
from pathlib import Path, PurePosixPath
import datetime as dt
import hashlib
import json
import math
import os
import re
import stat

HOME = Path(__file__).resolve().parent
BASELINE_SHA256 = '24AE3E6B230A3451221EC0CC047890FD6E93A559C24BD223ACFE5AAE6FF75EDF'
CANDIDATE = 'G8_K2_PARTIAL_C14_EXPERIMENT'
SEEDS = [2, 3, 5, 7, 8, 9, 10, 11]
VERSION = '2022.2-SP6.4<build 146967>'
EMPTY_AUX = frozenset(('compile/error_info.txt', 'place_route/layers.txt'))


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest().upper()


def no_duplicates(pairs):
    value = {}
    for key, item in pairs:
        need(key not in value, 'Duplicate JSON key: ' + key)
        value[key] = item
    return value


def load(path):
    def invalid(value):
        raise ValueError('Non-finite JSON: ' + value)
    return json.loads(Path(path).read_text(encoding='utf-8-sig'),
                      object_pairs_hook=no_duplicates, parse_constant=invalid)


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                    allow_nan=False) + '\n', encoding='utf-8')


def read(path):
    raw = Path(path).read_bytes()
    for encoding in ('utf-8-sig', 'gb18030'):
        try:
            return raw.decode(encoding).replace('\r\n', '\n')
        except UnicodeDecodeError:
            pass
    raise ValueError('Undecodable text: ' + str(path))


def reparse(path):
    info = path.lstat()
    return stat.S_ISLNK(info.st_mode) or bool(getattr(info, 'st_file_attributes', 0) & 0x400)


def relative_name(name):
    need(isinstance(name, str) and name and '\\' not in name and ':' not in name,
         'Noncanonical relative path')
    need(not PurePosixPath(name).is_absolute(), 'Absolute evidence path')
    need(all(part and part not in ('.', '..') and not part.endswith((' ', '.'))
             for part in name.split('/')), 'Unsafe evidence path')
    return name


def safe_file(root, name, auxiliary=False):
    relative_name(name)
    path = Path(root)
    need(path.is_dir() and not reparse(path), 'Linked or missing evidence root')
    for part in name.split('/'):
        path = path / part
        need(not reparse(path), 'Linked evidence forbidden: ' + name)
    need(path.is_file() and (path.stat().st_size > 0 or (auxiliary and name in EMPTY_AUX)),
         'Missing or empty file: ' + name)
    return path


def inventory(root):
    root = Path(root)
    need(root.is_dir() and not reparse(root), 'Missing or linked directory')
    paths, folded = {}, set()
    for parent, dirs, names in os.walk(root, followlinks=False):
        for name in dirs + names:
            path = Path(parent) / name
            relative = path.relative_to(root).as_posix()
            relative_name(relative)
            need(not reparse(path), 'Link/junction in evidence: ' + relative)
            need(relative.casefold() not in folded, 'Case-aliased path: ' + relative)
            folded.add(relative.casefold())
        for name in names:
            path = Path(parent) / name
            need(path.is_file(), 'Non-regular evidence')
            paths[path.relative_to(root).as_posix()] = path
    return paths


def hash_map(value):
    need(isinstance(value, dict) and value, 'Missing/non-object hash map')
    result, folded = {}, set()
    for name, digest in value.items():
        relative_name(name)
        need(name.casefold() not in folded, 'Case-aliased hash path')
        need(isinstance(digest, str) and re.fullmatch('[0-9A-Fa-f]{64}', digest), 'Invalid SHA256')
        folded.add(name.casefold())
        result[name] = digest.upper()
    return result


def trusted_baseline():
    path = HOME / 'data/g8_baseline.json'
    need(sha(path) == BASELINE_SHA256, 'Packaged G8 baseline is corrupted')
    baseline = load(path)
    need(baseline['schema'] == 'g8-pinned-inputs-v1' and baseline['candidate'] == CANDIDATE and
         baseline['seeds'] == SEEDS and type(baseline['latency']) is int and baseline['latency'] == 14 and
         type(baseline['II']) is int and baseline['II'] == 1, 'Wrong G8 baseline')
    return baseline


def baseline_id(test_baseline):
    return BASELINE_SHA256 if test_baseline is None else 'SYNTHETIC_TEST_INJECTION'


def check_plan(root, base):
    path = safe_file(root, 'run_plan.json')
    need(sha(path) == base['run_plan_sha256'], 'Run plan differs from pinned G8 bytes')
    plan = load(path)
    need(plan['candidate'] == CANDIDATE and type(plan['latency']) is int and plan['latency'] == 14 and
         type(plan['II']) is int and plan['II'] == 1, 'Candidate/C14/II identity differs')
    need(plan['seeds'] == SEEDS and all(type(seed) is int for seed in plan['seeds']), 'Wrong eight seed set')
    need(hash_map(plan['host_inputs']) == hash_map(base['host_inputs']), 'Host input identity differs')
    need({path.name for path in Path(root).iterdir() if path.name.startswith('seed_')} ==
         {'seed_' + str(seed) for seed in SEEDS}, 'Missing, extra or unplanned seed directory')
    return sha(path)


def check_inputs(root, seed, base, clean=False):
    paths = inventory(root)
    expected = hash_map(base['seed_inputs'][str(seed)])
    manifest = safe_file(root, 'trial_inputs_sha256.json')
    need(sha(manifest) == base['seed_manifest_sha256'][str(seed)], 'Trial manifest bytes differ')
    need(hash_map(load(manifest)) == expected, 'Input list differs from pinned G8')
    for name, digest in expected.items():
        need(sha(safe_file(root, name)) == digest, 'Pinned input hash mismatch: ' + name)
    actual_source = {name for name in paths if name.split('/')[0] in ('source', 'ipcore')}
    need(actual_source == {name for name in expected if name.split('/')[0] in ('source', 'ipcore')},
         'Extra/missing source or IP')
    if clean:
        need(set(paths) == set(expected) | {'trial_inputs_sha256.json'}, 'Prepared input directory is not clean')
    return expected


def preflight(root, _test_baseline=None):
    root = Path(root).absolute()
    base = trusted_baseline() if _test_baseline is None else _test_baseline
    plan_sha = check_plan(root, base)
    rows = []
    for seed in SEEDS:
        expected = check_inputs(root / ('seed_' + str(seed)), seed, base, clean=True)
        rows.append({'seed': seed, 'inputs': len(expected), 'clean': True})
    need(check_plan(root, base) == plan_sha, 'Plan drift during preflight')
    return {'schema': 'g8-preflight-v1', 'status': 'PASS', 'candidate': CANDIDATE,
            'baseline_sha256': baseline_id(_test_baseline), 'run_plan_sha256': plan_sha,
            'latency': 14, 'II': 1, 'seeds': rows, 'pds_executed': False,
            'formal_acceptance': 'NOT_DECLARED'}


def finite_positive(value, label):
    need(type(value) in (int, float) and math.isfinite(value) and value > 0, 'Invalid ' + label)
    return value


def timeline(receipt):
    begin = dt.datetime.fromisoformat(receipt['started'])
    end = dt.datetime.fromisoformat(receipt['finished'])
    need(begin.utcoffset() is not None and end.utcoffset() is not None, 'Timezone required')
    need(end >= begin, 'Receipt time order reversed')
    seconds = receipt['seconds']
    need(type(seconds) in (int, float) and math.isfinite(seconds) and seconds >= 0, 'Invalid duration')
    need(abs((end - begin).total_seconds() - seconds) <= 5, 'Receipt duration contradicts timestamps')
    return begin, end


def shell_path(value):
    need(isinstance(value, str) and value.replace('\\', '/').endswith(
         '/PDS_2022.2-SP6.4/bin/pds_shell.exe'), 'Unsupported SP6.4 shell path')


def separate_output(root, out):
    root, out = Path(root).resolve(), Path(out).resolve()
    need(not out.exists() and root != out and not out.is_relative_to(root) and not root.is_relative_to(out),
         'Use a fresh output separate from immutable inputs/evidence')
