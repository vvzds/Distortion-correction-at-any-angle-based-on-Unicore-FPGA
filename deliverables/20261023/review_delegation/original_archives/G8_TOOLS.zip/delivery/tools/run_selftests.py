"""在新证据目录复跑普通/-O两组工具自检，不执行PDS。"""
from pathlib import Path
import argparse
import datetime as dt
import subprocess
import sys
import time
from g8_common import dump, inventory, need, sha


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    out = args.out.resolve()
    need(not out.exists(), 'Use a fresh selftest output directory')
    out.mkdir(parents=True)
    monitored = {str(path.relative_to(root)).replace('\\', '/'): sha(path)
                 for folder in ('tools', 'tests') for path in (root / folder).rglob('*')
                 if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc'}
    jobs = []
    for flags, label in (([], 'normal'), (['-O'], 'optimized')):
        argv = [sys.executable, '-B', *flags, str(root / 'tests/test_g8_tools.py')]
        start = time.monotonic()
        run = subprocess.run(argv, cwd=root, capture_output=True)
        (out / (label + '.stdout.log')).write_bytes(run.stdout)
        (out / (label + '.stderr.log')).write_bytes(run.stderr)
        jobs.append({'mode': label, 'argv': argv, 'exit_code': run.returncode,
                     'seconds': time.monotonic() - start})
    unchanged = all(sha(root / name) == value for name, value in monitored.items())
    result = {'schema': 'g8-tools-selftest-v1', 'jobs': jobs, 'tool_inputs_sha256': monitored,
              'inputs_unchanged': unchanged, 'pds_executed': False,
              'finished': dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).isoformat(),
              'pass': unchanged and all(job['exit_code'] == 0 for job in jobs)}
    dump(out / 'selftest_receipt.json', result)
    return 0 if result['pass'] else 1


if __name__ == '__main__':
    sys.exit(main())
