"""G8 C14独立只读门禁；数值参考通过也不自动批准契约、资源、上板或生产。"""
from pathlib import Path
import argparse
import csv
import json
import re
import sys
from g8_common import (BASELINE_SHA256, CANDIDATE, SEEDS, baseline_id, check_inputs, check_plan,
                       dump, hash_map, inventory, load, need, read, safe_file, separate_output,
                       sha, trusted_baseline)
from g8_execution_records import check_batch, check_record
from g8_console import ERROR, classify
from pds_reports import parse_csv, parse_final, parse_resources, parse_rtr

PHASES = ('compile', 'synthesize', 'device_map', 'place_route', 'report_timing', 'generate_bitstream')
REQUIRED_LOGS = ['console_full.log'] + [phase + '/run.log' for phase in PHASES]
REQUIRED_NATIVE = {
    'csv': 'multiseed_summary.csv', 'clock': 'report_timing/rtr.db',
    'paths': 'report_timing/*.rtr', 'final': 'place_route/*_timing_summary_after_hold_fix.txt',
    'resources': 'place_route/*.prr', 'mapping': 'device_map/*.pcf',
    'device_database': 'device_map/*.dmr', 'map_adf': 'device_map/*_map.adf',
    'compile_adf': 'compile/*_comp.adf',
    'syn_adf': 'synthesize/*_syn.adf', 'pnr_adf': 'place_route/*_pnr.adf',
    'netlist': 'synthesize/*_syn.vm', 'bitstream': 'generate_bitstream/*.sbit'}


def check_seed(target, seed, base, batch, policy):
    before = inventory(target)
    expected = check_inputs(target, seed, base)
    receipt_sha = hash_map(batch['receipts_sha256'])[f'seed_{seed}/process_receipt.json']
    receipt = check_record(target, seed, expected, batch, receipt_sha)
    need(receipt['outcome'] == 'FINISHED', 'Execution not successful: ' + receipt['outcome'] +
         ': ' + str(receipt['error']))
    artifacts = hash_map(receipt['artifacts_sha256'])
    need(not set(artifacts) & (set(expected) | {'process_receipt.json', 'trial_inputs_sha256.json'}),
         'Artifacts overlap frozen inputs or self receipt')
    need(set(before) == set(expected) | set(artifacts) | {'trial_inputs_sha256.json', 'process_receipt.json'},
         'Unreceipted/missing file in run directory')
    checked = {name: digest for name, digest in expected.items()}
    checked['trial_inputs_sha256.json'] = base['seed_manifest_sha256'][str(seed)]
    checked['process_receipt.json'] = receipt_sha
    for name, digest in artifacts.items():
        need(sha(safe_file(target, name, auxiliary=True)) == digest, 'Artifact hash mismatch: ' + name)
        checked[name] = digest
    for name in REQUIRED_LOGS:
        need(name in artifacts, 'Missing receipted phase log: ' + name)

    native = {}
    for key, pattern in REQUIRED_NATIVE.items():
        hits = [name for name, path in before.items() if path.match(pattern)]
        need(len(hits) == 1 and hits[0] in artifacts, 'Expected one receipted native ' + key)
        native[key] = hits[0]
    console = classify(read(target / 'console_full.log'), seed, receipt['pds_shell'], policy)
    need('SYNTHETIC' not in read(target / 'console_full.log') or
         batch['baseline_sha256'] == 'SYNTHETIC_TEST_INJECTION', 'Synthetic console cannot be physical evidence')
    post = parse_csv(read(target / native['csv']), seed)
    final = parse_final(read(target / native['final']))
    clocks = parse_rtr(read(target / native['clock']))
    resources = parse_resources(read(target / native['resources']))
    netlist = read(target / native['netlist'])
    need(re.search(r'\bmodule\s+hdmi_ddr_ov5640_top\b', netlist), 'Wrong synthesized top')
    tokens = ('kr2_low_g8', 'kr2_high_g8', 'kr2_4', 'sx_product_g7', 'sy_product_g7')
    structure = {token: bool(re.search(r'\b' + token + r'(?:\b|\[)', netlist)) for token in tokens}
    warnings, errors = [], []
    for name in artifacts:
        if not name.endswith('.log'):
            continue
        for index, line in enumerate(read(target / name).splitlines(), 1):
            if re.match(r'^\s*(?:#\s*)?(?:W:|C:|WARNING\b|CRITICAL\b)', line, re.I):
                warnings.append({'file': name, 'line': index, 'text': line})
            if name != 'console_full.log' and ERROR.match(line):
                errors.append({'file': name, 'line': index, 'text': line})
    need(not errors, 'Error diagnostic in phase/nested log')
    q = final['sections']
    direction = post['closed'] == (q['Setup(Slow)']['wns'] >= 0)
    other = all(post[key] >= 0 and q[key]['wns'] >= 0 and q[key]['tns'] == 0 and q[key]['ep'] == 0
                for key in ('Setup(Fast)', 'Hold(Slow)', 'Hold(Fast)'))
    need(inventory(target).keys() == before.keys(), 'File set changed during seed collection')
    need(all(sha(safe_file(target, name, auxiliary=True)) == digest for name, digest in checked.items()),
         'Evidence changed during seed collection')
    return {'seed': seed, 'evidence_valid': True, 'execution_outcome': receipt['outcome'],
            'postroute': post, 'after_hold_fix': final, 'two_views_consistent': direction,
            'other_quadrants_met': other, 'numeric_views_pass': direction and other,
            'resources': resources, 'clock': clocks, 'console': console,
            'warning_lines': warnings, 'native_artifacts': native,
            'structure_name_evidence': structure, 'structure_status': 'MANUAL_NATIVE_MAPPING_REVIEW_REQUIRED',
            'cache_DRM_reference_pass': resources['modules']['u_cache']['DRM'] <= 12,
            'checked_hashes': checked}


def assess(root, policy='strict', _test_baseline=None):
    root = Path(root).absolute()
    need(policy in ('strict', 'startup-db-v1-g8'), 'Unknown console policy')
    base = trusted_baseline() if _test_baseline is None else _test_baseline
    plan_sha = check_plan(root, base)
    batch, batch_sha = check_batch(root, baseline_id(_test_baseline))
    rows = []
    for seed in SEEDS:
        try:
            rows.append(check_seed(root / f'seed_{seed}', seed, base, batch, policy))
        except Exception as exc:
            rows.append({'seed': seed, 'evidence_valid': False,
                         'invalid_reason': type(exc).__name__ + ': ' + str(exc)})
    need(check_plan(root, base) == plan_sha and sha(root / 'batch_receipt.json') == batch_sha,
         'Plan/batch receipt changed during collection')
    # Recheck the whole batch after collecting the final seed.
    for row in rows:
        if row['evidence_valid']:
            target = root / f"seed_{row['seed']}"
            try:
                need(set(inventory(target)) == set(row['checked_hashes']), 'Late extra/missing evidence')
                need(all(sha(safe_file(target, n, auxiliary=True)) == h
                         for n, h in row['checked_hashes'].items()), 'Late evidence mutation')
            except (OSError, ValueError) as exc:
                row.update(evidence_valid=False, invalid_reason=str(exc))
    valid = [row for row in rows if row['evidence_valid']]
    closed = sum(row['postroute']['closed'] for row in valid)
    worst = min((row['postroute']['Setup(Slow)'] for row in valid), default=None)
    complete = len(valid) == 8
    timing = complete and closed >= 7 and worst >= -0.05
    views = complete and all(row['numeric_views_pass'] for row in valid)
    ready = timing and views
    return {'schema': 'g8-gate-report-v1', 'candidate': CANDIDATE, 'latency': 14, 'II': 1,
            'baseline_sha256': baseline_id(_test_baseline), 'run_plan_sha256': plan_sha,
            'batch_receipt_sha256': batch_sha, 'console_policy': policy,
            'evidence_origin': 'SYNTHETIC_NOT_PDS' if _test_baseline is not None else
                               'USER_SUPPLIED_NOT_AUTHENTICATED',
            'planned': 8, 'valid': len(valid), 'closed': closed,
            'closure_ratio_planned': closed / 8, 'worst_valid_wns_ns': worst,
            'evidence_complete': complete, 'timing_reference_pass': timing, 'two_view_reference_pass': views,
            'numeric_reference_ready_for_review': ready,
            'reference_profile': {'min_valid': 8, 'min_closed': 7, 'min_worst_wns_ns': -0.05,
                                  'status': 'CONSERVATIVE_REFERENCE_NOT_FORMAL_G8_APPROVAL'},
            'cache_DRM_reference_pass': complete and all(row['cache_DRM_reference_pass'] for row in valid),
            'warning_count': sum(len(row['warning_lines']) for row in valid),
            'warning_count_scope': 'VALID_SEEDS_ONLY_ALL_RAW_LOGS_RETAINED',
            'formal_C14_contract': 'PENDING_EXTERNAL_REGISTRATION',
            'resource_acceptance': 'NOT_DECLARED_OLD_BUDGETS_NOT_WAIVED',
            'structure_acceptance': 'MANUAL_NATIVE_MAPPING_REVIEW_REQUIRED',
            'functional_acceptance': 'SEPARATE_MATCHED_SHA_REGRESSION_REQUIRED',
            'throughput_acceptance': 'SEPARATE_REAL_PARAMETER_REGRESSION_REQUIRED',
            'board_acceptance': 'NOT_TESTED', 'overall_G8_acceptance': 'NOT_DECLARED',
            'production_promotion': False, 'seeds': rows, 'exit_code': 3 if ready else 2}


def write_report(result, out):
    out.mkdir(parents=True, exist_ok=False)
    dump(out / 'report.json', result)
    with (out / 'summary.csv').open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['seed', 'evidence_valid', 'post_WNS', 'post_TNS', 'final_WNS',
                         'two_views', 'top_APM_percent', 'cache_DRM', 'warning_count', 'invalid_reason'])
        for row in result.get('seeds', []):
            if row['evidence_valid']:
                writer.writerow([row['seed'], True, row['postroute']['Setup(Slow)'], row['postroute']['tns'],
                                 row['after_hold_fix']['sections']['Setup(Slow)']['wns'],
                                 row['numeric_views_pass'], row['resources']['device']['APM']['percent'],
                                 row['resources']['modules']['u_cache']['DRM'], len(row['warning_lines']), ''])
            else:
                writer.writerow([row['seed'], False] + [''] * 7 + [row['invalid_reason']])
    dump(out / 'output_sha256.json', {p.name: sha(p) for p in out.iterdir() if p.is_file()})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--console-policy', choices=('strict', 'startup-db-v1-g8'), default='strict')
    args = parser.parse_args()
    separate_output(args.run, args.out)
    try:
        result = assess(args.run, args.console_policy)
    except (ValueError, KeyError, TypeError, OSError) as exc:
        result = {'schema': 'g8-gate-report-v1', 'fatal_input_error': str(exc), 'planned': 8,
                  'valid': 0, 'seeds': [], 'overall_G8_acceptance': 'NOT_DECLARED', 'exit_code': 2}
    write_report(result, args.out)
    print(json.dumps({key: value for key, value in result.items() if key != 'seeds'},
                     ensure_ascii=False, indent=2))
    return result['exit_code']


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError) as exc:
        print('GATE_TOOL_ERROR: ' + str(exc), file=sys.stderr)
        sys.exit(1)
