"""G8 flow completion is mandatory under both strict and opt-in startup policies."""
import re

MESSAGES = ['E: Please rerun to generate compile db.',
            'E: Flow-0011: PNR or PLC design DB file is not found.']
ERROR = re.compile(r'^\s*(?:#\s*)?(?:E:|ERROR\b|FATAL\b|\*\*\s*(?:Error|Fatal):|Traceback \()', re.I)


def classify(text, seed, shell, policy='strict'):
    def need(ok, why):
        if not ok:
            raise ValueError(why)
    need(policy in ('strict', 'startup-db-v1-g8'), 'Unknown console policy')
    need(not any(ord(c) < 32 and c not in '\r\n\t' for c in text), 'Control-coded console evidence')
    lines = text.splitlines()
    errors = [dict(line=i+1, text=s) for i, s in enumerate(lines) if ERROR.match(s)]
    need(len(lines) >= 5, 'Console truncated')
    need(re.fullmatch(r'License checkout: fabric_shell from .+[\\/]PDS_2022\.2-SP6\.4[\\/]license[\\/][^\\/]+\.lic', lines[0]),
         'Unsupported SP6.4 startup/license prefix')
    need(lines[1] == 'Compiling architecture definition.', 'Unexpected startup architecture prefix')
    offset = 2
    if errors:
        need(policy == 'startup-db-v1-g8', 'Console error under strict policy')
        need([e['text'] for e in errors] == MESSAGES and lines[2:4] == MESSAGES,
             'Unexpected, repeated, relocated or altered error diagnostics')
        offset = 4
    need(re.fullmatch(r"Analyzing project file '[^'\r\n]+/seed_"+str(seed)+r"/run_trial\.pds'\.", lines[offset]),
         'Startup project/seed mismatch')
    arch = 'set_arch -family Logos2 -device PG2L100H -speedgrade -6 -package FBG676'
    need(lines[offset+1] == 'Executing : '+arch, 'Unexpected first architecture command')
    need(str(shell).replace('\\', '/').endswith('/PDS_2022.2-SP6.4/bin/pds_shell.exe'),
         'Receipt shell is not supported SP6.4 executable path')
    stages = ['Executing : '+arch+' successfully.',
              'Executing : compile -top_module hdmi_ddr_ov5640_top successfully.',
              'Executing : synthesize -ads -selected_syn_tool_opt 2 successfully.',
              'Executing : dev_map successfully.', 'G8_PHASE=DEV_MAP_DONE',
              'Executing : pnr -gplace_seed %d -groute_seed %d successfully.' % (seed, seed),
              'G8_PHASE=PNR_DONE', 'Executing : report_timing successfully.',
              'Executing : gen_bit_stream successfully.', 'G8_PHASE=FINISHED']
    positions = []
    for stage in stages:
        hits = [i for i, s in enumerate(lines) if s == stage]
        need(len(hits) == 1, 'Missing or repeated success stage: '+stage)
        positions.append(hits[0])
    need(positions == sorted(positions) and positions[0] > offset+1, 'Success stages out of order')
    phases = [s for s in lines if re.match(r'G\d+_PHASE=', s)]
    need(phases == ['G8_PHASE=DEV_MAP_DONE', 'G8_PHASE=PNR_DONE', 'G8_PHASE=FINISHED'], 'Wrong phase sequence')
    need(not any(s.strip() for s in lines[positions[-1]+1:]), 'Unexpected output after FINISHED')
    return dict(policy=policy, accepted=True, accepted_startup_diagnostics=errors,
                classification='RECOVERED_STARTUP_DB_DIAGNOSTICS' if errors else 'ORDERED_BUILD_NO_ERRORS',
                stage_count=len(stages))
