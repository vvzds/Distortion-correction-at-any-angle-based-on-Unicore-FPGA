"""执行记录契约：成功、失败、超时和中断均保留；哈希不认证真实物理执行。"""
import re
from g8_common import (CANDIDATE, SEEDS, VERSION, baseline_id, finite_positive,
                       hash_map, load, need, safe_file, sha, shell_path, timeline)

OUTCOMES = ('FINISHED', 'FAILED', 'TIMED_OUT', 'INTERRUPTED', 'START_FAILED', 'NOT_STARTED')


def check_batch(root, baseline_sha):
    path = safe_file(root, 'batch_receipt.json')
    value = load(path)
    need(value['schema'] == 'g8-batch-exec-v1' and value['candidate'] == CANDIDATE and
         value['baseline_sha256'] == baseline_sha, 'Batch identity differs')
    need(value['seeds'] == SEEDS and all(type(s) is int for s in value['seeds']), 'Batch seed set differs')
    need(value['evidence_origin'] == ('SYNTHETIC_NOT_PDS' if baseline_sha == 'SYNTHETIC_TEST_INJECTION'
                                      else 'EXTERNAL_TOOL_ATTEMPT_NOT_AUTHENTICATED'), 'Wrong evidence origin')
    timeline(value)
    finite_positive(value['timeout_seconds_per_seed'], 'batch timeout')
    need(value['status'] in ('COMPLETED', 'INTERRUPTED'), 'Unfinished batch receipt')
    shell_path(value['pds_shell'])
    digest = value['pds_shell_sha256_before']
    need(isinstance(digest, str) and re.fullmatch('[A-F0-9]{64}', digest) and
         value['pds_shell_sha256_after'] == digest, 'Tool identity missing or changed')
    need(value['pds_version_expected'] == VERSION, 'Wrong requested PDS version')
    receipts = hash_map(value['receipts_sha256'])
    need(set(receipts) == {f'seed_{s}/process_receipt.json' for s in SEEDS}, 'Eight process receipts required')
    return value, sha(path)


def check_record(root, seed, expected, batch, receipt_sha):
    path = safe_file(root, 'process_receipt.json')
    need(sha(path) == receipt_sha, 'Process receipt differs from batch hash')
    value = load(path)
    need(value['schema'] == 'g8-process-v1' and value['candidate'] == CANDIDATE and
         value['baseline_sha256'] == batch['baseline_sha256'], 'Process identity differs')
    need(all(type(value[key]) is int and value[key] == seed for key in
             ('seed', 'placement_seed', 'route_seed')), 'Receipt seed/type differs')
    need(value['pds_shell'] == batch['pds_shell'] and value['pds_shell_sha256_before'] ==
         value['pds_shell_sha256_after'] == batch['pds_shell_sha256_before'], 'Process tool identity differs')
    need(value['argv'] == [value['pds_shell'], '-file', 'run_trial.tcl'], 'Unexpected tool command')
    cwd = value['cwd'].replace('\\', '/')
    need(cwd.endswith('/seed_' + str(seed)) and ':/' in cwd, 'Absolute Windows seed cwd required')
    begin, end = timeline(value)
    batch_begin, batch_end = timeline(batch)
    need(batch_begin <= begin <= end <= batch_end, 'Process outside batch time interval')
    limit = finite_positive(value['timeout_seconds'], 'process timeout')
    need(limit == batch['timeout_seconds_per_seed'], 'Timeout differs from batch')
    outcome = value['outcome']
    need(outcome in OUTCOMES, 'Unknown process outcome')
    need(value['timed_out'] is (outcome == 'TIMED_OUT'), 'Timeout flag contradicts outcome')
    need(value['interrupted'] is (outcome == 'INTERRUPTED'), 'Interrupt flag contradicts outcome')
    need(value['evidence_origin'] == batch['evidence_origin'], 'Process evidence origin differs')
    need(value['inputs_unchanged'] is True and hash_map(value['inputs_before']) == expected ==
         hash_map(value['inputs_after']), 'Input drift or incomplete before/after hashes')
    code, pid = value['exit_code'], value['pid']
    need(code is None or type(code) is int, 'Invalid exit-code type')
    need(pid is None or (type(pid) is int and pid > 0), 'Invalid PID')
    if pid is not None:
        path = safe_file(root, 'process_started.json')
        need(sha(path) == hash_map(value['artifacts_sha256'])['process_started.json'], 'Child-start hash differs')
        started = load(path)
        need(started['schema'] == 'g8-child-start-v1' and type(started['pid']) is int and
             started['pid'] == pid and started['argv'] == value['argv'] and started['cwd'] == value['cwd'] and
             started['started'] == value['started'], 'Child-start record contradicts final receipt')
    if outcome == 'FINISHED':
        need(code == 0 and pid is not None and value['error'] is None and value['tree_termination'] is None,
             'Finished outcome contradicts execution result')
        need(value['seconds'] <= limit + 5, 'Finished execution exceeds timeout')
    else:
        need(isinstance(value['error'], str) and value['error'], 'Failure reason required')
        if outcome == 'FAILED':
            need(type(code) is int and code != 0 and pid is not None, 'Failed outcome requires nonzero exit')
        if outcome in ('START_FAILED', 'NOT_STARTED'):
            need(pid is None and code is None, 'Unstarted process has PID or exit code')
        if outcome in ('TIMED_OUT', 'INTERRUPTED'):
            need(pid is not None and isinstance(value['tree_termination'], dict) and
                 value['tree_termination']['attempted'] is True, 'Interrupted child tree not accounted for')
    return value
