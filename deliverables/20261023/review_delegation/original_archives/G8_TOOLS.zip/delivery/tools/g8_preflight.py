"""只读检查G8冻结八种子输入；不会启动PDS。"""
from pathlib import Path
import argparse
import json
import sys
from g8_common import dump, preflight, separate_output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', required=True, type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    if args.out:
        separate_output(args.inputs, args.out)
    result = preflight(args.inputs)
    if args.out:
        args.out.mkdir(parents=True)
        dump(args.out / 'preflight.json', result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print('PREFLIGHT_FAIL: ' + str(exc), file=sys.stderr)
        sys.exit(2)
