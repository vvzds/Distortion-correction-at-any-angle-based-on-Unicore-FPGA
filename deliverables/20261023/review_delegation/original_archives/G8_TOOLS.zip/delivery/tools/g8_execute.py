"""G8独立八种子执行器；默认仅预检，显式--execute才在新目录启动PDS。"""
from pathlib import Path
import argparse
import datetime as dt
import json
import os
import signal
import shutil
import subprocess
import sys
import time
from g8_common import (CANDIDATE, SEEDS, VERSION, baseline_id, check_inputs, dump,
                       finite_positive, inventory, need, preflight, separate_output,
                       sha, shell_path, trusted_baseline)


def now():
    # 所有执行记录显式带北京时间偏移；耗时另用monotonic。
    return dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).isoformat()


def terminate_tree(child):
    result = {'attempted': True, 'method': 'taskkill-tree' if os.name == 'nt' else 'kill-process-group'}
    try:
        if os.name == 'nt':
            killed = subprocess.run(['taskkill', '/PID', str(child.pid), '/T', '/F'],
                                    capture_output=True, timeout=20,
                                    creationflags=subprocess.CREATE_NO_WINDOW)
            result['exit_code'] = killed.returncode
            result['output'] = (killed.stdout + killed.stderr).decode('utf-8', errors='replace')
        else:
            os.killpg(child.pid, signal.SIGKILL)
            result['exit_code'] = 0
    except (OSError, subprocess.TimeoutExpired) as exc:
        result['error'] = type(exc).__name__ + ': ' + str(exc)
    try:
        child.wait(timeout=10)
    except subprocess.TimeoutExpired:
        child.kill()
        child.wait(timeout=10)
        result['fallback_direct_kill'] = True
    result['parent_reaped'] = child.poll() is not None
    return result


def run_process(argv, cwd, timeout):
    """仅管理本次创建的子进程；单测可用普通Python子进程验证超时，不冒充PDS。"""
    begin, started = now(), time.monotonic()
    result = {'started': begin, 'pid': None, 'exit_code': None, 'outcome': 'START_FAILED',
              'error': None, 'timed_out': False, 'interrupted': False, 'tree_termination': None}
    child = None
    with (cwd / 'console_full.log').open('wb') as console:
        try:
            options = {'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {'start_new_session': True}
            child = subprocess.Popen(argv, cwd=cwd, stdin=subprocess.DEVNULL, stdout=console,
                                     stderr=subprocess.STDOUT, shell=False, **options)
            result['pid'] = child.pid
            dump(cwd / 'process_started.json', {'schema': 'g8-child-start-v1', 'pid': child.pid,
                 'argv': argv, 'cwd': str(cwd.resolve()), 'started': begin})
            result['exit_code'] = child.wait(timeout=timeout)
            result['outcome'] = 'FINISHED' if result['exit_code'] == 0 else 'FAILED'
            if result['exit_code'] != 0:
                result['error'] = 'PDS process exited with code ' + str(result['exit_code'])
        except subprocess.TimeoutExpired:
            result.update(outcome='TIMED_OUT', timed_out=True, error='Per-seed timeout exceeded')
            result['tree_termination'] = terminate_tree(child)
            result['exit_code'] = child.returncode
        except KeyboardInterrupt:
            result.update(outcome='INTERRUPTED', interrupted=True, error='Operator interrupted execution')
            if child is not None:
                result['tree_termination'] = terminate_tree(child)
                result['exit_code'] = child.returncode
            else:
                result.update(outcome='START_FAILED', interrupted=False)
        except OSError as exc:
            result['error'] = type(exc).__name__ + ': ' + str(exc)
            if child is not None:
                result['tree_termination'] = terminate_tree(child)
                result.update(outcome='FAILED', exit_code=child.returncode)
    result.update(finished=now(), seconds=time.monotonic() - started)
    return result


def run_batch(inputs, out, shell, timeout, _test_baseline=None, _test_process=None):
    base = trusted_baseline() if _test_baseline is None else _test_baseline
    preflight(inputs, _test_baseline)
    separate_output(inputs, out)
    shell = Path(shell).absolute()
    shell_path(str(shell))
    need(shell.is_file(), 'PDS shell does not exist')
    finite_positive(timeout, 'per-seed timeout')
    binary_sha = sha(shell)
    started, clock_start = now(), time.monotonic()
    # 只复制已冻结的输入；从不在上一轮运行目录内增量编译。
    shutil.copytree(inputs, out)
    batch = {'schema': 'g8-batch-exec-v1', 'candidate': CANDIDATE,
             'baseline_sha256': baseline_id(_test_baseline), 'seeds': SEEDS,
             'pds_shell': str(shell), 'pds_shell_sha256_before': binary_sha,
             'pds_version_expected': VERSION, 'timeout_seconds_per_seed': timeout,
             'started': started, 'status': 'RUNNING', 'receipts_sha256': {},
             'evidence_origin': 'SYNTHETIC_NOT_PDS' if _test_baseline is not None else
                                'EXTERNAL_TOOL_ATTEMPT_NOT_AUTHENTICATED',
             'formal_acceptance': 'NOT_DECLARED', 'production_promotion': False}
    interrupted = False
    process = run_process if _test_process is None else _test_process
    dump(out / 'batch_receipt.json', batch)
    for seed in SEEDS:
        target = out / f'seed_{seed}'
        # 即使失败、超时、中断，也为八轮各保留一个记录。
        expected = base['seed_inputs'][str(seed)]
        before = {name: sha(target / name) if (target / name).is_file() else 'MISSING' for name in expected}
        identity_error = None
        try:
            check_inputs(target, seed, base, clean=True)
            need(sha(shell) == binary_sha, 'PDS binary changed before launch')
        except (ValueError, OSError) as exc:
            identity_error = str(exc)
        argv = [str(shell), '-file', 'run_trial.tcl']
        if interrupted or identity_error:
            stamp = now()
            result = {'started': stamp, 'finished': stamp, 'seconds': 0.0, 'pid': None,
                      'exit_code': None, 'outcome': 'NOT_STARTED', 'timed_out': False,
                      'interrupted': False, 'tree_termination': None,
                      'error': identity_error or 'Not started after operator interruption'}
        else:
            result = process(argv, target, timeout)
        interrupted = interrupted or result['outcome'] == 'INTERRUPTED'
        after = {name: sha(target / name) if (target / name).is_file() else 'MISSING' for name in expected}
        generated = {name: sha(path) for name, path in inventory(target).items()
                     if name not in expected and name not in ('trial_inputs_sha256.json', 'process_receipt.json')}
        receipt = {'schema': 'g8-process-v1', 'candidate': CANDIDATE,
                   'baseline_sha256': batch['baseline_sha256'], 'seed': seed,
                   'placement_seed': seed, 'route_seed': seed, 'pds_shell': str(shell),
                   'pds_shell_sha256_before': binary_sha,
                   'pds_shell_sha256_after': sha(shell) if shell.is_file() else 'MISSING',
                   'argv': argv, 'cwd': str(target.resolve()), 'timeout_seconds': timeout,
                   'inputs_before': before, 'inputs_after': after,
                   'inputs_unchanged': before == after == expected, 'artifacts_sha256': generated,
                   'evidence_origin': batch['evidence_origin'], **result}
        dump(target / 'process_receipt.json', receipt)
        batch['receipts_sha256'][f'seed_{seed}/process_receipt.json'] = sha(target / 'process_receipt.json')
        # 每轮提交一次中间批记录；突然断电保留RUNNING，不冒充已完整结束。
        dump(out / 'batch_receipt.json', batch)
        print('G8_EXEC seed=%d outcome=%s' % (seed, result['outcome']), flush=True)
    batch.update(status='INTERRUPTED' if interrupted else 'COMPLETED', finished=now(),
                 seconds=time.monotonic() - clock_start,
                 pds_shell_sha256_after=sha(shell) if shell.is_file() else 'MISSING')
    dump(out / 'batch_receipt.json', batch)
    return batch


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--pds-shell', type=Path)
    parser.add_argument('--timeout-seconds', type=float, default=7200)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if not args.execute:
        result = preflight(args.inputs)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    need(args.out is not None and args.pds_shell is not None, '--execute requires --out and --pds-shell')
    run_batch(args.inputs.resolve(), args.out.resolve(), args.pds_shell, args.timeout_seconds)
    # 执行完成不等于构建或验收成功；以每轮结果和门禁另行判定。
    outcomes = [__import__('g8_common').load(args.out / f'seed_{s}/process_receipt.json')['outcome'] for s in SEEDS]
    return 0 if all(value == 'FINISHED' for value in outcomes) else 2


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError, KeyError) as exc:
        print('EXECUTION_TOOL_ERROR: ' + str(exc), file=sys.stderr)
        sys.exit(1)
