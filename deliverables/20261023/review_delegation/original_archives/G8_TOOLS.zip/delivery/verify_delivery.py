"""核验本轮发行文件集、大小和SHA256；不表示硬件或画质验收。"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import sys
import zipfile

MANIFEST = 'MANIFEST_SHA256.json'


def digest(stream):
    h = hashlib.sha256()
    size = 0
    for block in iter(lambda: stream.read(1024 * 1024), b''):
        h.update(block)
        size += len(block)
    return {'bytes': size, 'sha256': h.hexdigest()}


def validate_manifest(data):
    if data.get('schema') != 'yx-release-sha256-v1' or not data.get('files'):
        raise ValueError('Invalid manifest schema')
    for name, item in data['files'].items():
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or '\\' in name or name == MANIFEST:
            raise ValueError('Unsafe manifest path: ' + name)
        if not isinstance(item['bytes'], int) or item['bytes'] < 0 or len(item['sha256']) != 64:
            raise ValueError('Invalid file identity: ' + name)
    return data['files']


def verify_tree(root):
    expected = validate_manifest(json.loads((root / MANIFEST).read_text(encoding='utf-8')))
    actual = {p.relative_to(root).as_posix(): p for p in root.rglob('*') if p.is_file()}
    actual.pop(MANIFEST, None)
    if actual.keys() != expected.keys():
        raise ValueError('File set differs: missing=' + repr(sorted(expected.keys() - actual.keys())) +
                         ' extra=' + repr(sorted(actual.keys() - expected.keys())))
    for name, path in actual.items():
        with path.open('rb') as stream:
            if digest(stream) != expected[name]:
                raise ValueError('File identity differs: ' + name)
    return len(expected), sum(item['bytes'] for item in expected.values())


def verify_zip(path):
    with zipfile.ZipFile(path) as archive:
        entries = [item for item in archive.infolist() if not item.is_dir()]
        if len({item.filename for item in entries}) != len(entries):
            raise ValueError('Duplicate ZIP entries')
        manifests = [item.filename for item in entries
                     if PurePosixPath(item.filename).name == MANIFEST
                     and len(PurePosixPath(item.filename).parts) <= 2]
        if len(manifests) != 1:
            raise ValueError('Exactly one top-level release manifest required')
        manifest_path = manifests[0]
        prefix = manifest_path[:-len(MANIFEST)]
        expected = validate_manifest(json.loads(archive.read(manifest_path).decode('utf-8')))
        names = {item.filename for item in entries}
        if names != {prefix + name for name in expected} | {manifest_path}:
            raise ValueError('ZIP file set differs from manifest')
        # Streaming each entry verifies ZIP CRC as well as SHA256.
        for name, identity in expected.items():
            with archive.open(prefix + name) as stream:
                if digest(stream) != identity:
                    raise ValueError('ZIP payload identity differs: ' + name)
    return len(expected), sum(item['bytes'] for item in expected.values())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--zip', type=Path)
    args = parser.parse_args()
    count, size = verify_zip(args.zip) if args.zip else verify_tree(args.root)
    print(json.dumps({'status': 'PASS', 'files': count, 'payload_bytes': size,
                      'mode': 'zip-crc-and-sha256' if args.zip else 'tree-sha256',
                      'hardware_acceptance': 'NOT_DECLARED'}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, zipfile.BadZipFile) as exc:
        print('FAIL: ' + str(exc), file=sys.stderr)
        sys.exit(1)
