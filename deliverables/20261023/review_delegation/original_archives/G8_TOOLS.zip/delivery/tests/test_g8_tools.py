"""G8门禁故障注入及执行器自校验；全部夹具为SYNTHETIC，不运行PDS。"""
from pathlib import Path
import copy
import json
import os
import subprocess
import sys
import unittest
import uuid
from unittest.mock import patch
from make_fixture import *
import g8_common as C
import g8_console as LOG
import g8_execute as X
import g8_gate as G
import g8_check_execution as E

SCRATCH = HOME.parent.parent / 'test_runs'
SCRATCH.mkdir(parents=True, exist_ok=True)


class GateTests(unittest.TestCase):
    def setUp(self):
        self.case = SCRATCH / uuid.uuid4().hex
        self.case.mkdir()
        self.root = self.case / 'synthetic_run'
        self.base = make_prepared(self.root)
        make_run(self.root, self.base)
        self.seed = self.root / 'seed_2'

    def assess(self, policy='strict'):
        return G.assess(self.root, policy, _test_baseline=self.base)

    def bad(self):
        result = self.assess()
        self.assertFalse(result['seeds'][0]['evidence_valid'], result['seeds'][0])
        self.assertEqual(result['exit_code'], 2)
        self.assertEqual(result['planned'], 8)
        self.assertEqual(result['overall_G8_acceptance'], 'NOT_DECLARED')
        return result

    def change(self, name, text, receipt=True):
        path = self.seed / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding='utf-8')
        if receipt:
            refresh(self.root, 2)

    def edit_receipt(self, **changes):
        path = self.seed / 'process_receipt.json'
        value = load(path)
        value.update(changes)
        dump(path, value)
        refresh(self.root, 2)

    def timing(self, seed, wns, final_wns=None, fast=1.583, hold=.143, fast_hold=.102):
        target = self.root / f'seed_{seed}'
        (target / 'multiseed_summary.csv').write_text(
            native(wns=wns, seed=seed, fast=fast, hold=hold, fast_hold=fast_hold), encoding='utf-8')
        (target / 'place_route/top_timing_summary_after_hold_fix.txt').write_text(
            final(wns if final_wns is None else final_wns, fast, hold, fast_hold), encoding='utf-8')
        refresh(self.root, seed)

    def test_complete_numeric_is_never_formal_acceptance(self):
        value = self.assess()
        self.assertEqual(value['valid'], 8)
        self.assertEqual(value['closed'], 8)
        self.assertTrue(value['numeric_reference_ready_for_review'])
        self.assertEqual(value['exit_code'], 3)
        self.assertEqual(value['evidence_origin'], 'SYNTHETIC_NOT_PDS')
        self.assertEqual(value['formal_C14_contract'], 'PENDING_EXTERNAL_REGISTRATION')
        self.assertFalse(value['production_promotion'])
        self.assertFalse(value['cache_DRM_reference_pass'])
        self.assertEqual(value['seeds'][0]['resources']['device']['APM']['percent'], 43.75)

    def test_seven_closed_one_exact_floor(self):
        self.timing(2, -.05)
        self.assertTrue(self.assess()['numeric_reference_ready_for_review'])

    def test_below_floor_not_ready(self):
        self.timing(2, -.050001)
        self.assertFalse(self.assess()['timing_reference_pass'])

    def test_six_closed_not_ready(self):
        self.timing(2, -.01)
        self.timing(3, -.01)
        self.assertFalse(self.assess()['timing_reference_pass'])

    def test_zero_is_closed(self):
        self.timing(2, 0)
        self.assertEqual(self.assess()['closed'], 8)

    def test_direction_disagreement_is_retained(self):
        self.timing(2, -.012, .001)
        result = self.assess()
        self.assertTrue(result['timing_reference_pass'])
        self.assertFalse(result['two_view_reference_pass'])

    def test_failed_seed_stays_in_denominator(self):
        (self.seed / 'report_timing/rtr.db').unlink()
        result = self.bad()
        self.assertEqual(result['valid'], 7)
        self.assertEqual(result['closure_ratio_planned'], 7 / 8)

    def test_resource_mismatch_one_lut_is_rejected(self):
        text = C.read(self.seed / 'place_route/top.prr')
        import re
        changed, count = re.subn(r'(\|\s*hdmi_ddr_ov5640_top\s*\|\s*)(\d+)',
                                lambda m: m[1] + str(int(m[2]) + 1), text)
        self.assertEqual(count, 1)
        self.change('place_route/top.prr', changed)
        self.bad()

    def test_legal_empty_auxiliary_only(self):
        self.change('compile/error_info.txt', '')
        self.change('place_route/layers.txt', '')
        self.assertEqual(self.assess()['valid'], 8)

    def test_warnings_preserved_without_autoapproval(self):
        self.change('compile/run.log', 'W: io delay missing\nC: share-pin\n')
        result = self.assess()
        self.assertEqual(result['warning_count'], 2)
        self.assertEqual(result['overall_G8_acceptance'], 'NOT_DECLARED')

    def test_missing_structure_names_remains_manual(self):
        self.change('synthesize/top_syn.vm', 'module hdmi_ddr_ov5640_top; endmodule\n')
        row = self.assess()['seeds'][0]
        self.assertTrue(row['evidence_valid'])
        self.assertFalse(row['structure_name_evidence']['kr2_low_g8'])
        self.assertEqual(row['structure_status'], 'MANUAL_NATIVE_MAPPING_REVIEW_REQUIRED')

    def test_rehashed_source_cannot_replace_trusted_inputs(self):
        self.change('source/core.v', 'OLD_G7_OR_NEW_UNAPPROVED_RTL\n')
        value = load(self.seed / 'trial_inputs_sha256.json')
        value['source/core.v'] = sha(self.seed / 'source/core.v')
        dump(self.seed / 'trial_inputs_sha256.json', value)
        self.edit_receipt(inputs_before=value, inputs_after=value)
        self.bad()

    def test_output_hashes_and_no_overwrite(self):
        out = self.case / 'report'
        G.write_report(self.assess(), out)
        for name, digest in load(out / 'output_sha256.json').items():
            self.assertEqual(sha(out / name), digest)
        with self.assertRaises(FileExistsError):
            G.write_report(self.assess(), out)

    def test_strict_startup_error_rejected_optin_exactly_accepted(self):
        self.change('console_full.log', console(2, startup=True))
        self.bad()
        self.assertEqual(self.assess('startup-db-v1-g8')['valid'], 8)

    def test_unapproved_policy_not_accepted(self):
        with self.assertRaises(ValueError):
            self.assess('startup-db-v1-g7')

    def test_process_receipt_hash_mutation(self):
        path = self.seed / 'process_receipt.json'
        path.write_text(path.read_text(encoding='utf-8') + '\n', encoding='utf-8')
        self.bad()

    def test_nonzero_process_is_valid_failure_record_but_gate_fails(self):
        self.edit_receipt(outcome='FAILED', exit_code=7, error='Synthetic process failure')
        self.assertEqual(E.inspect(self.root, self.base)['records_valid'], 8)
        self.bad()

    def test_timeout_is_valid_failure_record_but_gate_fails(self):
        self.edit_receipt(outcome='TIMED_OUT', timed_out=True, exit_code=-1,
                          error='Synthetic timeout', tree_termination={'attempted': True})
        result = E.inspect(self.root, self.base)
        self.assertEqual(result['records_valid'], 8)
        self.assertEqual(result['completed'], 7)
        self.bad()

    def test_batch_hash_stability_detected(self):
        import g8_gate
        original = g8_gate.check_seed
        calls = []
        def mutate(*args):
            result = original(*args)
            calls.append(1)
            if len(calls) == 8:
                p = self.root / 'batch_receipt.json'
                p.write_text(p.read_text(encoding='utf-8') + '\n', encoding='utf-8')
            return result
        with patch.object(g8_gate, 'check_seed', side_effect=mutate):
            with self.assertRaisesRegex(ValueError, 'changed during collection'):
                self.assess()

    def test_late_seed_mutation_detected(self):
        original = G.check_seed
        calls = []
        def mutate(*args):
            result = original(*args)
            calls.append(1)
            if len(calls) == 8:
                (self.seed / 'place_route/top.prr').write_text('LATE_MUTATION', encoding='utf-8')
            return result
        with patch.object(G, 'check_seed', side_effect=mutate):
            self.bad()


def file_fault(name, value, refresh_hash=True):
    def test(self):
        self.change(name, value(self) if callable(value) else value, receipt=refresh_hash)
        self.bad()
    return test


FILE_FAULTS = {
    'old_g7_phase': ('console_full.log', lambda s: console(2).replace('G8_PHASE', 'G7_PHASE')),
    'wrong_console_seed': ('console_full.log', console(3)),
    'extra_console_phase': ('console_full.log', console(2) + 'G8_PHASE=FINISHED\n'),
    'late_console_text': ('console_full.log', console(2) + 'unexpected footer\n'),
    'console_error': ('console_full.log', console(2).replace('G8_PHASE=PNR_DONE', 'E: mapping failed\nG8_PHASE=PNR_DONE')),
    'empty_console': ('console_full.log', ''),
    'empty_phase': ('compile/run.log', ''),
    'phase_error': ('device_map/run.log', 'E: internal failure\n'),
    'nested_phase_error': ('compile/parse_design/run.log', 'FATAL parser failure\n'),
    'extra_source': ('source/unlisted.v', 'module extra; endmodule\n'),
    'extra_ip': ('ipcore/unknown.idf', 'SYNTHETIC_EXTRA_IP\n'),
    'unknown_empty_artifact': ('place_route/empty_other.txt', ''),
    'duplicate_bitstream': ('generate_bitstream/extra.sbit', 'SYNTHETIC_DUPLICATE\n'),
    'wrong_native_seed': ('multiseed_summary.csv', native(seed=3)),
    'wrong_native_version': ('multiseed_summary.csv', native(seed=2).replace('SP6.4', 'SP6.1')),
    'nan_native': ('multiseed_summary.csv', native(wns=float('nan'), seed=2)),
    'missing_quadrant': ('place_route/top_timing_summary_after_hold_fix.txt', final().replace('Hold Summary(Fast Corner):', 'Other Summary(Fast Corner):')),
    'wrong_clock': ('report_timing/rtr.db', rtr().replace('8.0000', '7.0000')),
    'xml_entity': ('report_timing/rtr.db', '<!DOCTYPE tables><tables/>'),
    'wrong_top': ('synthesize/top_syn.vm', 'module different_top; endmodule\n'),
    'artifact_unrehashed': ('device_map/top.pcf', 'MUTATED_WITHOUT_HASH\n', False),
    'extra_unreceipted_extension': ('new_artifact.xyz', 'UNRECEIPTED\n', False),
}
for label, args in FILE_FAULTS.items():
    setattr(GateTests, 'test_file_fault_' + label, file_fault(*args))


RECEIPT_FAULTS = {
    'bool_seed': {'seed': True}, 'wrong_seed': {'route_seed': 3},
    'exit_bool': {'exit_code': False}, 'finished_nonzero': {'exit_code': 3},
    'pid_bool': {'pid': True}, 'pid_missing': {'pid': None},
    'unknown_outcome': {'outcome': 'OK'}, 'claimed_timeout': {'timed_out': True},
    'claimed_interrupt': {'interrupted': True}, 'declared_input_drift': {'inputs_unchanged': False},
    'wrong_tool_hash': {'pds_shell_sha256_after': 'B' * 64},
    'wrong_argv': {'argv': [SHELL, '-file', 'build.tcl']},
    'missing_timezone': {'started': '2026-10-23T12:00:01'},
    'reversed_time': {'finished': '2026-10-23T11:00:00+08:00'},
    'wrong_seconds': {'seconds': 600}, 'negative_seconds': {'seconds': -1},
    'wrong_limit': {'timeout_seconds': 3}, 'wrong_cwd_seed': {'cwd': 'D:/synthetic/seed_3'},
    'wrong_candidate': {'candidate': 'G7'}, 'wrong_baseline': {'baseline_sha256': 'G7'},
    'success_has_error': {'error': 'error'},
}
for label, changes in RECEIPT_FAULTS.items():
    def test(self, changes=changes):
        self.edit_receipt(**changes)
        self.bad()
    setattr(GateTests, 'test_receipt_fault_' + label, test)


class CommonAndExecutionTests(unittest.TestCase):
    def setUp(self):
        self.case = SCRATCH / uuid.uuid4().hex
        self.case.mkdir()

    def test_frozen_real_preflight(self):
        result = C.preflight(HOME.parent / 'prepared_inputs')
        self.assertEqual([r['inputs'] for r in result['seeds']], [147] * 8)
        self.assertFalse(result['pds_executed'])

    def test_tampered_packaged_baseline(self):
        (self.case / 'data').mkdir()
        (self.case / 'data/g8_baseline.json').write_text('{}', encoding='utf-8')
        with patch.object(C, 'HOME', self.case):
            with self.assertRaisesRegex(ValueError, 'corrupted'):
                C.trusted_baseline()

    def test_duplicate_and_nonfinite_json(self):
        p = self.case / 'bad.json'
        for text in ('{"a":1,"a":2}', '{"x":NaN}', '{"x":Infinity}'):
            p.write_text(text, encoding='utf-8')
            with self.assertRaises(ValueError):
                C.load(p)

    def test_unsafe_relative_names(self):
        for name in ('../outside', '/absolute', 'D:/file', 'a\\b', './a', 'a//b', 'a./x', 'a /x'):
            with self.assertRaises(ValueError):
                C.relative_name(name)

    def test_case_aliased_hash_map(self):
        with self.assertRaises(ValueError):
            C.hash_map({'a.v': 'A' * 64, 'A.v': 'B' * 64})

    def test_link_rejected(self):
        p = self.case / 'a.txt'
        p.write_text('test', encoding='utf-8')
        original = C.reparse
        with patch.object(C, 'reparse', side_effect=lambda path: path == p or original(path)):
            with self.assertRaises(ValueError):
                C.safe_file(self.case, 'a.txt')

    def test_output_inside_source_rejected(self):
        with self.assertRaises(ValueError):
            C.separate_output(self.case, self.case / 'out')

    def test_preflight_rejects_old_plan_and_extra_seed(self):
        p = self.case / 'prepared'
        base = make_prepared(p)
        (p / 'seed_99').mkdir()
        with self.assertRaises(ValueError):
            C.preflight(p, base)

    def test_default_runner_does_not_start_process(self):
        run = subprocess.run([sys.executable, '-B', str(HOME.parent / 'tools/g8_execute.py'),
                              '--inputs', str(HOME.parent / 'prepared_inputs')], capture_output=True)
        self.assertEqual(run.returncode, 0, run.stderr)
        self.assertFalse(json.loads(run.stdout)['pds_executed'])

    def test_cli_rejects_baseline_override(self):
        run = subprocess.run([sys.executable, '-B', str(HOME.parent / 'tools/g8_gate.py'),
                              '--baseline', 'fake.json'], capture_output=True)
        self.assertEqual(run.returncode, 2)

    def test_real_child_success_and_nonzero(self):
        for code in (0, 7):
            result = X.run_process([sys.executable, '-c', 'print("SYNTHETIC_CHILD"); raise SystemExit(%d)' % code],
                                   self.case, 10)
            self.assertEqual(result['exit_code'], code)
            self.assertEqual(result['outcome'], 'FINISHED' if code == 0 else 'FAILED')
            self.assertIn('SYNTHETIC_CHILD', C.read(self.case / 'console_full.log'))

    def test_real_child_timeout_reaped(self):
        result = X.run_process([sys.executable, '-c', 'import time; time.sleep(30)'], self.case, .1)
        self.assertEqual(result['outcome'], 'TIMED_OUT')
        self.assertTrue(result['tree_termination']['parent_reaped'])
        self.assertIsNotNone(result['exit_code'])

    def test_child_start_failure(self):
        result = X.run_process([str(self.case / 'missing.exe')], self.case, 1)
        self.assertEqual(result['outcome'], 'START_FAILED')
        self.assertIsNone(result['pid'])

    def test_child_interrupt_terminates_owned_tree(self):
        child = unittest.mock.Mock()
        child.pid = 123
        child.wait.side_effect = KeyboardInterrupt
        with patch.object(X.subprocess, 'Popen', return_value=child), \
             patch.object(X, 'terminate_tree', return_value={'attempted': True, 'parent_reaped': True}):
            result = X.run_process(['synthetic'], self.case, 10)
        self.assertEqual(result['outcome'], 'INTERRUPTED')
        self.assertTrue(result['tree_termination']['attempted'])

    def test_runner_keeps_all_seeds_after_failure_and_interruption(self):
        inputs = self.case / 'prepared'
        base = make_prepared(inputs)
        shell = self.case / 'PDS_2022.2-SP6.4/bin/pds_shell.exe'
        shell.parent.mkdir(parents=True)
        shell.write_bytes(b'SYNTHETIC_NOT_EXECUTABLE')
        launches = []
        def fake(argv, target, timeout):
            seed = int(target.name.split('_')[1])
            launches.append(seed)
            outputs(target, seed)
            stamp = X.now()
            dump(target / 'process_started.json', {'schema': 'g8-child-start-v1', 'pid': 123,
                 'argv': argv, 'cwd': str(target.resolve()), 'started': stamp})
            outcome = 'FAILED' if seed == 2 else 'INTERRUPTED' if seed == 5 else 'FINISHED'
            return {'started': stamp, 'finished': stamp, 'seconds': 0.0, 'pid': 123,
                    'exit_code': 7 if outcome == 'FAILED' else -1 if outcome == 'INTERRUPTED' else 0,
                    'outcome': outcome, 'error': None if outcome == 'FINISHED' else 'Synthetic failure',
                    'timed_out': False, 'interrupted': outcome == 'INTERRUPTED',
                    'tree_termination': {'attempted': True} if outcome == 'INTERRUPTED' else None}
        out = self.case / 'executed'
        result = X.run_batch(inputs, out, shell, 100, base, fake)
        self.assertEqual(launches, [2, 3, 5])
        self.assertEqual(result['status'], 'INTERRUPTED')
        inspected = E.inspect(out, base)
        self.assertEqual(inspected['records_valid'], 8, inspected)
        self.assertEqual([r['outcome'] for r in inspected['seeds']],
                         ['FAILED', 'FINISHED', 'INTERRUPTED'] + ['NOT_STARTED'] * 5)
        value = G.assess(out, _test_baseline=base)
        self.assertEqual(value['valid'], 1)
        self.assertEqual(value['exit_code'], 2)


if __name__ == '__main__':
    unittest.main(verbosity=2)
