"""SYNTHETIC gate fixtures: no PDS evidence, no real bitstream."""
from pathlib import Path
import json
import shutil
import sys
HOME = Path(__file__).resolve().parent
sys.path.insert(0, str(HOME.parent / "tools"))
from g8_common import CANDIDATE, SEEDS, VERSION, dump, inventory, load, sha
SHELL = "D:/pango/PDS_2022.2-SP6.4/bin/pds_shell.exe"

def console(seed, startup=False):
    from g8_console import MESSAGES
    arch = 'set_arch -family Logos2 -device PG2L100H -speedgrade -6 -package FBG676'
    lines = ['License checkout: fabric_shell from D:/pango/PDS_2022.2-SP6.4/license/synthetic.lic',
             'Compiling architecture definition.']
    if startup:
        lines += MESSAGES
    lines += ["Analyzing project file 'D:/SYNTHETIC_NOT_PDS/seed_%d/run_trial.pds'." % seed,
              'Executing : '+arch, 'Executing : '+arch+' successfully.',
              'Executing : compile -top_module hdmi_ddr_ov5640_top successfully.',
              'Executing : synthesize -ads -selected_syn_tool_opt 2 successfully.',
              'Executing : dev_map successfully.', 'G8_PHASE=DEV_MAP_DONE',
              'Executing : pnr -gplace_seed %d -groute_seed %d successfully.' % (seed, seed),
              'G8_PHASE=PNR_DONE', 'Executing : report_timing successfully.',
              'Executing : gen_bit_stream successfully.', 'G8_PHASE=FINISHED']
    return '\n'.join(lines)+'\n'


def native(wns=.071, fast=1.583, hold=.143, fast_hold=.102, seed=2):
    import csv
    import io
    lines = (HOME/'fixtures/native.csv').read_text(encoding='utf-8').splitlines()
    i = next(i for i, s in enumerate(lines) if s.startswith('Seed,State,'))
    header, row = list(csv.reader(lines[i:i+2]))
    values = dict(zip(header, row))
    values.update({'Convergence': 'OK' if wns >= 0 else 'Fail', 'Setup(Slow)': str(wns),
                   'Setup(Fast)': str(fast), 'Hold(Slow)': str(hold), 'Hold(Fast)': str(fast_hold),
                   'Setup(Slow) Total Failing TNS': str(wns if wns < 0 else 0),
                   'Setup(Slow) Total Failing Endpoints': '1' if wns < 0 else '0',
                   'Hold(Slow) Total Failing THS': str(hold if hold < 0 else 0),
                   'Hold(Slow) Total Failing Endpoints': '1' if hold < 0 else '0'})
    out = io.StringIO()
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow(header); writer.writerow([values[k] for k in header])
    trailer = (f'Project Configurations:\nplace & route," -gplace_seed {seed}\n -groute_seed {seed} "\n')
    return '\n'.join(lines[:i])+'\n'+out.getvalue()+'Pass Rate/Convergence Rate,100.00%,100.00%\n\n'+trailer


def final(wns=.089, fast=1.6, hold=.14, fast_hold=.10):
    text = 'Design Summary : '+('All Constraints Met.' if min(wns, fast, hold, fast_hold) >= 0 else 'Constraints Violated.')+'\n\n'
    for kind, corner, value in [('Setup','Slow',wns), ('Setup','Fast',fast), ('Hold','Slow',hold), ('Hold','Fast',fast_hold)]:
        text += '%s Summary(%s Corner):\n' % (kind, corner)
        text += 'ddrphy_sysclk ddrphy_sysclk %.6f %.6f %d 100\n\n' % (value, value if value < 0 else 0, int(value < 0))
    return text


def rtr():
    return '<tables><table id="report_timing_clock_summary"><row><data>ddrphy_sysclk</data><data>Generated</data><data>8.0000</data><data>125.0000MHz</data></row></table></tables>'


def make_prepared(root):
    root.mkdir()
    base = {'schema': 'g8-pinned-inputs-v1', 'candidate': CANDIDATE, 'seeds': SEEDS,
            'latency': 14, 'II': 1, 'seed_inputs': {}, 'seed_manifest_sha256': {}}
    for seed in SEEDS:
        target = root / f'seed_{seed}'
        target.mkdir()
        data = {'source/core.v': '// SYNTHETIC_NOT_RTL\n', 'ipcore/ip.idf': 'SYNTHETIC_IP\n',
                'build.tcl': '# SYNTHETIC_ONLY\n', 'HDMI_DDR3_OV5640_test.fdc': '# SYNTHETIC_ONLY\n',
                'run_trial.tcl': '# SYNTHETIC_ONLY G8_PHASE=FINISHED\npnr -gplace_seed %d -groute_seed %d\n' % (seed, seed)}
        for name, text in data.items():
            path = target / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding='utf-8')
        expected = {name: sha(target / name) for name in data}
        base['seed_inputs'][str(seed)] = expected
        base['host_inputs'] = {name: digest for name, digest in expected.items() if name != 'run_trial.tcl'}
        dump(target / 'trial_inputs_sha256.json', expected)
        base['seed_manifest_sha256'][str(seed)] = sha(target / 'trial_inputs_sha256.json')
    dump(root / 'run_plan.json', {'candidate': CANDIDATE, 'seeds': SEEDS, 'latency': 14, 'II': 1,
                                 'host_inputs': base['host_inputs'], 'origin': 'SYNTHETIC_NOT_PDS'})
    base['run_plan_sha256'] = sha(root / 'run_plan.json')
    return base


def outputs(target, seed):
    data = {'console_full.log': console(seed), 'multiseed_summary.csv': native(seed=seed),
            'report_timing/rtr.db': rtr(), 'report_timing/top.rtr': 'SYNTHETIC_PATH_REPORT\n',
            'place_route/top_timing_summary_after_hold_fix.txt': final(),
            'place_route/top.prr': (HOME / 'fixtures/resources.prr').read_text(encoding='utf-8-sig'),
            'synthesize/top_syn.vm': '// SYNTHETIC_NOT_NETLIST\nmodule hdmi_ddr_ov5640_top;\n'
                                     'wire kr2_low_g8, kr2_high_g8, kr2_4, sx_product_g7, sy_product_g7; endmodule\n',
            'device_map/top.pcf': 'SYNTHETIC_PCF\n', 'device_map/top.dmr': 'SYNTHETIC_DMR\n',
            'device_map/top_map.adf': 'SYNTHETIC_MAP_ADF\n', 'synthesize/top_syn.adf': 'SYNTHETIC_SYN_ADF\n',
            'compile/top_comp.adf': 'SYNTHETIC_COMPILE_ADF\n',
            'place_route/top_pnr.adf': 'SYNTHETIC_PNR_ADF\n',
            'generate_bitstream/top.sbit': 'SYNTHETIC_NOT_A_BITSTREAM\n'}
    for phase in ('compile', 'synthesize', 'device_map', 'place_route', 'report_timing', 'generate_bitstream'):
        data[phase + '/run.log'] = 'SYNTHETIC_PHASE_LOG\n'
    for name, text in data.items():
        path = target / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding='utf-8')


def refresh(root, seed):
    target = root / f'seed_{seed}'
    record = load(target / 'process_receipt.json')
    frozen = set(load(target / 'trial_inputs_sha256.json'))
    record['artifacts_sha256'] = {name: sha(path) for name, path in inventory(target).items()
                                if name not in frozen | {'trial_inputs_sha256.json', 'process_receipt.json'}}
    dump(target / 'process_receipt.json', record)
    batch = load(root / 'batch_receipt.json')
    batch['receipts_sha256'][f'seed_{seed}/process_receipt.json'] = sha(target / 'process_receipt.json')
    dump(root / 'batch_receipt.json', batch)


def make_run(root, base):
    batch = {'schema': 'g8-batch-exec-v1', 'candidate': CANDIDATE,
             'baseline_sha256': 'SYNTHETIC_TEST_INJECTION', 'seeds': SEEDS,
             'pds_shell': SHELL, 'pds_shell_sha256_before': 'A' * 64,
             'pds_shell_sha256_after': 'A' * 64, 'pds_version_expected': VERSION,
             'timeout_seconds_per_seed': 3600, 'started': '2026-10-23T12:00:00+08:00',
             'finished': '2026-10-23T12:01:00+08:00', 'seconds': 60.0, 'status': 'COMPLETED',
             'evidence_origin': 'SYNTHETIC_NOT_PDS', 'receipts_sha256': {}}
    for seed in SEEDS:
        target = root / f'seed_{seed}'
        outputs(target, seed)
        expected = base['seed_inputs'][str(seed)]
        record = {'schema': 'g8-process-v1', 'candidate': CANDIDATE,
                  'baseline_sha256': 'SYNTHETIC_TEST_INJECTION', 'seed': seed,
                  'placement_seed': seed, 'route_seed': seed, 'pds_shell': SHELL,
                  'pds_shell_sha256_before': 'A' * 64, 'pds_shell_sha256_after': 'A' * 64,
                  'argv': [SHELL, '-file', 'run_trial.tcl'], 'cwd': 'D:/SYNTHETIC_NOT_PDS/seed_' + str(seed),
                  'timeout_seconds': 3600, 'started': '2026-10-23T12:00:01+08:00',
                  'finished': '2026-10-23T12:00:02+08:00', 'seconds': 1.0,
                  'pid': 123, 'exit_code': 0, 'outcome': 'FINISHED', 'error': None,
                  'timed_out': False, 'interrupted': False, 'tree_termination': None,
                  'inputs_before': expected, 'inputs_after': expected, 'inputs_unchanged': True,
                  'evidence_origin': 'SYNTHETIC_NOT_PDS'}
        dump(target / 'process_receipt.json', record)
        dump(target / 'process_started.json', {'schema': 'g8-child-start-v1', 'pid': record['pid'],
             'argv': record['argv'], 'cwd': record['cwd'], 'started': record['started']})
    dump(root / 'batch_receipt.json', batch)
    for seed in SEEDS:
        refresh(root, seed)


