"""Verify frozen delivered files; allow additional user-generated output files."""
from pathlib import Path
import hashlib
import json
import sys

root = Path(__file__).resolve().parent
rows = json.loads((root / "MANIFEST_SHA256.json").read_text(encoding="utf-8"))
bad = []
for row in rows:
    path = (root / row["path"]).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        bad.append("MISSING/UNSAFE " + row["path"])
        continue
    data = path.read_bytes()
    if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
        bad.append("CHANGED " + row["path"])
print("M01_DELIVERY", "PASS" if not bad else "FAIL", "files=", len(rows))
for line in bad:
    print(line)
sys.exit(bool(bad))
