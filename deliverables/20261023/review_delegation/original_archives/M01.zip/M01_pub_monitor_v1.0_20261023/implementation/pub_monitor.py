"""M01: read-only publication-counter monitor and deterministic offline replay."""
import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import platform
import shutil
import sys
import time
import uuid

from uart_adapter import Capture, PortLock, UART_SHA256, hex_bytes, uart

RATE_FIELDS = ("session_id segment start_seq end_seq delta_pub duration_est_s "
               "duration_min_s duration_max_s rate_est_fps rate_min_fps "
               "rate_max_fps quality reason").split()
CONDITION = ("Correct response association; no reset or hidden wraps; rates are "
             "conditional observations, not exact FPGA publication times.")


def positive(value):
    value = float(value)
    if not math.isfinite(value) or value <= 0:
        raise ValueError("value must be finite and positive")
    return value


def policy(max_rate=None, reset_evidence=None, bound_evidence=None,
           max_gap_s=5.0, max_window_s=1.5):
    if max_rate is not None:
        max_rate = positive(max_rate)
        if not bound_evidence or not bound_evidence.strip():
            raise ValueError("max rate requires reviewable bound evidence")
    if positive(max_gap_s) > 5 and max_rate is None:
        raise ValueError("raising the 5-second gap policy requires a rate-bound assumption/evidence")
    return dict(max_publication_rate_assumption=max_rate,
                reset_exclusion_evidence=reset_evidence,
                max_rate_evidence=bound_evidence,
                max_gap_s=positive(max_gap_s), max_window_s=positive(max_window_s))


def validate(record, p):
    """Validate recorded frames with original parser, not a replacement stack."""
    try:
        required = ("schema_version session_id seq evidence_kind t_tx_ns t_rx_ns "
                    "request_hex response_hex status_u32 outcome error "
                    "continuity_assumed reset_event").split()
        if not isinstance(record, dict) or any(k not in record for k in required):
            return "SCHEMA_ERROR"
        if (type(record["schema_version"]) is not int or record["schema_version"] != 1
                or type(record["seq"]) is not int or record["seq"] < 0
                or not isinstance(record["session_id"], str) or not record["session_id"]
                or record["evidence_kind"] not in ("SYNTHETIC", "BOARD")
                or type(record["continuity_assumed"]) is not bool
                or type(record["reset_event"]) is not bool):
            return "SCHEMA_ERROR"
        if record["outcome"] != "OK":
            return "SAMPLE_FAILURE:" + str(record["outcome"])
        a, b = record["t_tx_ns"], record["t_rx_ns"]
        if type(a) is not int or type(b) is not int or a < 0 or b <= a:
            return "INVALID_TIME"
        if (b - a) / 1e9 > p["max_window_s"]:
            return "EXCESSIVE_RESPONSE_WINDOW"
        if bytes.fromhex(record["request_hex"]) != uart.frame(0x05):
            return "INVALID_REQUEST"
        cmd, _, payload = uart.parse_frame(bytes.fromhex(record["response_hex"]),
                                           status_reply=True)
        if cmd != 0x05:
            return "INVALID_RESPONSE_COMMAND"
        status = int.from_bytes(payload, "little")
        if type(record["status_u32"]) is not int or record["status_u32"] != status:
            return "STATUS_BYTES_MISMATCH"
        if status & 0xff != 0x12:
            return "INCOMPATIBLE_FW"
    except (TypeError, ValueError, uart.ToolError):
        return "INVALID_FRAME"
    return None


def analyze(records, p):
    rows, annotations = [], []
    previous = None
    segment = 0
    seen_seq = {}
    for index, record in enumerate(records):
        r = record if isinstance(record, dict) else {}
        row = dict.fromkeys(RATE_FIELDS)
        row.update(session_id=r.get("session_id"), segment=segment,
                   end_seq=r.get("seq"), quality="INVALID")
        error = validate(record, p)
        key, seq = r.get("session_id"), r.get("seq")
        if not error:
            if key in seen_seq and seq <= seen_seq[key]:
                error = "NONMONOTONIC_SEQUENCE"
            seen_seq[key] = max(seq, seen_seq.get(key, seq))
        if error:
            row["reason"] = error
            previous = None
            segment += 1
        else:
            row.update(quality="FIRST", reason="First sample; no rate")
            if r["reset_event"]:
                row.update(quality="BREAK", reason="EXPLICIT_RESET")
                previous = None
                segment += 1
            if previous is not None:
                old = previous
                row["start_seq"] = old["seq"]
                a0, b0, a1, b1 = (old["t_tx_ns"], old["t_rx_ns"],
                                  r["t_tx_ns"], r["t_rx_ns"])
                dt = (a1 + b1 - a0 - b0) / 2e9
                dmin, dmax = (a1 - b0) / 1e9, (b1 - a0) / 1e9
                row.update(duration_est_s=dt, duration_min_s=dmin, duration_max_s=dmax)
                reason = None
                if key != old["session_id"]:
                    reason = "SESSION_CHANGED"
                elif r["evidence_kind"] != old["evidence_kind"]:
                    reason = "EVIDENCE_KIND_CHANGED"
                elif seq != old["seq"] + 1:
                    reason = "MISSING_SEQUENCE"
                elif a1 <= a0 or b1 <= b0:
                    reason = "TIME_REVERSED_OR_IDENTICAL"
                elif dmin <= 0:
                    reason = "OVERLAPPING_WINDOWS"
                elif not (r["continuity_assumed"] and old["continuity_assumed"]):
                    reason = "CONTINUITY_NOT_ASSUMED"
                count0, count1 = old["status_u32"] >> 16, r["status_u32"] >> 16
                delta = (count1 - count0) % 65536
                upper = p["max_publication_rate_assumption"]
                bound_excludes_wraps = upper is not None and upper * dmax < 65536
                if not reason and count1 < count0:
                    if not (bound_excludes_wraps and p["reset_exclusion_evidence"]):
                        reason = "AMBIGUOUS_COUNTER"
                if not reason and (dmax > p["max_gap_s"] or upper is not None):
                    if not bound_excludes_wraps:
                        reason = "MULTIWRAP_NOT_EXCLUDED"
                if not reason and upper is not None and delta > upper * dmax:
                    reason = "RATE_BOUND_CONTRADICTION"
                if reason:
                    segment += 1
                    row.update(quality="BREAK", reason=reason)
                else:
                    row.update(delta_pub=delta, rate_est_fps=delta / dt,
                               rate_min_fps=delta / dmax, rate_max_fps=delta / dmin,
                               quality="ASSUMED_MODULO" if count1 < count0 else "ASSUMED",
                               reason=CONDITION)
            # A rejected pair can establish a new baseline, unless its time went backwards.
            previous = None if row["reason"] == "TIME_REVERSED_OR_IDENTICAL" else r
        row["segment"] = segment
        rows.append(row)
        annotations.append(dict(index=index, seq=r.get("seq"),
                                evidence_kind=r.get("evidence_kind"),
                                pub_count16=(r["status_u32"] >> 16)
                                if type(r.get("status_u32")) is int else None,
                                quality=row["quality"], reason=row["reason"]))
    valid = [row for row in rows if row["rate_est_fps"] is not None]
    duration = sum(row["duration_est_s"] for row in valid)
    evidence = sorted({r.get("evidence_kind") for r in records
                       if isinstance(r, dict) and r.get("evidence_kind") in ("BOARD", "SYNTHETIC")})
    summary = dict(schema_version=1, records=len(records), computed_intervals=len(valid),
                   raw_outcomes=dict(Counter(str(r.get("outcome")) if isinstance(r, dict)
                                             else "SCHEMA_ERROR" for r in records)),
                   invalid_samples=sum(row["quality"] == "INVALID" for row in rows),
                   broken_intervals=sum(row["quality"] == "BREAK" for row in rows),
                   valid_duration_est_s=duration,
                   total_delta_pub=sum(row["delta_pub"] for row in valid),
                   aggregate_rate_est_fps=sum(row["delta_pub"] for row in valid) / duration
                   if duration else None,
                   evidence_kinds=evidence, not_hardware_evidence="BOARD" not in evidence,
                   policy=p, rate_condition=CONDITION, wp3_verdict="NOT_EVALUATED")
    summary["failed_record_count"] = sum(not isinstance(r, dict) or r.get("outcome") != "OK"
                                         for r in records)
    summary["failed_record_fraction"] = (summary["failed_record_count"] / len(records)
                                          if records else None)
    def is_query(r):
        try:
            return isinstance(r, dict) and bytes.fromhex(r.get("request_hex", "")) == uart.frame(0x05)
        except (TypeError, ValueError):
            return False
    queries = [r for r in records if is_query(r)]
    summary["attempted_queries"] = len(queries)
    summary["failed_queries"] = sum(r.get("outcome") != "OK" for r in queries)
    summary["failed_query_fraction"] = (summary["failed_queries"] / len(queries) if queries else None)
    summary["quality_counts"] = dict(Counter(row["quality"] for row in rows))
    summary["rejection_reasons"] = dict(Counter(row["reason"] for row in rows
                                                if row["quality"] in ("INVALID", "BREAK")))
    return rows, annotations, summary


def dump_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
                    encoding="utf-8")


def dump_jsonl(path, rows):
    with path.open("w", encoding="utf-8", newline="\n") as output:
        for row in rows:
            output.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")


def new_output(path, sources=()):
    path = Path(path).resolve()
    for source in sources:
        if source is not None and Path(source).resolve().is_relative_to(path):
            raise ValueError("output cannot contain an input or replace its parent")
    path.mkdir(parents=True, exist_ok=False)  # Existing directory always rejected.
    return path


def reports(out, records, p, session):
    rows, annotations, summary = analyze(records, p)
    with (out / "rates.csv").open("w", encoding="utf-8", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=RATE_FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    dump_jsonl(out / "validated_samples.jsonl", annotations)
    dump_json(out / "summary.json", summary)
    dump_json(out / "session.json", session)
    lines = ["# M01 publication observations", "",
             "Evidence: " + ", ".join(summary["evidence_kinds"]),
             "Session state: " + session["state"],
             "", f"Records: {summary['records']}; computed intervals: {len([r for r in rows if r['rate_est_fps'] is not None])}",
             f"Invalid samples: {summary['invalid_samples']}; broken intervals: {summary['broken_intervals']}",
             f"Valid midpoint duration (s): {summary['valid_duration_est_s']}",
             f"Conditional aggregate rate (fps): {summary['aggregate_rate_est_fps']}",
             "", CONDITION, "",
             "These are new corrected-frame publication counts, not HDMI/camera fps.",
             "busy/params_valid and reserved bits do not establish a publication or reset.",
             "Short increasing intervals still ASSUME no hidden wraps. No-rate intervals are retained.",
             "Policy limits and rate bounds are reviewable assumptions, not measured hardware guarantees.",
             "WP-3 25/30fps acceptance: NOT_EVALUATED. See rates.csv for all intervals.", ""]
    (out / "report.md").write_text("\n".join(lines), encoding="utf-8")
    return summary


def read_records(path):
    records = []
    for number, line in enumerate(Path(path).read_text(encoding="utf-8-sig").splitlines(), 1):
        if not line.strip():
            continue
        try:
            records.append(json.loads(line, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x))))
        except ValueError:
            records.append(dict(source_line=number, outcome="INVALID_JSON"))
    return records


def versions():
    try:
        serial_version = importlib.metadata.version("pyserial")
    except importlib.metadata.PackageNotFoundError:
        serial_version = None
    return dict(python=platform.python_version(), platform=platform.platform(),
                pyserial=serial_version, uart_sha256=UART_SHA256)


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def replay(source, out_path, p, metadata=None):
    source = Path(source)
    records = read_records(source)
    original_session = json.loads(Path(metadata).read_text(encoding="utf-8")) if metadata else None
    out = new_output(out_path, (source, metadata))
    shutil.copyfile(source, out / "records.jsonl")  # Exact input bytes, even invalid lines.
    if metadata:
        shutil.copyfile(metadata, out / "source_session.json")
    session = dict(schema_version=1, mode="replay", state="REPLAYED", start_utc=None,
                   end_utc=None, timezone="UTC", dependencies=versions(),
                   source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                   source_metadata=original_session, board_id=None, bitstream_sha256=None,
                   parameter_sha256=None, policy=p,
                   max_publication_rate_assumption=p["max_publication_rate_assumption"],
                   files=dict(records="records.jsonl", rates="rates.csv", summary="summary.json",
                              original_session="source_session.json" if metadata else None))
    return reports(out, records, p, session)


def monitor(port, out_path, interval, duration, timeout, p, fresh_evidence,
            continuity=False, conditions="", opener=uart.open_serial,
            clock=time.monotonic_ns, sleeper=time.sleep, lock_factory=PortLock,
            board_id=None, bitstream_sha256=None, parameter_sha256=None, evidence_kind="BOARD"):
    interval, duration, timeout = map(positive, (interval, duration, timeout))
    if timeout < 1:
        raise ValueError("timeout must be >= 1 second (frozen parser minimum)")
    if not fresh_evidence or not fresh_evidence.strip():
        raise ValueError("fresh-session evidence required; reopening alone cannot remove late replies")
    if evidence_kind not in ("BOARD", "SYNTHETIC"):
        raise ValueError("invalid evidence kind")
    for digest in (bitstream_sha256, parameter_sha256):
        if digest is not None and (len(digest) != 64 or any(c not in "0123456789abcdefABCDEF" for c in digest)):
            raise ValueError("hash must be SHA256 hexadecimal or unknown")
    out = new_output(out_path)
    session_id = str(uuid.uuid4())
    session = dict(schema_version=1, session_id=session_id, mode="monitor", state="IN_PROGRESS",
                   evidence_kind=evidence_kind,
                   start_utc=utc_now(), end_utc=None, timezone=str(datetime.now().astimezone().tzinfo),
                   dependencies=versions(), board_id=board_id, bitstream_sha256=bitstream_sha256,
                   parameter_sha256=parameter_sha256, conditions=conditions, policy=p,
                   max_publication_rate_assumption=p["max_publication_rate_assumption"],
                   serial=dict(port=port, baud=115200, bytesize=8, parity="N", stopbits=1,
                               flow_control=False, timeout_s=timeout, interval_s=interval,
                               duration_s=duration, exclusive_owner_required=True),
                   continuity_assumed=continuity, fresh_session_evidence=fresh_evidence,
                   response_association="conditional on clean start / one owner / one reply per request",
                   files=dict(records="records.jsonl", raw="raw_io.jsonl", rates="rates.csv",
                              summary="summary.json"))
    dump_json(out / "session.json", session)
    records, connection, capture = [], None, None
    request = uart.frame(0x05)
    current = None

    def failure(outcome, error):
        return dict(schema_version=1, session_id=session_id, seq=len(records),
                    evidence_kind=evidence_kind, t_tx_ns=None, t_rx_ns=clock(),
                    request_hex="", response_hex="", status_u32=None,
                    outcome=outcome, error=str(error), continuity_assumed=continuity,
                    reset_event=False)

    with (out / "records.jsonl").open("w", encoding="utf-8", newline="\n") as record_file, \
            (out / "raw_io.jsonl").open("w", encoding="utf-8", newline="\n") as raw_file:
        def save(record):
            record_file.write(json.dumps(record, ensure_ascii=False) + "\n")
            record_file.flush()
            records.append(record)
        try:
            with lock_factory(port):
                connection = opener(port)
                connection.timeout = 0.05
                connection.write_timeout = timeout
                capture = Capture(connection, raw_file, clock)
                if capture.drain_available("startup unsolicited bytes; cannot associate"):
                    raise RuntimeError("UNASSOCIATED_STARTUP_BYTES")
                start = clock()
                end = start + int(duration * 1e9)
                next_poll = start
                while clock() < end:
                    now = clock()
                    if now < next_poll:
                        sleeper(min((next_poll - now) / 1e9, (end - now) / 1e9, 0.05))
                        continue
                    capture.seq = len(records)
                    if capture.drain_available("unsolicited bytes before next request"):
                        raise RuntimeError("UNASSOCIATED_BYTES")
                    capture.received.clear()
                    current = failure("IN_PROGRESS", "")
                    current.update(t_tx_ns=clock(), request_hex=hex_bytes(request))
                    capture.deadline_ns = current["t_tx_ns"] + int(timeout * 1e9)
                    try:
                        if capture.write(request) != len(request):
                            raise OSError("SHORT_WRITE")
                        # No flush(): potentially unbounded driver drain; full write count is checked.
                        status = uart.read_status_frame(capture, timeout=timeout,
                                                        clock=lambda: clock() / 1e9)
                        current.update(t_rx_ns=clock(), response_hex=hex_bytes(capture.received[-9:]),
                                       status_u32=status, outcome="OK", error=None)
                        error = validate(current, p)
                        if error:
                            raise RuntimeError(error)
                    except KeyboardInterrupt:
                        raise
                    except Exception as exc:
                        text = str(exc)
                        kind = ("TIMEOUT" if isinstance(exc, TimeoutError) or "超时" in text or "deadline" in text
                                else "SHORT_WRITE" if "SHORT_WRITE" in text else "IO_OR_PROTOCOL_ERROR")
                        current.update(t_rx_ns=clock(), response_hex=hex_bytes(capture.received),
                                       status_u32=None, outcome=kind, error=text)
                        save(current)
                        current = None
                        session["state"] = "TAINTED_ABORTED"
                        session["error"] = text
                        # No new requests; capture only bytes already available at failure.
                        capture.drain_available("post-failure quarantine; never attributed to a request")
                        break
                    save(current)
                    current = None
                    next_poll = clock() + int(interval * 1e9)  # No catch-up bursts.
                else:
                    session["state"] = "COMPLETE"
        except KeyboardInterrupt:
            if current is not None:
                current.update(outcome="INTERRUPTED", error="Ctrl+C", status_u32=None,
                               t_rx_ns=clock(), response_hex=hex_bytes(capture.received))
                save(current)
            else:
                save(failure("INTERRUPTED", "Ctrl+C between polls"))
            session["state"] = "INCOMPLETE"
        except Exception as exc:
            save(failure("SESSION_ERROR", exc))
            session.update(state="TAINTED_ABORTED", error=str(exc))
        finally:
            if connection is not None:
                try:
                    connection.close()
                except Exception as exc:
                    save(failure("CLOSE_ERROR", exc))
                    session.update(state="INCOMPLETE", close_error=str(exc))
            session["end_utc"] = utc_now()
            reports(out, records, p, session)
    return session


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("replay", "monitor"):
        p = sub.add_parser(name)
        p.add_argument("--out", required=True, help="NEW directory; existing directories rejected")
        p.add_argument("--max-rate", type=float, help="reviewable upper-bound assumption; not 30fps target")
        p.add_argument("--max-rate-evidence")
        p.add_argument("--reset-exclusion-evidence")
        p.add_argument("--max-gap", type=float, default=5.0)
        p.add_argument("--timeout", type=float, default=1.5)
        if name == "replay":
            p.add_argument("--input", required=True)
            p.add_argument("--session", help="original session metadata (preserved, not silently trusted as policy)")
        else:
            p.add_argument("--port", required=True)
            p.add_argument("--interval", type=float, default=1.0)
            p.add_argument("--duration", type=float, default=60.0)
            p.add_argument("--fresh-session-evidence", required=True)
            p.add_argument("--assume-continuity", action="store_true")
            p.add_argument("--conditions", default="")
            p.add_argument("--board-id")
            p.add_argument("--bitstream-sha256")
            p.add_argument("--parameter-sha256")
    args = parser.parse_args(argv)
    try:
        if positive(args.timeout) < 1:
            raise ValueError("timeout must be >= 1 second")
        p = policy(args.max_rate, args.reset_exclusion_evidence, args.max_rate_evidence,
                   args.max_gap, args.timeout)
        if args.command == "replay":
            result = replay(args.input, args.out, p, args.session)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        session = monitor(args.port, args.out, args.interval, args.duration, args.timeout, p,
                          args.fresh_session_evidence, args.assume_continuity, args.conditions,
                          board_id=args.board_id, bitstream_sha256=args.bitstream_sha256,
                          parameter_sha256=args.parameter_sha256)
        print("Session:", session["state"])
        return 0 if session["state"] == "COMPLETE" else 2
    except (ValueError, OSError, uart.ToolError) as exc:
        print("M01 error:", exc, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
