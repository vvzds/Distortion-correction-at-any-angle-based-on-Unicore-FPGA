"""Capture actual I/O while delegating decoding to the unchanged frozen UART tool."""
import hashlib
import importlib.util
import json
import os
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UART_PATH = ROOT / "reference_original/M01/current/uart/uart_tool.py"
UART_SHA256 = "043f8076f3ee9b810081fa337b6ed0cdffa85131ee4a3c04f409534960331a57"
uart_source = UART_PATH.read_bytes()
if hashlib.sha256(uart_source).hexdigest() != UART_SHA256:
    raise RuntimeError("Frozen UART dependency hash mismatch")
spec = importlib.util.spec_from_file_location("m01_frozen_uart", UART_PATH)
uart = importlib.util.module_from_spec(spec)
# Execute the exact checked bytes without creating __pycache__ in the archive.
exec(compile(uart_source, str(UART_PATH), "exec"), uart.__dict__)


def hex_bytes(data):
    return bytes(data).hex(" ").upper()


class PortLock:
    """Process lifetime lock; Windows also enforces exclusive serial open."""
    def __init__(self, port):
        name = hashlib.sha256(port.strip().upper().encode()).hexdigest()[:24]
        self.path = Path(tempfile.gettempdir()) / ("m01-port-" + name + ".lock")
        self.file = None

    def __enter__(self):
        self.file = self.path.open("a+b")
        try:
            self.file.seek(0, os.SEEK_END)
            if not self.file.tell():
                self.file.write(b"0")
                self.file.flush()
            self.file.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BaseException:
            self.file.close()
            self.file = None
            raise
        return self

    def __exit__(self, *_):
        if self.file is not None:
            self.file.close()  # OS releases lock even after interruption.


class Capture:
    def __init__(self, connection, raw_file, clock):
        self.connection, self.raw_file, self.clock = connection, raw_file, clock
        self.seq = None
        self.received = bytearray()
        self.deadline_ns = None

    def event(self, direction, data=b"", **extra):
        row = dict(seq=self.seq, t_ns=self.clock(), direction=direction,
                   data_hex=hex_bytes(data), **extra)
        self.raw_file.write(json.dumps(row, ensure_ascii=False) + "\n")
        self.raw_file.flush()

    def write(self, data):
        try:
            sent = self.connection.write(data)
        except BaseException as exc:
            self.event("TX_ERROR", attempted_hex=hex_bytes(data),
                       actual_sent_unknown=True, error=str(exc))
            raise
        # Driver acceptance is observable, physical wire delivery is not.
        if type(sent) is not int or not 0 <= sent <= len(data):
            self.event("TX_ERROR", attempted_hex=hex_bytes(data),
                       actual_sent_unknown=True, error="invalid driver return")
            raise OSError("invalid serial write count")
        self.event("TX", data[:sent], attempted_hex=hex_bytes(data), accepted=sent)
        return sent

    def read(self, count):
        if self.deadline_ns is not None:
            remaining = (self.deadline_ns - self.clock()) / 1e9
            if remaining <= 0:
                raise TimeoutError("transaction deadline exceeded")
            self.connection.timeout = min(0.05, remaining)
        try:
            data = self.connection.read(count)
        except BaseException as exc:
            self.event("RX_ERROR", error=type(exc).__name__ + ": " + str(exc))
            raise
        if data:
            self.received.extend(data)
            self.event("RX", data)
        return data

    def drain_available(self, reason):
        """Bounded one-shot capture. Never used as proof of synchronization."""
        result = bytearray()
        # Bounded even for a noisy device that continuously produces data.
        for _ in range(256):
            available = int(self.connection.in_waiting)
            count = min(available, 65536 - len(result))
            if count <= 0:
                if available > 0:
                    self.event("DRAIN_LIMIT", reason=reason, unread_bytes_reported=available)
                return bytes(result)
            self.connection.timeout = 0
            data = self.connection.read(count)
            self.event("RX_UNASSOCIATED", data, reason=reason)
            result.extend(data)
            if not data:
                return bytes(result)
        self.event("DRAIN_LIMIT", reason=reason,
                   unread_bytes_reported=int(self.connection.in_waiting))
        return bytes(result)
