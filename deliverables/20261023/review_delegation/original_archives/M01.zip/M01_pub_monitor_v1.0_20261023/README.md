# M01 新帧发布率观测与回放 v1.0 软件候选交付

用于只读查询 FPGA 的 `pub_count16`，记录时间界、原始收发字节，离线重放并输出 JSON/CSV/Markdown。它测量的是**新校正帧发布计数**；HDMI 刷新率、摄像头采集率需要另行测量。

本次软件验收覆盖 P01–P09；P10 实板测试为 **NOT_TESTED**。未改 FPGA、生产 G4、A+B 候选或冻结 UART 协议。后续可用已验证的 G4 集成位流采样，不依赖 A+B 时序收敛。

## 内容

| 路径 | 用途 |
|---|---|
| `implementation/pub_monitor.py` | monitor / replay 命令及速率分析 |
| `implementation/uart_adapter.py` | 原 UART 依赖校验、字节抓取、串口占用锁 |
| `tests/test_m01.py`、`tests/fake_serial.py` | P01–P09 自动化验收和合成串口 |
| `tests/build_evidence.py` | 重建保留的离线/合成串口证据 |
| `results/verification_final/` | 最终源码对应的验收矩阵、日志、依赖版本与源码哈希 |
| `results/cli/` | 实际CLI进程回放、输入校验及不可覆盖验证 |
| `results/offline/` | 各分支回放、原始合成记录和串口片段 |
| `docs/设计说明与验收报告.md` | 算法、关联前提、局限、验收口径 |
| `reference_original/M01/` | 原任务包 118 个清单文件及原清单，不作修改 |
| `verify_delivery.py` | 本交付清单哈希核对 |

运行需 Python 3.9+，本轮实测 Python 3.12.14。回放和自动化验收仅需标准库；真实串口另需 `pyserial==3.5`。本轮运行环境未安装 pyserial，串口驱动接口通过 fake serial 验证；没有打开真实 COM。

## 立即运行回放

在本目录运行 PowerShell 命令；输出目录必须尚不存在。

```powershell
python -B -X utf8 implementation/pub_monitor.py replay --input reference_original/M01/samples/steady.jsonl --out my_results/replay_001
python -B -X utf8 tests/test_m01.py --out my_results/verification_001
python -B -X utf8 tests/build_evidence.py --out my_results/offline_001
python -B -X utf8 verify_delivery.py
```

`steady` 是合成数据，点估计 30fps，条件时间界对应约 29.70297–30.30303fps。不能作为实板 30fps 证据。

## 真实串口采样

先在你选用的 Python 环境安装串口依赖（如已有则不必重复）：

```powershell
python -m pip install -r requirements-monitor.txt
```

关闭 affine_track、串口助手及其他占用该端口的软件。确认已验证的校正系统位流运行正常。**新会话开始前必须有消除前次未完成请求的依据**，例如关闭所有 UART 发送方，复位 FPGA UART 命令/发送逻辑，确认旧请求已取消，并清除主机/适配器残留。实际复位的范围与证据应由操作者核实；关闭并重开 COM、清主机缓冲、观察短暂静默都不能单独证明旧回复不会迟到。

以下为示例，COM 号和依据需要替换；工具不会自动复位硬件或下发参数：

```powershell
python -B -X utf8 implementation/pub_monitor.py monitor --port COM5 --interval 1 --duration 60 --timeout 1.5 --out my_results/live_001 --assume-continuity --fresh-session-evidence "填写本次复位UART及清理旧事务的实际操作与记录" --conditions "盘古100P；已验证G4校正整机；1920x1080@30；静止棋盘"
```

`--fresh-session-evidence` 只是可审查的操作记录，不是软件对硬件状态的证明。未知的板号、位流/参数哈希保持 null；已知时追加 `--board-id`、`--bitstream-sha256`、`--parameter-sha256`。应保存实际使用的位流、参数和采样记录以便核对。

默认不假定计数连续：不加 `--assume-continuity` 时仍完整采样，但不生成条件速率。加该选项后，正常短间隔可以输出 `ASSUMED`；这仍假定无复位、无隐藏回绕。

计数下降默认断段，不把 `65535→0` 自动认定为回绕。只有同时提供 `--max-rate`、`--max-rate-evidence`、`--reset-exclusion-evidence`，记录本身也明确假定连续，且该上界能排除额外回绕时，才输出 `ASSUMED_MODULO`。**30fps 目标不是物理速率上界**，不要仅为得到数字填入 30。

失败后立即停止，不发下一条请求。退出码：正常完成/成功回放 0；异常、中断或输入错误 2。Ctrl+C 会保存已收到的部分数据并标 `INCOMPLETE`。异常后重新测量需要新的输出目录和新的干净会话依据。

## 输出文件

- `records.jsonl`：schema_version=1；原始样本字段、时间括号、状态字、成功/失败、假设与复位事件。回放时逐字节复制输入，包括无效 JSON 行。
- `raw_io.jsonl`：仅采样模式生成；实际 read 片段、write 驱动接受的字节及异常/隔离事件，保留噪声和错误帧。不是用 status 反推的串口字节。
- `session.json`：时间、环境、实验条件、哈希、假设、相对路径、完成状态。回放的历史起止未知时为 null；`--session` 可以保存原会话元数据，不会静默用它改变分析策略。
- `rates.csv`：每条样本的分析行；首样本和断段行无速率，保留失败原因。
- `validated_samples.jsonl`：样本质量、原始计数的解析值；保留位不单列解释。
- `summary.json`、`report.md`：数量、失败比例、有效时间、条件速率、断段原因。只对可计算区间汇总，缺失/失败区间不补值；不自动裁定 WP-3 的 25/30fps 门槛。

每次输出目录均为新建，已存在（包括空目录）也拒绝；不覆盖输入或历史记录。交付清单核对允许新增运行结果，但原清单文件变动会失败。

`results/verification/` 保留首轮测试，最终以 `verification_final/` 为准。可用 `tests/package_delivery.py --out <包目录外的新ZIP路径>` 重建清单与可重复的压缩包。
