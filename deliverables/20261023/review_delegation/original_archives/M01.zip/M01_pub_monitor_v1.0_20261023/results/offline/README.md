# Retained offline evidence

All input and serial drivers are SYNTHETIC. FAKE_NO_HARDWARE is not a COM port. No FPGA or serial hardware was opened.

P01_steady and P09_steady_repeat match byte-for-byte in rates, summary and annotations.
P03_wrap_conditional supplies artificial reset-exclusion and rate-bound evidence, which is NOT board evidence.
P07_late_after_close intentionally leaves bytes arriving AFTER session closure unread; only one request is sent. P07_late_quarantine logs bytes available at failure separately.
Original sample/data outcomes, all failure records, raw fragments and policy assumptions are retained.
