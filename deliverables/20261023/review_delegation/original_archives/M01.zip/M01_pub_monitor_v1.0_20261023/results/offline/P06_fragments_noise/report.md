# M01 publication observations

Evidence: SYNTHETIC
Session state: COMPLETE

Records: 2; computed intervals: 1
Invalid samples: 0; broken intervals: 0
Valid midpoint duration (s): 0.1011
Conditional aggregate rate (fps): 296.7359050445104

Correct response association; no reset or hidden wraps; rates are conditional observations, not exact FPGA publication times.

These are new corrected-frame publication counts, not HDMI/camera fps.
busy/params_valid and reserved bits do not establish a publication or reset.
Short increasing intervals still ASSUME no hidden wraps. No-rate intervals are retained.
Policy limits and rate bounds are reviewable assumptions, not measured hardware guarantees.
WP-3 25/30fps acceptance: NOT_EVALUATED. See rates.csv for all intervals.
