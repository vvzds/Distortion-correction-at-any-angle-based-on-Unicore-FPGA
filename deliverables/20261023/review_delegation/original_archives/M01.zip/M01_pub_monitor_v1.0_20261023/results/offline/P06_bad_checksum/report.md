# M01 publication observations

Evidence: SYNTHETIC
Session state: TAINTED_ABORTED

Records: 1; computed intervals: 0
Invalid samples: 1; broken intervals: 0
Valid midpoint duration (s): 0
Conditional aggregate rate (fps): None

Correct response association; no reset or hidden wraps; rates are conditional observations, not exact FPGA publication times.

These are new corrected-frame publication counts, not HDMI/camera fps.
busy/params_valid and reserved bits do not establish a publication or reset.
Short increasing intervals still ASSUME no hidden wraps. No-rate intervals are retained.
Policy limits and rate bounds are reviewable assumptions, not measured hardware guarantees.
WP-3 25/30fps acceptance: NOT_EVALUATED. See rates.csv for all intervals.
