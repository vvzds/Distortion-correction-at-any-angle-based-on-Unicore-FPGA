"""Scripted serial driver and deterministic monotonic clock, no hardware access."""
class FakeClock:
    def __init__(self):
        self.ns = 1_000_000_000

    def __call__(self):
        return self.ns

    def sleep(self, seconds):
        self.ns += max(1, int(seconds * 1e9))


class FakeSerial:
    def __init__(self, clock, replies=(), short_write=False, disconnect=False,
                 interrupt=False, late_reply=b"", startup=b"", late_delay_ns=1_500_000_001):
        self.clock = clock
        self.replies = list(replies)
        self.buffer = bytearray(startup)
        self.writes = []
        self.short_write, self.disconnect, self.interrupt = short_write, disconnect, interrupt
        self.late_reply = late_reply
        self.late_delay_ns = late_delay_ns
        self.late_ns = None
        self.closed = False
        self.timeout, self.write_timeout = 0.05, 1.5

    def _arrive(self):
        if self.late_ns is not None and self.clock() >= self.late_ns:
            self.buffer.extend(self.late_reply)
            self.late_ns = None

    @property
    def in_waiting(self):
        self._arrive()
        return len(self.buffer)

    def write(self, data):
        self.writes.append(bytes(data))
        if self.short_write:
            return 2
        if self.replies:
            self.buffer.extend(self.replies.pop(0))
        if self.late_reply:
            self.late_ns = self.clock() + self.late_delay_ns
        return len(data)

    def read(self, count):
        if self.interrupt:
            raise KeyboardInterrupt()
        if self.disconnect:
            raise OSError("device disconnected")
        self._arrive()
        # Fragment every read, including the parser's 2/5-byte requests.
        if self.buffer:
            self.clock.sleep(0.0001)
            result = bytes(self.buffer[:1])
            del self.buffer[:1]
            return result
        self.clock.sleep(self.timeout or 0.0001)
        self._arrive()
        return b""

    def close(self):
        self.closed = True


class NoLock:
    def __init__(self, _port):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *_):
        pass
