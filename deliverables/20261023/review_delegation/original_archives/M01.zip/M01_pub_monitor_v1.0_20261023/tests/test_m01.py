"""Executable P01-P09 acceptance; all serial input here is SYNTHETIC."""
import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "implementation"))
sys.path.insert(0, str(ROOT / "tests"))
import pub_monitor as m
from uart_adapter import PortLock, hex_bytes, uart
from fake_serial import FakeClock, FakeSerial, NoLock


def reply(count, flags=0x312):
    data = (count << 16 | flags).to_bytes(4, "little")
    return b"\xaa\x55\x05\x04" + data + bytes([sum(data) & 255])


def sample(count, seq=0, seconds=None, flags=0x312, **extra):
    seconds = seq if seconds is None else seconds
    result = dict(schema_version=1, session_id="SYNTHETIC_TEST", seq=seq,
                  evidence_kind="SYNTHETIC", t_tx_ns=int(seconds * 1e9),
                  t_rx_ns=int(seconds * 1e9) + 10_000_000,
                  request_hex="AA 55 05 00 00", response_hex=hex_bytes(reply(count, flags)),
                  status_u32=count << 16 | flags, outcome="OK", error=None,
                  continuity_assumed=True, reset_event=False)
    result.update(extra)
    return result


def rates(records, **kw):
    return m.analyze(records, m.policy(**kw))[0]


class Acceptance(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.tmp = Path(self.temp.name)

    def run_fake(self, *, interval=0.1, duration=0.3, opener=None, **kw):
        clock = FakeClock()
        fake = FakeSerial(clock, **kw)
        out = self.tmp / ("fake" + str(len(list(self.tmp.iterdir()))))
        session = m.monitor("FAKE", out, interval, duration, 1.5, m.policy(),
                            "SYNTHETIC clean session fixture", True,
                            opener=opener or (lambda _: fake), clock=clock,
                            sleeper=clock.sleep, lock_factory=NoLock,
                            evidence_kind="SYNTHETIC")
        return fake, session, m.read_records(out / "records.jsonl"), out

    def test_P01_steady_brackets(self):
        records = m.read_records(ROOT / "reference_original/M01/samples/steady.jsonl")
        rows, _, summary = m.analyze(records, m.policy())
        self.assertIsNone(rows[0]["rate_est_fps"])
        row = rows[1]
        self.assertEqual(row["delta_pub"], 30)
        self.assertEqual(row["rate_est_fps"], 30)
        self.assertAlmostEqual(row["rate_min_fps"], 29.702970297029704)
        self.assertAlmostEqual(row["rate_max_fps"], 30.303030303030305)
        self.assertEqual(row["quality"], "ASSUMED")
        self.assertTrue(summary["not_hardware_evidence"])
        self.assertEqual(summary["valid_duration_est_s"], 1)
        self.assertEqual(summary["wp3_verdict"], "NOT_EVALUATED")
        records[0]["request_hex"] = "aa55050000"
        self.assertEqual(m.analyze(records, m.policy())[2]["attempted_queries"], 2)

    def test_P02_same_count_busy_valid_reserved(self):
        # Changes in busy, valid, reserved do not publish a frame or prove reset.
        for flags in (0x012, 0x112, 0x212, 0xF812):
            records = [sample(100), sample(100, 1, flags=flags)]
            row = rates(records)[1]
            self.assertEqual(row["delta_pub"], 0)
            self.assertEqual(row["rate_est_fps"], 0)
            self.assertEqual(records[1]["status_u32"] & 0xffff, flags)

    def test_P03_wrap_requires_evidence(self):
        records = [sample(65534), sample(2, 1)]
        self.assertEqual(rates(records)[1]["reason"], "AMBIGUOUS_COUNTER")
        self.assertIsNone(rates(records)[1]["rate_est_fps"])
        row = rates(records, max_rate=60, bound_evidence="fixture physical bound",
                    reset_evidence="fixture reset excluded")[1]
        self.assertEqual((row["delta_pub"], row["quality"]), (4, "ASSUMED_MODULO"))
        self.assertEqual(rates(records, max_rate=60, bound_evidence="fixture")[1]["reason"],
                         "AMBIGUOUS_COUNTER")
        self.assertEqual(rates([sample(65535), sample(0, 1)])[1]["reason"], "AMBIGUOUS_COUNTER")
        records[1]["continuity_assumed"] = False
        self.assertEqual(rates(records, max_rate=60, bound_evidence="fixture",
                               reset_evidence="fixture")[1]["reason"], "CONTINUITY_NOT_ASSUMED")

    def test_P04_reset_missing_reconnect_version(self):
        self.assertEqual(rates([sample(1000), sample(0, 1)])[1]["reason"], "AMBIGUOUS_COUNTER")
        row = rates([sample(1000), sample(0, 1, reset_event=True)])[1]
        self.assertEqual(row["reason"], "EXPLICIT_RESET")
        self.assertIsNone(row["rate_est_fps"])
        for failed in (sample(0, 1, outcome="DISCONNECTED", status_u32=None),
                       sample(0, 1, flags=0x313)):
            rows = rates([sample(1000), failed, sample(10, 2)])
            self.assertIsNone(rows[1]["rate_est_fps"])
            self.assertEqual(rows[2]["quality"], "FIRST")
        self.assertEqual(rates([sample(1), sample(2, 1, session_id="reconnect")])[1]["reason"],
                         "SESSION_CHANGED")
        self.assertEqual(rates([sample(1), sample(2, 2)])[1]["reason"], "MISSING_SEQUENCE")

    def test_P05_long_gap_multiwrap_bad_time(self):
        records = [sample(10), sample(20, 1, seconds=3600)]
        self.assertEqual(rates(records)[1]["reason"], "MULTIWRAP_NOT_EXCLUDED")
        self.assertEqual(rates(records, max_rate=60, bound_evidence="fixture")[1]["reason"],
                         "MULTIWRAP_NOT_EXCLUDED")
        self.assertEqual(rates([sample(1), sample(2, 1, seconds=10)],
                               max_rate=60, bound_evidence="fixture")[1]["delta_pub"], 1)
        self.assertEqual(rates([sample(1), sample(100, 1)],
                               max_rate=30, bound_evidence="fixture")[1]["reason"],
                         "RATE_BOUND_CONTRADICTION")
        for second in (sample(2, 1, seconds=0), sample(2, 1, seconds=0.0, t_rx_ns=1_000_000),
                       sample(2, 1, t_rx_ns=1_000_000_000),
                       sample(2, 1, t_tx_ns=-1), sample(2, 1, t_tx_ns=True)):
            self.assertIsNone(rates([sample(1), second])[1]["rate_est_fps"])
        self.assertEqual(rates([sample(1, seconds=1), sample(2, 1, seconds=0)])[1]["reason"],
                         "TIME_REVERSED_OR_IDENTICAL")

    def test_P06_original_parser_fragment_noise_rejections(self):
        noisy = b"\x00\xaa\x00\xaa" + reply(123)
        fake, session, records, out = self.run_fake(replies=[noisy], duration=0.0001)
        self.assertEqual(session["state"], "COMPLETE")
        self.assertEqual(records[0]["status_u32"] >> 16, 123)
        fragments = m.read_records(out / "raw_io.jsonl")
        observed = b"".join(bytes.fromhex(r["data_hex"]) for r in fragments if r["direction"] == "RX")
        self.assertEqual(observed, noisy)
        self.assertEqual(fake.writes, [b"\xaa\x55\x05\x00\x00"])
        self.assertEqual(bytes.fromhex(records[0]["response_hex"]), reply(123))
        bad_frames = [reply(1)[:-1] + b"\xff", b"\xaa\x55\x04\x04" + b"\0" * 5,
                      b"\xaa\x55\x05\x03" + b"\0" * 5]
        for bad in bad_frames:
            fake, session, records, out = self.run_fake(replies=[bad])
            self.assertEqual(session["state"], "TAINTED_ABORTED")
            self.assertEqual(records[0]["outcome"], "IO_OR_PROTOCOL_ERROR")
            self.assertIsNone(records[0]["status_u32"])
            raw = m.read_records(out / "raw_io.jsonl")
            self.assertTrue(any(r["direction"] == "RX" for r in raw))
            # Received and currently buffered bytes are all saved; tail may be quarantine.
            observed = b"".join(bytes.fromhex(r["data_hex"]) for r in raw
                                if r["direction"] in ("RX", "RX_UNASSOCIATED"))
            self.assertEqual(observed, bad)
            self.assertEqual(bytes(fake.buffer), b"")
            self.assertEqual(len(fake.writes), 1)

    def test_P07_timeout_late_short_busy_disconnect(self):
        fake, session, records, out = self.run_fake(late_reply=reply(999), duration=5)
        self.assertEqual(session["state"], "TAINTED_ABORTED")
        self.assertEqual(records[0]["outcome"], "TIMEOUT")
        self.assertIsNone(records[0]["status_u32"])
        self.assertEqual(len(fake.writes), 1)  # No second request to steal the late response.
        self.assertTrue(fake.closed)
        fake.clock.sleep(1)
        self.assertGreater(fake.in_waiting, 0)  # A late reply still exists but is NEVER a success.
        fake, session, records, out = self.run_fake(late_reply=reply(888),
                                                   late_delay_ns=1_500_000_000, duration=5)
        raw = m.read_records(out / "raw_io.jsonl")
        late = b"".join(bytes.fromhex(r["data_hex"]) for r in raw
                        if r["direction"] == "RX_UNASSOCIATED")
        self.assertEqual(late, reply(888))
        self.assertEqual(len(fake.writes), 1)
        self.assertIsNone(records[0]["status_u32"])
        for options in (dict(short_write=True), dict(disconnect=True)):
            fake, session, records, out = self.run_fake(**options)
            self.assertEqual(session["state"], "TAINTED_ABORTED")
            self.assertEqual(len(fake.writes), 1)
            self.assertIsNone(records[0]["status_u32"])
            self.assertTrue(fake.closed)
        def busy(_):
            raise OSError("port busy")
        _, session, records, _ = self.run_fake(opener=busy)
        self.assertEqual(records[0]["outcome"], "SESSION_ERROR")
        self.assertEqual(session["state"], "TAINTED_ABORTED")
        _, session, records, _ = self.run_fake(startup=reply(99))
        self.assertEqual(records[0]["outcome"], "SESSION_ERROR")
        self.assertEqual(session["state"], "TAINTED_ABORTED")
        with PortLock("M01_SYNTHETIC_LOCK_TEST"):
            with self.assertRaises(OSError):
                with PortLock("m01_synthetic_lock_test"):
                    self.fail("port lock allowed another owner")

    def test_P08_windows_version_status_validation(self):
        for second, reason in ((sample(2, 1, seconds=0.005), "OVERLAPPING_WINDOWS"),
                               (sample(2, 1, t_rx_ns=99_000_000_000), "EXCESSIVE_RESPONSE_WINDOW"),
                               (sample(2, 1, flags=0x311), "INCOMPATIBLE_FW"),
                               (sample(2, 1, status_u32=0), "STATUS_BYTES_MISMATCH")):
            row = rates([sample(1), second])[1]
            self.assertEqual(row["reason"], reason)
            self.assertIsNone(row["rate_est_fps"])
        for value in (float("nan"), float("inf"), 0, -1):
            with self.assertRaises(ValueError):
                m.policy(max_gap_s=value)
            with self.assertRaises(ValueError):
                m.monitor("FAKE", self.tmp / "invalid", value, 1, 1.5, m.policy(), "fixture")
        with self.assertRaises(ValueError):
            m.policy(max_rate=30)
        with self.assertRaises(ValueError):
            m.policy(max_gap_s=3600)
        with self.assertRaises(ValueError):
            m.monitor("FAKE", self.tmp / "invalid", 1, 1, 0.5, m.policy(), "fixture")

    def test_P09_replay_determinism_interrupt_no_overwrite(self):
        source = ROOT / "reference_original/M01/samples/steady.jsonl"
        before = source.read_bytes()
        for name in ("one", "two"):
            m.replay(source, self.tmp / name, m.policy())
        for name in ("rates.csv", "summary.json", "validated_samples.jsonl", "session.json", "report.md"):
            self.assertEqual((self.tmp / "one" / name).read_bytes(),
                             (self.tmp / "two" / name).read_bytes(), name)
        with self.assertRaises(FileExistsError):
            m.replay(source, self.tmp / "one", m.policy())
        with self.assertRaises(ValueError):
            m.replay(source, source.parent, m.policy())
        self.assertEqual(source.read_bytes(), before)
        fake, session, records, out = self.run_fake(interrupt=True)
        self.assertTrue(fake.closed)
        self.assertEqual(session["state"], "INCOMPLETE")
        self.assertEqual(records[0]["outcome"], "INTERRUPTED")
        self.assertTrue((out / "rates.csv").is_file())
        broken = self.tmp / "bad.jsonl"
        broken.write_text('{broken\nnull\n' + json.dumps(sample(1)) + '\n', encoding="utf-8")
        result = m.replay(broken, self.tmp / "malformed", m.policy())
        self.assertEqual(result["records"], 3)
        self.assertEqual(result["invalid_samples"], 2)
        self.assertEqual((self.tmp / "malformed/records.jsonl").read_bytes(), broken.read_bytes())


def run_original_uart():
    sys.modules["uart_tool"] = uart
    source = ROOT / "reference_original/M01/current/uart/tests/selftest.py"
    spec = importlib.util.spec_from_file_location("m01_original_selftest", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.run_selftest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", help="new verification directory")
    args = parser.parse_args()
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(Acceptance))
    print(stream.getvalue())
    uart_log = io.StringIO()
    with contextlib.redirect_stdout(uart_log):
        uart_code = run_original_uart()
    print(uart_log.getvalue())
    if args.out:
        out = m.new_output(args.out)
        (out / "P01_P09_console.log").write_text(stream.getvalue(), encoding="utf-8")
        (out / "original_UART_U0_U5.log").write_text(uart_log.getvalue(), encoding="utf-8")
        cases = [{"id": f"P{i:02}", "status": "PASS" if result.wasSuccessful() else "CHECK_LOG",
                  "evidence_kind": "SYNTHETIC"} for i in range(1, 10)]
        cases.append(dict(id="P10", status="NOT_TESTED", evidence_kind="BOARD"))
        m.dump_json(out / "matrix.json", dict(cases=cases, original_uart="PASS" if not uart_code else "FAIL",
                                             dependencies=m.versions()))
        inputs = sorted((ROOT / "implementation").glob("*.py")) + sorted((ROOT / "tests").glob("*.py"))
        m.dump_json(out / "input_source_sha256.json", {
            p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in inputs})
    return 0 if result.wasSuccessful() and not uart_code else 1


if __name__ == "__main__":
    sys.exit(main())
