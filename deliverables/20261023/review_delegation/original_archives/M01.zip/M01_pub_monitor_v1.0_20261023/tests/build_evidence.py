"""Generate retained SYNTHETIC replay fixtures and serial traces. No COM access."""
import argparse
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_m01 import ROOT, m, sample, reply, FakeClock, FakeSerial, NoLock


def build(destination):
    out = m.new_output(destination)
    fixtures = out / "fixtures"
    fixtures.mkdir()
    cases = {
        "P02_busy_toggle": [sample(100), sample(100, 1, flags=0x112)],
        "P03_wrap": [sample(65534), sample(2, 1)],
        "P04_reset": [sample(1000), sample(0, 1, reset_event=True), sample(2, 2)],
        "P04_disconnect": [sample(1000), sample(0, 1, outcome="DISCONNECTED", status_u32=None), sample(2, 2)],
        "P04_version": [sample(1), sample(2, 1, flags=0x313), sample(3, 2)],
        "P05_long_gap": [sample(1), sample(100, 1, seconds=3600)],
        "P05_time_reversed": [sample(1, seconds=1), sample(100, 1, seconds=0)],
        "P05_same_time": [sample(1), sample(2, 1, seconds=0)],
        "P08_overlap": [sample(1), sample(2, 1, seconds=0.005)],
        "P08_huge_delay": [sample(1), sample(2, 1, t_rx_ns=99_000_000_000)],
        "P08_reserved": [sample(1), sample(1, 1, flags=0xFC12)],
    }
    for name, records in cases.items():
        path = fixtures / (name + ".jsonl")
        m.dump_jsonl(path, records)
        m.replay(path, out / name, m.policy())
    m.replay(fixtures / "P03_wrap.jsonl", out / "P03_wrap_conditional",
             m.policy(max_rate=60, bound_evidence="SYNTHETIC fixture: publication rate <=60/s",
                      reset_evidence="SYNTHETIC fixture: no reset events"))
    source = ROOT / "reference_original/M01/samples/steady.jsonl"
    m.replay(source, out / "P01_steady", m.policy())
    m.replay(source, out / "P09_steady_repeat", m.policy())
    numeric_equal = all((out / "P01_steady" / name).read_bytes() ==
                        (out / "P09_steady_repeat" / name).read_bytes()
                        for name in ("rates.csv", "summary.json", "validated_samples.jsonl"))
    if not numeric_equal:
        raise AssertionError("replay mismatch")
    fake_cases = {
        "P06_fragments_noise": dict(replies=[b"\x00\xaa\x00\xaa" + reply(100), reply(130)]),
        "P06_bad_checksum": dict(replies=[reply(100)[:-1] + b"\xff"]),
        "P06_wrong_command": dict(replies=[b"\xaa\x55\x04\x04" + b"\0" * 5]),
        "P06_wrong_length": dict(replies=[b"\xaa\x55\x05\x03" + b"\0" * 5]),
        "P07_late_after_close": dict(late_reply=reply(999)),
        "P07_late_quarantine": dict(late_reply=reply(999), late_delay_ns=1_500_000_000),
        "P07_short_write": dict(short_write=True),
        "P07_disconnect": dict(disconnect=True),
        "P07_startup_unassociated": dict(startup=reply(999)),
        "P09_CtrlC": dict(interrupt=True),
    }
    for name, options in fake_cases.items():
        clock = FakeClock()
        connection = FakeSerial(clock, **options)
        m.monitor("FAKE_NO_HARDWARE", out / name, 0.1, 0.2, 1.5, m.policy(),
                  "SYNTHETIC fixture clean start (startup error case deliberately violates)", True,
                  opener=lambda _: connection, clock=clock, sleeper=clock.sleep,
                  lock_factory=NoLock, evidence_kind="SYNTHETIC")
    (out / "README.md").write_text(
        "# Retained offline evidence\n\nAll input and serial drivers are SYNTHETIC. "
        "FAKE_NO_HARDWARE is not a COM port. No FPGA or serial hardware was opened.\n\n"
        "P01_steady and P09_steady_repeat match byte-for-byte in rates, summary and annotations.\n"
        "P03_wrap_conditional supplies artificial reset-exclusion and rate-bound evidence, "
        "which is NOT board evidence.\n"
        "P07_late_after_close intentionally leaves bytes arriving AFTER session closure unread; "
        "only one request is sent. P07_late_quarantine logs bytes available at failure separately.\n"
        "Original sample/data outcomes, all failure records, raw fragments and policy assumptions are retained.\n",
        encoding="utf-8")
    m.dump_json(out / "evidence_index.json", dict(evidence_kind="SYNTHETIC", board_test="NOT_TESTED",
                                                 replay_deterministic=numeric_equal,
                                                 replay_cases=list(cases), fake_serial_cases=list(fake_cases)))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True)
    build(parser.parse_args().out)
    print("SYNTHETIC evidence generated; no hardware opened")
