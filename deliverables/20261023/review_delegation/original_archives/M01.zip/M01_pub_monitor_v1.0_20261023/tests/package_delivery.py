"""Rebuild manifest and a reproducible ZIP of this independent M01 delivery."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def package(destination):
    destination = Path(destination).resolve()
    if destination.is_relative_to(ROOT) or destination.exists():
        raise ValueError("ZIP must be new and outside delivery root")
    manifest = ROOT / "MANIFEST_SHA256.json"
    files = sorted((p for p in ROOT.rglob("*") if p.is_file()
                    and "__pycache__" not in p.parts and p.suffix != ".pyc" and p != manifest),
                   key=lambda p: p.relative_to(ROOT).as_posix())
    rows = [dict(path=p.relative_to(ROOT).as_posix(), bytes=p.stat().st_size,
                 sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
    manifest.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    files.append(manifest)
    with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files):
            name = "M01_pub_monitor_v1.0_20261023/" + path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 23, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    digest = hashlib.sha256(destination.read_bytes()).hexdigest()
    destination.with_suffix(destination.suffix + ".sha256").write_text(
        digest + "  " + destination.name + "\n", encoding="utf-8")
    print(json.dumps(dict(zip=destination.name, sha256=digest,
                          files=len(files), bytes=destination.stat().st_size), indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True)
    package(parser.parse_args().out)
