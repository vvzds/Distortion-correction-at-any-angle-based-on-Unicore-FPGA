"""Exercise actual CLI processes, without opening a physical port."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "implementation"))
import pub_monitor as m


def check(destination):
    out = m.new_output(destination)
    source = ROOT / "reference_original/M01/samples/steady.jsonl"
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    script = ROOT / "implementation/pub_monitor.py"
    entries = []

    def run(name, args, expected):
        command = [sys.executable, "-B", "-X", "utf8", str(script)] + list(map(str, args))
        result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", timeout=10)
        (out / (name + ".stdout.log")).write_text(result.stdout, encoding="utf-8")
        (out / (name + ".stderr.log")).write_text(result.stderr, encoding="utf-8")
        entries.append(dict(case=name, exit_code=result.returncode, expected_exit=expected,
                            passed=result.returncode == expected))
        if result.returncode != expected:
            raise AssertionError(name + ": " + result.stderr)

    run("help", ["--help"], 0)
    for name in ("replay_a", "replay_b"):
        run(name, ["replay", "--input", source, "--out", out / name], 0)
    run("existing_directory_rejected", ["replay", "--input", source,
                                         "--out", out / "replay_a"], 2)
    run("nan_rejected", ["replay", "--input", source, "--out", out / "nan",
                          "--max-gap", "nan"], 2)
    run("small_timeout_rejected", ["replay", "--input", source, "--out", out / "timeout",
                                    "--timeout", "0.5"], 2)
    for name in ("rates.csv", "summary.json", "session.json"):
        if (out / "replay_a" / name).read_bytes() != (out / "replay_b" / name).read_bytes():
            raise AssertionError("determinism: " + name)
    if hashlib.sha256(source.read_bytes()).hexdigest() != before:
        raise AssertionError("input changed")
    m.dump_json(out / "checks.json", dict(cases=entries, deterministic=True, input_unchanged=True,
                                         evidence_kind="SYNTHETIC", board_test="NOT_TESTED"))
    print("CLI checks PASS; no hardware opened")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True)
    check(parser.parse_args().out)
