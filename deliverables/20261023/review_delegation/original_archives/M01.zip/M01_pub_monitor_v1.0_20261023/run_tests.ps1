param([string]$Python = "python", [string]$Out = "")
$ErrorActionPreference = "Stop"
$testScript = Join-Path $PSScriptRoot "tests/test_m01.py"
if ($Out) {
    & $Python -B -X utf8 $testScript --out $Out
} else {
    & $Python -B -X utf8 $testScript
}
exit $LASTEXITCODE
