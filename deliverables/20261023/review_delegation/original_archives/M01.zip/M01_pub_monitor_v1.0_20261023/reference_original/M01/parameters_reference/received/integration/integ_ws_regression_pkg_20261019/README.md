# integ_ws —— 校正子系统顶层骨架 + 联调仿真环境

畸变校正系统（V1.2 基线）的顶层集成工作区。corr_top.v 为顶层骨架（接口全冻结），
undistort_core 与 rect_wr_if 交付前用同名 stub 结构联调；交付后仅换编译文件即可
切全真件，corr_top 源码零改动。

## 目录结构

```
integ_ws/
├── source/
│   ├── rtl/                  # 真件 RTL
│   │   ├── corr_top.v        # 顶层骨架（V1.0.1 门控）
│   │   ├── param_mgr.v       # UART 参数管理（T_LIM 修复版，三副本哈希一致）
│   │   ├── gamma_lut.v       # Gamma LUT（01_ref 交付版原样复制）
│   │   ├── undistort_map.v / undistort_line_cache.v / undistort_bilinear.v
│   │   │                      # 二号交付真件（与 core 同套 4 文件）
│   │   ├── undistort_core.v # 二号交付真件（V1.2，功能验收通过；WNS 修复待二号回传）
│   │   └── rect_wr_if.v      # rect_wr_if 交付真件（V1.0，验收通过）
│   └── stub/                 # 同名 stub（module 名与真件相同）
│       ├── undistort_core_stub.v   # 恒等复制引擎（真走 D2/C2'/像素流契约时序）
│       └── rect_wr_if_stub.v       # 行为级乒乓双 bank 写回（D3/C3' 语义同真件）
├── sim_models/
│   └── ideal_link.v           # 一号链路侧理想替身（DDR 数组 + 12 项协议断言）
├── tb/
│   ├── corr_top_tb.v          # 自校验 TB（用例 I0-I7）
│   ├── run_corr_top_stub.do   # 批仿真：stub 结构版
│   ├── run_corr_top_full.do   # 批仿真：全真件版（交付后用）
│   ├── run_log_20261015_baseline_v1.0.log        # V1.0 竞态基线（I6=0008_0012，竞态缺陷证据）
│   ├── run_log_20261015_final_v1.0.1.log         # V1.0.1 干净回归（旧判据 I6=0007_0012）
│   ├── run_log_20261017_tlimfix*.log              # T_LIM 修复三段回归（corr_top/param_mgr/gamma）
│   ├── run_log_20261017_stub_preplanB.log         # 方案 B 前 stub 基线（旧判据 I6=00070012）
│   ├── run_log_20261017_full_pretb_adapt.log      # 全真件 TB 适配前（k1=-0.1 旧激励+300ms 看门狗）
│   ├── run_log_20261017_full_preplanB_i6fail.log  # 全真件 I6 失配定性证据（err=1，got=00080012）
│   ├── run_log_20261018_stub_planB.log           # 方案 B 后 stub 全绿（I6=00080012，21s）
│   └── run_log_20261018_full_planB.log           # 方案 B 后全真件全绿（I6=00080012，3'23"）
├── README.md
└── status_map.json            # status 32bit 位域语义（供 uart_host_tool 可选映射）
```

## 运行方法

ModelSim（vsim 在 PATH 或用全路径，工作目录 = integ_ws/tb）：

```
vsim -c -do run_corr_top_stub.do
```

全部通过时末行打印：`=== ALL TESTS PASSED (err=0) ===`

## 用例覆盖（I0-I7）

| 用例 | 验证内容 |
|---|---|
| I0 | 复位静默：复位中/释放后（valid=0）契约输出全 0、TX 空闲高 |
| I1 | 门控启动：无参数不启动；0x01 合法组 -> valid -> 自动 start -> D2 锁源 -> 首行读 addr=0/len=119 |
| I2 | 身份复制：帧#1 逐字==golden；0x02 恒等仿射+使能帧间隙生效（G01 共存回归） |
| I3 | Gamma 帧间隙原子切换：帧#3 仍为旧参数，帧#4 起 B 通道取反生效 |
| I4 | 0x05 status 回读（宽松：版本/valid/pub 下限） |
| I5 | 跳帧后到优先：连发 f1/f2/f3，帧#6 锁最新 f3；帧#5/6/7 逐字==golden |
| I6 | 越界组停机：fx=64.0 -> 在途帧#8 rel 拍 swap -> valid=0 -> 帧#9 start 被门控拦截停机；wait_pub(8) 后精确回读 0x0008_0012（双模式统一）；合法组自动重启 |
| I7 | 慢写口+D3 互锁：重启帧#9 写出头/尾各阻塞 3720 拍；帧#10 slot_req 严格晚于帧#9 commit；帧#8/#9 逐字==golden |

全程同时监听 ideal_link 12 项契约断言（violation 计数为 0）。

## 切换全真件

1. 协作者交付的 undistort_core 4 文件套件（core/map/line_cache/bilinear）与
   `rect_wr_if.v` 放入 `source/rtl/`（2026-10-18 已部署，与交付原件哈希核验一致）；
2. 跑 `run_corr_top_full.do`（与 stub 版差 core 4 文件 + wr_if 的编译行）。

## 已知说明

- stub 版 core 为恒等映射（参数不参与数据通路），I2-I7 的 golden 比对验证的是
  结构链路（拼字/时序/契约/帧调度），映射数学正确性由二号 core 自带 TB 负责；
- gamma 1 拍流水无标志透传端口，顶层把 core 的 sop/eop/sof/eof 打 1 拍对齐后再接
  rect_wr_if（corr_top.v 内 `r_*` 寄存块），真件交付后此对齐仍必需；
- 仿真加速：corr_top 例化 CLK_FREQ=12.5MHz（波特分频 DIV=108，10 倍波特加速），
  时钟仍 8ns，逻辑不变（param_mgr_tb 同款手法）；
- start 输出带当拍 params_valid 组合门控（corr_top V1.0.1 竞态消除）：armed 在
  帧间隙第 1 拍读到的 valid 可能是 swap 前旧值（param_mgr 的 swap_go 组合于
  !busy，busy 拉低次拍即切换生效），而 start 脉冲拍恰为 core 的参数采样拍——
  门控保证两者同拍读到 swap 后真值，越界组切换不产生竞态尾帧。真件集成不依赖
  core D06 对竞态 start 的拒绝行为（D06 仍作为 core 兜底保留）；
- 预计仿真时长较长：stub 版 9 帧 ≈ 20M 拍、看门狗 300ms；全真件版帧周期实测
  ~84.3ms/帧（row-0 映射 + C2' 供给节拍），9 帧 ≈ 95M 拍，看门狗已放宽到 1.5s；
- 全真件版 TB 适配（2026-10-18）：0x01 激励改真恒等参数组（v1.0 沿用 T3 组
  k1=-0.1，stub 时代参数不进数据通路无感，真件 core 忠实执行反畸变映射则与
  恒等 golden 必然失配）；I1 首读捕获改事件等待（真件在 row-0 映射完成后才发
  首个 C2' 读，时延远大于 stub，固定 20 拍窗按 stub 校准已废止）；
- I6 精确回读判据升版（2026-10-18 方案 B）：全真件自由连续帧节拍下，在途帧#8
  （合法参数、start 拍锁存）的 pub#8 可能落在 0x05 快照前——真件 rel->pub 写出
  滞后 ~0.23ms 远短于 stub 的 ~8.5ms，TB 收尾等待 ~0.39ms 介于两者之间，次序随
  模式翻转（run_log_20261017_full_preplanB_i6fail.log 定性证据）。属良性口径差异
  非缺陷：pub#8 落槽 7 内容经 I7 逐字校验==golden(f4)、停机检查全过、合法组
  重启正常。修订：0x05 前加 wait_pub(8)（等在途帧写出收尾、链路全静止后快照），
  双模式统一判据 0x0008_0012、与 rel->pub 滞后解耦；旧判据 0007_0012 废止。
  注意与 run_log_20261015_baseline_v1.0.log 的 V1.0 撞值（同为 0008_0012）机制
  完全不同：V1.0 是无门控 start 让 core 次拍锁到越界组（真竞态缺陷，已由 V1.0.1
  门控消除）；本版是合法在途帧发布先于快照（正确行为，pub=8 停机）。
