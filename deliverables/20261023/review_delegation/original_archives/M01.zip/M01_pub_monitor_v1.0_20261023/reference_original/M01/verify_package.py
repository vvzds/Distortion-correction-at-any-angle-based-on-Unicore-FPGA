from pathlib import Path
import hashlib, json, sys
root=Path(__file__).resolve().parent
rows=json.loads((root/'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
expected={r['path']:r for r in rows}
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p != root/'MANIFEST_SHA256.json'}
bad=[]
for name,r in expected.items():
    p=(root/name).resolve()
    if not p.is_relative_to(root) or not p.is_file(): bad.append('MISSING/UNSAFE '+name);continue
    data=p.read_bytes()
    if len(data)!=r['bytes'] or hashlib.sha256(data).hexdigest()!=r['sha256']: bad.append('CHANGED '+name)
bad += ['UNEXPECTED '+n for n in sorted(actual-set(expected))]
print('PACKAGE_INTEGRITY', 'PASS' if not bad else 'FAIL', 'files=',len(rows))
for s in bad: print(s)
sys.exit(1 if bad else 0)
