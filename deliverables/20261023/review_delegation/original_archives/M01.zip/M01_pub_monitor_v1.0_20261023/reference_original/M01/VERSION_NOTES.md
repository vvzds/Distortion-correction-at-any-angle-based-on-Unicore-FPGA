# 版本、证据与使用边界

本包状态 TASK_READY；目标配套模块尚未制作，包中 existing/source 自测不代表新模块完成。

## 版本选择（以审查结论为准）

| 目录/成果 | 本包定位与完整哈希 |
|---|---|
| current/uart/uart_tool.py | **当前有效 UART：tlimfix**，043f8076f3ee9b810081fa337b6ed0cdffa85131ee4a3c04f409534960331a57。已移除旧±256警告，保留±4096预检，支持fields列表和字典；依据references/uart_host_tool_V1.0_增量接收审查结论_设计方_20261018.md |
| current/refill/ | 官方补发参考件：param_mgr.v/tb、status冻结V1.1、status_map_V1.2.1.json；本包当前status映射优先用此版本 |
| current/host/calibration_tools/calibrate.py | 10-18审查修订版，464e6fa5aa0536db14c8d062357f2f3c8b94735bae118aa3af13ce7784c1c273 |
| current/host/calibration_tools/capture.py | 10-18修订版，e0d686e96d55c8c39edaa63888ab8724af2f0d22139e9212d3f2bb4e67bb535b |
| current/host/calibration_tools/linearity.py | R05修订版，47eb06a2d861c6ed39bbadd6d5b7220098b9d1ee7614d4bcfd88b6cb87f76df8 |
| current/host/calibration_tools/mtf50.py | E8，157e32efd266f1155aadc42439b0e1a30a6dfc76d88497827cd6b9359bc905d7 |
| current/host/UART_HOST_TOOL/ | **历史依赖，仅为复现10-18 Host审查保留**；其ac980be3…主脚本与仓库/affine_track实采包一致，但不是UART当前有效版本。新实现必须用current/uart，不以文件日期推翻专项接收裁定 |
| current/affine_reference/ | 已有affine_track查询/闭环调用参考，非本包要重写的目标；它原来配套旧UART，新观测器不把这种历史绑定当作新协议 |

## 原件、规格与运行边界

1. archives保留原ZIP；SOURCE_PROVENANCE逐件记录路径、成员、哈希。current/host只对mtf50叠加E8，current/uart独立保留完整tlimfix包，避免混改历史主机包。current/uart/status_map.json还是原1.2；当前命令应选current/refill/status_map_V1.2.1.json。旧字典status_map_uart仍兼容，但非新使用首选。
2. current/uart/reference_original内旧T_LIM RTL、status V1.0与reference_current“待收到”记录是历史状态；当前补发本体在current/refill。原件不改；V1.1是status权威。I6应在wait_pub(8)后核对0x00080012；U4旧0x00070012构造帧仍有效。
3. current/rtl_reference来自main 09f53a3，只供端口核对，不是完整可综合工程；核心G4生产基线仍9e9e0fc。三项PC软件无需PDS/ModelSim/完整宿主即可独立制作。目标目录implementation/待承接方新建。
4. 0x05 bit8不证明刚发送的参数已生效，busy下降不证明发布完成；0x01/02/04没有ACK。0x04 bit1仍为直方图均衡预留，不能自加控制功能。非法参数也可进入影子组并在swap后令valid=0，不应把“拒收”理解为保持旧参数。
5. 历史README/脚本“弱畸变”提示不是当前镜头约束；真实k1≈-0.381485已采信。RMS/fx-fy/直线度等SOP不自动升级为本包正式门槛。参数编码包不是完整原始标定图或板端生效证据。
6. selftest_fixed_tools.py是旧18/18函数/数值/源码探针，不等于R03端到端遍历。当前E8用test_mtf50_e8.py。Host_review的synthetic/calibration/*.png多为故障注入占位字节，必须配合其替身逻辑，不能当真实PNG。historical_reviews脚本只作参考，运行前审查旧路径/覆盖输出假设。
7. requirements-reference.txt是本机观测环境。包内不含解释器/第三方安装器，安装需网络或自备wheels；建议英文短解压路径。旧OpenCV路径失败应原样报告或做可追溯的无损路径适配。
8. 使用前python verify_package.py。开发放implementation；原current/references不变。修复原工具另放candidate并交diff。校验器严格检查文件集；开发后对未修改原包副本校验，不能改旧manifest掩盖变化。
9. 本包新CLI/JSON都是候选软件契约，不是新冻结FPGA协议。真实板端/校正前后照片尚缺，标NOT_TESTED；不影响软件开工，但阻止硬件性能或质量签收。

待您转交：按包名推荐方；若无错误不进行回复。

本次工作主要由 GPT-6 模型完成。
