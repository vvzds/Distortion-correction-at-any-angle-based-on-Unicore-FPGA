# M01 新帧发布率观测与回放：制作任务书

推荐一号协作者；配套软件新划分，支持已有 WP-1/WP-3。现有 query_status/affine_track.confirm_status 已有查询能力，须复用，不重写协议栈。

## IN / OUT

IN：持续只读 0x05 会话、原始字节记录、时间界记录、离线重放、发布率与异常统计、JSON/CSV/Markdown 报告。
OUT：参数写入、0x01–04 自动配置、相机抓图、HDMI 帧率检测、内部 A+B 统计寄存器、修改 FPGA。不能与 affine_track 抢同一串口；可单独测量，未来由单一串口所有者调用共享采样函数，首版禁止两个进程同时打开 COM。

## 冻结接口

- 115200 8N1，无流控；请求 AA 55 05 00 00；响应 9 字节 AA55 05 04 + status 小端 + payload 累加和。
- status[7:0]=0x12，[8]=params_valid，[9]=core busy，[15:10]保留零，[31:16]=pub_count16。
- 快照在命令受理拍，处于 host 请求前时间与完整响应收完时间之间（仅在会话干净且响应可归属时成立）；host 收包时间不是 FPGA 发布时刻。无事务 ID、无复位计数，无法从单个计数器严格区分复位和回绕。
- 回读复用 read_status_frame/parse_frame；用串口包装器保存 read/write 原字节。错误帧/噪声也保存，不能反推重建原始帧充作原始抓取。

## 建议实现接口（待实现，不是可执行现有命令）

`python implementation/pub_monitor.py replay --input samples/steady.jsonl --out results/replay`

`python implementation/pub_monitor.py monitor --port COMx --interval 1 --duration 60 --out results/live`

默认只读，单请求在途；间隔须有限且正数，超时不少于既有解析器下限 1 秒，建议沿用 1.5 秒。每次结束正常关闭串口，Ctrl+C 保留部分记录并标 incomplete。超时后必须隔离迟到响应，明确重新同步步骤及丢弃字节；无法归属的响应不得作为新请求样本。参考 query_status 每次清输入缓冲不保证消除尚未到达的旧响应，必须在设计说明中处理，宁可断段失去一个区间，也不可伪造成功率。

records JSONL schema_version=1：session_id、seq、evidence_kind(SYNTHETIC/BOARD)、t_tx_ns、t_rx_ns（同一 monotonic_ns 时间基准）、request_hex、response_hex、status_u32（失败为 null）、outcome、error、continuity_assumed、reset_event。session 元数据单独 JSON：UTC 起止/时区、主机与依赖、板卡/位流/参数包哈希（未知 null）、实验条件、串口配置、轮询/超时、连续性假设和最大发布率上界（未给则 null；30fps 目标不是物理上界）。文件路径相对包/输出根，记录 raw 收发片段可另存 JSONL。

rate CSV：session_id、段号、起止 seq、delta_pub、duration_est_s、duration_min_s、duration_max_s、rate_est_fps、rate_min_fps、rate_max_fps、quality、reason。首样本没有速率。midpoint 差作估计时间；对不重叠 host 时间区间 [a0,b0]/[a1,b1]，时间界 [a1-b0,b1-a0]，正值时速率界 [delta/(b1-a0),delta/(a1-b0)]。这些只是“响应归属正确、无复位/漏掉多次回绕”等条件下的观测界，不是精确发布时刻。

## 歧义处理

- 正常连续样本计数相同时可记 delta=0；不能仅因 busy=0/valid=0 就推断停机或参数已生效。
- 计数下降默认 AMBIGUOUS_COUNTER，断段不输出精确 fps；边界 65535→0 也可能是复位。只有明确配置连续性假设并有独立事件/上界证据排除复位与多次回绕时，才报告条件性模差，并保留 assumed 字样。计数不下降也不能证明无复位，整段报告须带假设。
- 缺样/超时/断线/版本变化/显式复位断段；跨长间隔若无法排除模 65536 多次回绕则未知。最大速率配置只能作为可审查假设，不能任意裁掉快/慢样本使门槛通过。
- 原始数、全部失败率、有效时长、样本数量齐全；不输出把重复 HDMI 帧当新校正帧的值；不自动判定 WP-3 ≥25/30 达标。

## 验收矩阵

| ID | 覆盖 | 必须断言 |
|---|---|---|
| P01 | 100→130，间隔1秒 | 包内 steady 合成记录给出30fps点估计；界按括号公式；标 SYNTHETIC |
| P02 | 相同计数、busy翻转 | delta0，busy 不产生发布事件 |
| P03 | 65534→2 | 默认歧义；显式连续且有上界的模式才取4，报告假设 |
| P04 | 1000→0、重新连接、版本变化 | 断段，不产生巨大 fps |
| P05 | 长缺样/多回绕/时间回退/同时间戳 | 不可计算标无效，保留原始数据 |
| P06 | 分片串口、前导噪声、坏校验、错长度/命令 | 正确解码或具名拒绝；所有原始片段保留 |
| P07 | 超时后的迟到响应、短写、串口占用/断开 | 不错配响应；会话有失败/断段记录，无无限等待 |
| P08 | 请求窗口重叠/延迟极大、版本非0x12 | 不悄悄沿用正常速率；显式不兼容/无效。保留位按冻结不单列解析，保存原始字，不能仅据保留位变化推断发布 |
| P09 | replay 两次、Ctrl+C、输出目录已有文件 | 重放数值确定；部分结果可读；不覆盖原始输入 |
| P10 | 可选真实板测 | 单列 BOARD，提供位流/参数/日志哈希；无板则 NOT_TESTED，不影响纯软件验收 |

交付 implementation 源码、测试/fake serial/完整矩阵、离线结果、使用说明与局限、依赖版本、manifest。协议/位域无变化，既有 UART selftest 仍通过。软件验收不依赖当前 A+B 收敛，也不等于板端性能验收。

待您转交：一号协作者；若无错误不进行回复。

本次工作主要由 GPT-6 模型完成。
