# 已验收数学路径对照

`undistort_map_v12_ref.v` 来自已交付、设计方独立复测通过的 Git 提交 `209ff75` 的 `source/rtl/undistort_map.v`。唯一文本变更是模块声明 `undistort_map` → `undistort_map_v12_ref`，使原版与G1版能同时例化；仅供仿真，不加入PDS综合源文件。

新增 `sim/undistort_map_equiv_tb.v` 不执行real golden，专门检查流水改动前后的坐标逐位相同和额外2拍延迟；原有560点real模型与冻结T0–T9仍单独执行，未被它替代。
