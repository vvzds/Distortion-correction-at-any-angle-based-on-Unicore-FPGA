# M01_新帧发布率观测与回放_推荐一号协作者_20261023

状态：TASK_READY，目标模块尚待制作。本包只制作观测器；既有查询/周期状态确认不可重复冒领。

## 阅读顺序

1. VERSION_NOTES.md：确认当前/历史版本和未验收边界。
2. TASK_BRIEF.md：功能、IN/OUT、建议文件接口、用例、交付物。
3. references/模块分工与工作包交付总说明_v2.0.0.md：现有分工与优先级。
4. references 内整体设计/冻结协议/审查结论；current/host/docs 是UART协议原件；current/refill是当前状态映射与补发参考件。
5. SOURCE_PROVENANCE.json：逐文件原件来源；MANIFEST_SHA256.json：本包完整性。

## 开始制作

解压到英文短路径，如 D:/handoff/M01（ZIP根目录为M01）。在包根执行：

```powershell
python verify_package.py
python -m venv ../venv_M01
../venv_M01/Scripts/python.exe -m pip install -r requirements-reference.txt
../venv_M01/Scripts/python.exe -B current/uart/uart_tool.py selftest
```

解释器建议Python3.12；requirements是本机观测版本，安装需联网或自备wheels。verify_package仅需Python标准库；UART自测不需要串口硬件。完整依赖观测与本次实际复验见verification/。不要在current目录修改参考件；新实现另建implementation/并提交独立验收。

已存在的 E8 参考自测可运行：

```powershell
$env:PYTHONUTF8='1'
../venv_M01/Scripts/python.exe -B current/host/test_mtf50_e8.py
```

本次打包实际执行了UART参考自测和E8参考自测，结果见verification/reference_checks.json和日志。这不是本模块的新功能测试，不代表R03/板端性能/实拍质量通过。任务书中的implementation命令均待实现，不能现在直接运行。

## 内容与不足

current/uart：已接收tlimfix主脚本与测试；current/refill：官方新版参考本体；current/host：标定审查修订源码＋E8覆盖＋历史依赖/测试（其UART_HOST_TOOL为旧版）；archives：完整原ZIP只读；parameters_reference：冻结恒等/真实参数与编码；current/rtl_reference：接口核对片段；current/affine_reference：现有状态查询调用参考（非独立运行工程）。historical_reviews仅在相关包内提供完整旧诊断素材，运行前读其路径/替身假设。

samples：本次新建候选模板/合成记录；没有真实板端输入，不冒充实拍证据。软件可独立开工，硬件结论需以后提供真实数据。包内不含第三方安装器、凭据或需登录的材料。

如发现既有源码缺陷，记录并在candidate中修复/交diff；不改档案、不把失败删出矩阵。回传源码、测试、原始日志、结果、版本/哈希和未完成项；若无错误不进行回复。

待您转交：按包名推荐方，M02留本机。

本次工作主要由 GPT-6 模型完成。
