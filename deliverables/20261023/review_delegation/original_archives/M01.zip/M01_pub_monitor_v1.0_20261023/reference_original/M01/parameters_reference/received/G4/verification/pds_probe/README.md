# PDS compile 最小复现

本目录 `probe.v` 仅为一个时钟触发的 D 寄存器，不依赖图像 RTL。将目录置于英文绝对路径，在该目录用 PDS 2022.2-SP6.1 shell 运行：

```powershell
& 'D:/FPGA PDS/site/PDS_2022.2-SP6.1-win64/bin/pds_shell.exe' -file run_probe.tcl
```

该环境在 `compile -top_module probe` 进入RTL分析前报 `Flow-0189: Internal error occurred`。`run_probe.pds` 为工具自动生成的原生工程，`../logs/pds_minimal_console.log` 是当次完整命令输出。四份 core RTL 显式登记后同样在compile起始失败，日志见 `../logs/pds_core_explicit_console.log`。

此复现只能说明当前 PDS 安装/运行环境下无法得到资源与时序报告；尚未证明具体根因，也不能推断 RTL 综合是否会通过。请在可正常编译此 probe 的环境中，再执行 `../pds_core.tcl` 并保存编译、综合、资源和WNS报告。
