# OV5640 Brown4 参数接入及 G4 核心离线核对

日期：2026-10-22。只执行用户要求的第 1、2 步，图像配置固定 1920×1080@30fps。
本包不包含新校正位流，不会发送 UART 或烧录开发板。完整结论以 `验证报告.md` 为准。

## 使用范围

- 模型：普通针孔 Brown4，参数顺序 fx/fy/cx/cy/k1/k2/p1/p2，k3=0。
- K_out=K_in，不做裁剪、缩放、新主点选择或鱼眼模型转换。
- 坐标：左上原点、x 向右、y 向下。DDR 行反转由 core 按冻结契约处理，不能改变 p1/p2/cy 的符号来“修方向”。
- 基线：用户已确认 G4。`received/G4/source/rtl/` 四件 RTL 与设计方 I0–I7 集成包内四核逐字节一致，未使用 G6 候选替换生产基线。

## 文件

| 路径 | 内容 |
|---|---|
| parameters/parameter_encoding.json | 浮点值、量化值、补码、字节顺序、误差、G02 范围、完整 UART 帧 |
| parameters/calibration_q16.vh | 仿真/审阅用有符号常数，不会自动写入 FPGA |
| parameters/real_0x01.bin / .hex | 真实参数 0x01 完整 37B 帧，校验 A0 |
| parameters/identity_0x01.bin / .hex | 保留实测 K、四畸变系数为零的恒等测试组 |
| parameters/real_parameters.csv / identity_parameters.csv | 兼容已交付 uart_host_tool 的 CSV，aff_en=0、gamma_en=0 |
| parameters/affine_disabled_0x02.bin | 恒等矩阵、aff_en=0 的完整 30B 帧 |
| parameters/gamma_disabled_0x04.bin | gamma_en=0 的完整命令帧 |
| prepare_and_check.py | 生成参数、独立 NumPy 浮点 Brown4/双线性参考、定点诊断模型及全帧向量 |
| run_verification.ps1 | 可重跑 UART、map、边界、cache、bilinear、完整 core 测试 |
| sim/calibration_*_tb.v | 本次新增的自校验 testbench，包含超时和失败退出门 |
| received/ | 标定说明、G4 包、设计方集成回归件，保持原字节，不据其中历史待办推断当前状态 |
| reference_uart/uart_tool.py | 冻结的已交付 UART 编码工具原件 |
| reports/、logs/ | 本轮实跑结果、输入哈希、离线误差指标和日志 |
| vectors/ | 全帧坐标与像素向量（可由生成器重建） |

## 重跑

需要 Python 3 + NumPy、Icarus Verilog。Python 路径可显式给出：

```powershell
& ./run_verification.ps1 -Python 'C:\path\python.exe' -IverilogRoot 'C:\path\iverilog\app'
```

只跑快速检查：

```powershell
& ./run_verification.ps1 -Cases uart,boundary,bilinear,cache -SkipVectorGeneration -IverilogRoot 'C:\path\iverilog\app'
```

默认 core 仿真为恒等和真实高频两次 1920×1080 输出，真实参数会发生行缓存重载，耗时明显长于快速单元测试。
`-Cases real_smooth` 可选运行完整分段渐变核心；本轮主要功能门禁不要求重复这一帧，渐变图案全帧浮点对照已包含在离线检查中。
runner 使用临时 subst 驱动器解决此 Icarus 发行版对长可执行路径的兼容问题，并在结束后释放映射。
不需要降低图像尺寸、使用 SIM_MODE 或改变 RTL 来缩短时间。

## 后续板测时的使用顺序（本轮未执行）

1. 先准备已接入真实 core 的校正整机位流；空 correction_hook 的宿主包不能用于本步骤。
2. 关闭仿射和 Gamma（0x02、0x04），下发 identity 0x01，确认方向、颜色、首尾行与旁路一致。
3. 再下发 real 0x01，使用棋盘/直线对比。摄像头窗口、镜头焦点、分辨率与方向须保持本次标定条件。
4. 0x05 只能检查现行组合法性及发布活性，不是某次参数命令的 ACK。结合可见图像确认切换。
5. 本轮不承诺强畸变处理达到 30 个新校正帧/秒；HDMI 30Hz、采集帧率、校正发布率分别报告。

参数 CSV 的既有工具发送顺序为 0x01→0x02→0x04；从曾运行其他仿射/Gamma 参数的板端切换时，应先单独关闭仿射/Gamma，再用新畸变组，避免中间参数组合。所有二进制帧均为离线产物，本包没有自动打开串口的逻辑。
