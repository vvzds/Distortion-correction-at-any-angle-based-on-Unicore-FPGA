# undistort_core 阶段2 · G4读地址拆级候选版

2026-10-18当前状态：用户已选择 **C：G4 与 corr_top 集成并行推进**。G4 core 已实现并通过 ModelSim 冻结 T0–T9、8组独立 golden 和新协议测试。先读 `doc/G4_实现验证交接_20261018.md`。本包尚无 G4 SP6.4 综合、125MHz闭合或实板结论。

适用：Logos2 PG2L100H-6IFBG676、单一125MHz域、1920×1080 RGB565。G4相对G3只改core，增加READ_ADDR地址准备阶段；外接口、map/cache/bilinear和原21件测试不变。本包为RTL/仿真子任务包，不含完整采集、DDR、写回、HDMI或bitstream。

并行集成准备已完成；本机缺少真实corr_top、rect_wr_if及一号冻结生产工程，暂不能运行全真件I0–I7或P&R。具体缺件及冻结连接见 `doc/G4_corr_top并行核查_20261018.md`。G3/G4方案和评审原件的“待启动”措辞为当时历史记录，不代表本轮状态。

只有G3有SP6.4实测：WNS −1.372ns、LUT4299/FF3744/APM106/DRM16；不能用作G4资源/时序结论。DRM≤12、强畸变稳态≤2拍/像素仍未达成。G4恒等首帧4,147,455拍、稳态2.000000拍/像素；普通miss增加1拍/行加载，强畸变实测详见交接表。

## G4当前文件与证据

|路径|内容|
|---|---|
|`doc/G4_实现验证交接_20261018.md`|实现时序、测试范围、精确周期、复现及SP6.4交接|
|`doc/G4_corr_top并行核查_20261018.md`|实际工程/工具核查、连接契约与缺件|
|`sim/undistort_core_g4_protocol_tb.v`、对应runner|RUN/SIM握手、预取边界、返回压力、复位及负向故障|
|`verification/logs/g4_20261018/`|30件最终日志；含1件有意注入提前req的预期FAIL|
|`verification/g4_baseline_files.tsv`|对照G3：仅core改变，其他3生产件和21测试不变|
|`verification/g4_sim_sources_sha256.tsv`|18件实际运行副本与工作树字节一致|
|`verification/g4_logs_sha256.tsv`、`g4_evidence_summary.json`|日志哈希与核对结论|
|`verification/g4_core_vs_g3.patch`|最小core差异|
|`verification/collect_g4_evidence.py`|基线、运行副本、正向结果和预期故障证据检查|
|`verification/package_g4.py`|干净提交后打包、逐文件manifest核对及根目录英文副本|

## G3及更早历史证据

|路径|内容|
|---|---|
|`doc/G3_SP64_接收回复_20261018.md`|新收综合证据复核、源码路径归属、当前未闭合状态|
|`doc/G4_读地址拆级方案_待决策_20261018.md`|只改core的候选拆级方案、握手/预取影响及验证计划，未实施|
|`verification/design_g3_sp64_20261018/`|G3 SP6.4原始4件报告与设计方2件原文，逐字节保存|
|`verification/g3_sp64_sources_sha256.tsv`|本轮6件原件的长度/SHA256核对|
|`verification/g3_sp64_receipt.json`|收件、指标与生产/既有测试未变核对|
|`source/rtl/`|4个Verilog-2001生产模块；G3仅修改map|
|`sim/`|冻结T0–T9、独立real golden、新增G3逐位等价测试|
|`doc/G3_处理回复_20261018.md`|G2报告核查、G3寄存/精度/接口影响、复核要求|
|`doc/G3_验证结果_20261018.md`|本轮实测、验证方法/观测信号/预期现象|
|`doc/G3_交付核对_20261018.md`|交付范围、校验与后续操作|
|`verification/logs/g3_20261018/`|G3当轮结果、transcript、完整console、批处理退出码|
|`verification/design_g2_sp64_20261018/`|G2 SP6.4原始4件报告与设计方接收结论，逐字节保存|
|`verification/g2_sp64_sources_sha256.tsv`|G2原附件到归档件的完整哈希核对|
|`verification/g3_frozen_files.tsv`|9件冻结文件与已验收209ff75 Git内容核对|
|`verification/g3_existing_sim_files.tsv`|原有19件TB/runner相对G2无改动|
|`verification/g3_sim_sources_sha256.tsv`|本轮14件仿真源码/脚本与交付副本核对|
|`verification/g3_logs_sha256.tsv`|本轮日志完整哈希|
|`verification/g1_baseline/`|已验收V1.2 map仿真对照，不参与综合|
|`verification/reference_package/`|参考原件；param_mgr采用补发修订件，平移±4096|
|`verification/collect_g3_evidence.py`|本轮原件、冻结件、运行副本与日志核对脚本|
|`verification/pds_core.tcl`|SP6.4纯核综合入口；4个生产RTL|

`doc/implementation.md`为基础接口约定；当前G4行为以G4交接文档为准，map级表仍见G3文档。G1/G2处理回复及日志保留历史状态，不混作G3实测。

## ModelSim复现

解压至英文路径，如 `D:/undistort_stage2`。本机ModelSim 10.7加载中文路径不可靠。将ModelSim win64目录加入PATH后，从sim目录顺序运行：

```powershell
cd D:/undistort_stage2/sim
vsim -c -do run_undistort_map.do -l map_g3_transcript.log *> map_g3_console_full.log
if ($LASTEXITCODE -ne 0) { throw 'Map simulation failed' }
Get-Content map_result.txt
vsim -c -do run_undistort_map_g3_equiv.do -l map_g3_equiv_transcript.log *> map_g3_equiv_console_full.log
if ($LASTEXITCODE -ne 0) { throw 'G3 equivalence failed' }
vsim -c -do run_undistort_line_cache.do -l cache_g4_transcript.log *> cache_g4_console_full.log
if ($LASTEXITCODE -ne 0) { throw 'Cache simulation failed' }
vsim -c -do run_undistort_core_g4_protocol.do -l core_g4_protocol_transcript.log *> core_g4_protocol_console_full.log
if ($LASTEXITCODE -ne 0) { throw 'G4 protocol failed' }
vsim -c -do run_undistort_core.do -l core_suite_transcript.log *> core_suite_console_full.log
if ($LASTEXITCODE -ne 0) { throw 'Core suite failed' }
```

必须检查新生成的结果：560点real PASS；G3等价128组/51,520点PASS、extra_latency=4；core suite末两行：

```text
=== CORE SUITE PASSED: T0-T9 (err=0) ===
=== ALL TESTS PASSED (err=0) ===
```

原map runner保持冻结，不能仅凭退出码认定通过；同时核对编译日志及结果新生成时间。G3等价和core runner删除旧结果、显式vopt并检查PASS/FAIL。ModelSim退出有已知FileWatch Tcl提示，完整console原样保存；本机transcript漏记部分运行期puts，不能只交transcript。

历史 `run_undistort_map_equiv.do` 为G1专用（相对V1.2 +2拍）；`run_undistort_map_g2_equiv.do` 为G2专用（+3拍）。G3运行新增脚本（+4拍），不改历史判据。

G4协议正常MODE0/1须各有 `ALL TESTS PASSED (err=0)`。故障注入文件须有 `FAIL err=33`，runner须输出 `EXPECTED EARLY-REQUEST FAULT DETECTED`；不可将其当正向失败或删除。G4协议TB隔离调度，不替代独立real算法golden。计划V7的可选G3/G4 core事务比对未执行，map等价不代表core等价。

## SP6.4与集成

历史G3：设计方已在正常SP6.4以 `-file verification/pds_core.tcl` 对G3重跑，原始结果在G3归档。G4须以当前四件生产RTL重新运行并取得新报告。复现时仍须核对当前生产源码哈希、8ns时钟、完整setup/hold、关键路径、约束覆盖与资源，不据退出码或“复核通过”字样认定时序闭合。

本机SP6.1已知在单寄存器探针及core compile报Flow-0189，不重复运行。历史 `verification/pds_g1_full.tcl` 仍禁用：纯核禁IO插入报DRC-0001，启用后898 IO>器件300 IO报DRC-0018。须接入真实corr_top执行dev_map/P&R，并跑I0–I7、UART→param_mgr→core全真件验证。

G3内部map相对G2增加1拍，顶层按有效事务适配。DRM≤12、强畸变稳态≤2拍/像素尚未达成；恒等仿真不能推定全参数30fps。源槽rel不等于写回commit。本轮不修改参考模块，也未重跑参考param_mgr/gamma或实板测试。
