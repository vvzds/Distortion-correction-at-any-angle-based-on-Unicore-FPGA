"""Read-only PAP_GROUP evidence extraction; never synthesizes or edits constraints."""
from pathlib import Path
import argparse,bisect,hashlib,json,re

GROUP='g6_map_locality'
PREFIX='u_corr_top/u_core/u_map/'
TOKEN=re.compile(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+')
START=re.compile(r'\(INSTANCE\s+(\\?u_corr_top/u_core/u_map/N(?:78|82)_[am]\w*/[^\s()]+)\s')

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()

def parse_expression(text):
    """Small complete expression parser for an individual native INSTANCE block."""
    stack=[];root=None
    for m in TOKEN.finditer(text):
        t=m.group()
        if t=='(':
            item=[]
            if stack:stack[-1].append(item)
            elif root is not None:raise ValueError('Multiple expressions')
            else:root=item
            stack.append(item)
            if len(stack)>100:raise ValueError('Excessive nesting')
        elif t==')':
            if not stack:raise ValueError('Unmatched close')
            stack.pop()
        else:
            if not stack:raise ValueError('Token outside expression')
            stack[-1].append(t)
    if stack or root is None:raise ValueError('Truncated expression')
    return root

def extract_native(text):
    records=[];seen=set();previous=0;line=1
    for m in START.finditer(text):
        depth=0;end=None
        for token in TOKEN.finditer(text,m.start()):
            t=token.group()
            if t=='(':depth+=1
            elif t==')':
                depth-=1
                if depth==0:end=token.end();break
        if end is None:raise ValueError('Truncated target instance: '+m[1])
        expr=parse_expression(text[m.start():end]);name=expr[1].lstrip('\\')
        if name in seen:raise ValueError('Duplicate target instance: '+name)
        seen.add(name)
        groups=[n for n in expr[2:] if isinstance(n,list) and len(n)>=2 and n[:2]==['ATTRIBUTE','PAP_GROUP']]
        values=[]
        for node in groups:
            if len(node)!=3 or not isinstance(node[2],list) or len(node[2])!=2 or node[2][0]!='STRING':
                raise ValueError('Malformed PAP_GROUP: '+name)
            values.append(node[2][1])
        line+=text.count('\n',previous,m.start());previous=m.start()
        records.append({'instance':name,'parent':name.rsplit('/',1)[0],'line':line,
                        'values':values,'bound':values==['"'+GROUP+'"'],
                        'native_block':text[m.start():end]})
    if not records:raise ValueError('No target instances')
    return records

def vm_inventory(text):
    modules=list(re.finditer(r'(?m)^module\s+undistort_map\b[\s\S]*?^endmodule\b',text))
    if len(modules)!=1:raise ValueError('Expected exactly one undistort_map module')
    text=modules[0].group()
    names=set()
    for m in re.finditer(r'\bGTP_\w+\s*/\*\s*\\?(N(?:78|82)_[am]\w*)\s*\*/',text):
        if m[1] in names:raise ValueError('Duplicate VM instance '+m[1])
        names.add(m[1])
    if not all(any(n.startswith(t+'_') for n in names) for t in ['N78','N82']):raise ValueError('Missing VM tree')
    return names

def compare(records,expected):
    parents=[r['parent'].removeprefix(PREFIX) for r in records]
    actual=set(parents)
    return {'confirmed':bool(records) and actual==expected and len(actual)==len(parents) and all(r['bound'] for r in records),
            'missing':sorted(expected-actual),'unexpected':sorted(actual-expected),
            'multiple_leaves_per_parent':len(actual)!=len(parents),
            'unbound':[r['instance'] for r in records if not r['bound']],
            'counts':{t:sum(p.startswith(t+'_') for p in parents) for t in ['N78','N82']}}

def audit_seed(seed,run,export,out):
    root=run/f'seed_{seed}';receipt=json.loads((root/'process_receipt.json').read_text(encoding='utf-8'))
    expected=json.loads((root/'trial_inputs_sha256.json').read_text())
    if receipt['seed']!=seed or receipt['placement_seed']!=seed or receipt['route_seed']!=seed or receipt['exit_code']!=0 or receipt['error'] is not None:raise ValueError('Invalid original receipt')
    if not receipt['inputs_unchanged'] or not expected==receipt['inputs_before']==receipt['inputs_after']:raise ValueError('Input receipt drift')
    for name,h in expected.items():
        if sha(root/name).lower()!=h.lower():raise ValueError('Input hash mismatch '+name)
    for name,h in receipt['artifacts_sha256'].items():
        if sha(root/name).lower()!=h.lower():raise ValueError('Artifact hash mismatch '+name)
    original_paths={'mapped':root/'device_map/hdmi_ddr_ov5640_top_map.adf','routed':root/'place_route/hdmi_ddr_ov5640_top_pnr.adf'}
    er=json.loads((export/'export_receipt.json').read_text(encoding='utf-8'))
    if er['seed']!=seed or er['exit_code']!=0:raise ValueError('Native export failed')
    for label,p in original_paths.items():
        if sha(p)!=er['source_sha256'][str(p)] or sha(export/(label+'.adf'))!=sha(p):raise ValueError('Database copy drift')
    for name,h in er['files_sha256'].items():
        if sha(export/name)!=h:raise ValueError('Export changed '+name)
    console=(export/'console.log').read_text(encoding='utf-8',errors='replace')
    if 'BINDING_EXPORT_FINISHED' not in console or re.search(r'(?mi)^\s*(?:E:|ERROR:|\*\* (?:Error|Fatal):)',console):raise ValueError('Native export console incomplete/error')
    vm=root/'synthesize/hdmi_ddr_ov5640_top_syn.vm'
    inventory=vm_inventory(vm.read_text(encoding='utf-8'))
    out.mkdir(parents=True)
    stages={};recordsets={}
    for label in ['mapped','routed']:
        records=extract_native((export/(label+'.txt')).read_text(encoding='utf-8'))
        stages[label]=compare(records,inventory);recordsets[label]=records
        (out/(label+'_leaf_blocks.txt')).write_text('\n\n'.join(f'# native line {r["line"]}\n'+r['native_block'] for r in records),encoding='utf-8')
        # This is explicitly derived audit data, NOT a vendor FDC export or new input.
        (out/(label+'_leaf_records.json')).write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    binding=(root/'binding_groups.fdc').read_text(encoding='utf-8')
    placed=set(re.findall(r'def_inst_site\s+\{(u_corr_top/u_core/u_map/N(?:78|82)_[am]\w*/[^}]+)\}',binding))
    routed_names={r['instance'] for r in recordsets['routed']}
    if not placed or not placed<=routed_names:raise ValueError('Historical placed leaf names do not match native routed export')
    result={'seed':seed,'mapped':stages['mapped'],'routed':stages['routed'],'binding_observed':all(s['confirmed'] for s in stages.values()),
            'historically_anchored_placed_leaf_matches':len(placed),'source_vm_sha256':sha(vm),
            'new_database_sha256':{k:sha(p) for k,p in original_paths.items()},
            'historical_ADF_hashes_available':all(p.relative_to(root).as_posix() in receipt['artifacts_sha256'] for p in original_paths.values()),
            'scope':'Observed native mapped/routed leaf properties; no timing acceptance or automatic gate change'}
    (out/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,default=Path('D:/g6_locality_runs_20261022'));p.add_argument('--workspace',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    if a.out.exists():raise SystemExit('Output exists; preserve historical audit')
    rows=[]
    for seed in [2,3,5,7,8,9,10,11]:
        export=a.workspace/f'native_direct_seed_{seed}'
        if not (export/'export_receipt.json').is_file():export=a.workspace/f'native_seed_{seed}'
        rows.append(audit_seed(seed,a.run,export,a.out/f'seed_{seed}'))
        print(json.dumps(rows[-1],ensure_ascii=False),flush=True)
    (a.out/'summary.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
