"""Use the vendor's observed -shell_cmd entry to avoid duplicate Tcl preparse conversions."""
from pathlib import Path
import concurrent.futures,subprocess,time,json,shutil
from binding_audit import sha
W=Path(__file__).resolve().parent;RUN=Path('D:/g6_locality_runs_20261022');TOOL=Path('D:/pango/PDS_2022.2-SP6.4/bin/pds_shell.exe')
def export(seed):
    out=W/f'native_direct_seed_{seed}';out.mkdir();src=RUN/f'seed_{seed}'
    sources={'mapped':src/'device_map/hdmi_ddr_ov5640_top_map.adf','routed':src/'place_route/hdmi_ddr_ov5640_top_pnr.adf'}
    anchors={str(p):sha(p) for p in sources.values()};commands=[];t=time.time()
    for label,p in sources.items():
        shutil.copy2(p,out/(label+'.adf'))
        if sha(out/(label+'.adf'))!=anchors[str(p)]:raise RuntimeError('Copy mismatch')
    with (out/'console.log').open('wb') as log:
        log.write(b'BINDING_AUDIT_WRAPPER: stage markers below are wrapper messages; vendor output is retained between them.\n')
        for label in sources:
            args=[str(TOOL),'-shell_cmd','.switch_db','-input',str(out/(label+'.adf')),'-output',str(out/(label+'.txt'))]
            commands.append(args);log.write(f'BINDING_EXPORT_START={label}\n'.encode());log.flush()
            p=subprocess.run(args,cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=600)
            if p.returncode:raise RuntimeError('Native command failed')
            log.write(f'BINDING_EXPORT_DONE={label}\n'.encode());log.flush()
        log.write(b'BINDING_EXPORT_FINISHED\n')
    (out/'commands.json').write_text(json.dumps(commands,indent=2),encoding='utf-8')
    (out/'export.tcl').write_text('# Equivalent Tcl replay; actual commands are in commands.json\n'+''.join(f'.switch_db -input {{{(out/(s+".adf")).as_posix()}}} -output {{{(out/(s+".txt")).as_posix()}}}\n' for s in sources),encoding='utf-8')
    for path,h in anchors.items():
        if sha(Path(path))!=h:raise RuntimeError('Source drift')
    rec={'seed':seed,'exit_code':0,'seconds':time.time()-t,'source_sha256':anchors,'tool_sha256':sha(TOOL),
         'invocation':'direct -shell_cmd, actual argument arrays in commands.json','files_sha256':{p.name:sha(p) for p in out.iterdir() if p.is_file()}}
    (out/'export_receipt.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
    print(f'Direct native export seed {seed} complete in {rec["seconds"]:.1f}s',flush=True)
    return rec
if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(export,[9,10,11]))
    (W/'direct_batch_receipt.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
