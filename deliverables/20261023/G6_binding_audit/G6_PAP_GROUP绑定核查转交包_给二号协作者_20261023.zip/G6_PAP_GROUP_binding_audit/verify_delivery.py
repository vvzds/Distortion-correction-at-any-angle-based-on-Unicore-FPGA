from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
manifest=json.loads((R/'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
for name,h in manifest.items():
    p=(R/name).resolve()
    if not p.is_relative_to(R) or not p.is_file():raise ValueError('Missing/unsafe path '+name)
    digest=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''):digest.update(chunk)
    if digest.hexdigest()!=h:raise ValueError('Hash mismatch '+name)
print(f'PASS: {len(manifest)} manifest-listed files verified')
