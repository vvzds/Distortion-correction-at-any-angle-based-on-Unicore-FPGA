import unittest
from binding_audit import extract_native,compare,vm_inventory,parse_expression

def leaf(tree='N78',value='g6_map_locality',extra='',suffix='gateop'):
    return f'(INSTANCE \\u_corr_top/u_core/u_map/{tree}_a1_1/{suffix} (VIEWREF OPER) (ATTRIBUTE PAP_GROUP (STRING "{value}")) {extra})'

class TestBinding(unittest.TestCase):
    def test_both_trees_required(self):
        self.assertTrue(compare(extract_native(leaf()+leaf('N82')),{'N78_a1_1','N82_a1_1'})['confirmed'])
    def test_one_tree_missing(self):
        self.assertFalse(compare(extract_native(leaf()),{'N78_a1_1','N82_a1_1'})['confirmed'])
    def test_wrong_group(self):
        self.assertFalse(compare(extract_native(leaf(value='other')),{'N78_a1_1'})['confirmed'])
    def test_missing_attribute(self):
        self.assertFalse(extract_native(leaf().replace('(ATTRIBUTE PAP_GROUP (STRING "g6_map_locality"))',''))[0]['bound'])
    def test_neighbor_attribute_not_inherited(self):
        s=leaf().replace('(ATTRIBUTE PAP_GROUP (STRING "g6_map_locality"))','')+leaf('N82')
        self.assertFalse(extract_native(s)[0]['bound'])
    def test_nested_child_attribute_not_accepted(self):
        s=leaf().replace('(ATTRIBUTE PAP_GROUP (STRING "g6_map_locality"))','(CHILD (ATTRIBUTE PAP_GROUP (STRING "g6_map_locality")))')
        self.assertFalse(extract_native(s)[0]['bound'])
    def test_duplicate_attribute_rejected(self):
        self.assertFalse(extract_native(leaf(extra='(ATTRIBUTE PAP_GROUP (STRING "g6_map_locality"))'))[0]['bound'])
    def test_conflicting_attribute_rejected(self):
        self.assertFalse(extract_native(leaf(extra='(ATTRIBUTE PAP_GROUP (STRING "other"))'))[0]['bound'])
    def test_duplicate_instance_rejected(self):
        with self.assertRaises(ValueError):extract_native(leaf()+leaf())
    def test_truncated_instance_rejected(self):
        with self.assertRaises(ValueError):extract_native(leaf()[:-1])
    def test_malformed_attribute_rejected(self):
        with self.assertRaises(ValueError):extract_native(leaf().replace('(STRING "g6_map_locality")','wrong'))
    def test_empty_records_rejected(self):
        with self.assertRaises(ValueError):extract_native('(OTHER PAP_GROUP)')
    def test_unexpected_leaf_rejected(self):
        self.assertFalse(compare(extract_native(leaf()+leaf('N82')),{'N78_a1_1'})['confirmed'])
    def test_multiple_leaf_mapping_not_silently_accepted(self):
        self.assertFalse(compare(extract_native(leaf()+leaf(suffix='gateop_perm')),{'N78_a1_1'})['confirmed'])
    def test_parentheses_in_quoted_string(self):
        self.assertTrue(extract_native(leaf(extra='(NOTE "a (b) c")'))[0]['bound'])
    def test_vm_module_scope(self):
        text='module other\nGTP_APM /* N78_m1 */\nendmodule\nmodule undistort_map\nGTP_APM /* N78_a1_1 */\nGTP_APM /* N82_a1_1 */\nendmodule'
        self.assertEqual(vm_inventory(text),{'N78_a1_1','N82_a1_1'})
    def test_missing_vm_module(self):
        with self.assertRaises(ValueError):vm_inventory('GTP_APM /* N78_m1 */')
    def test_vm_missing_tree(self):
        with self.assertRaises(ValueError):vm_inventory('module undistort_map\nGTP_APM /* N78_m1 */\nendmodule')
    def test_duplicate_vm_instance(self):
        with self.assertRaises(ValueError):vm_inventory('module undistort_map\nGTP_APM /* N78_m1 */\nGTP_APM /* N78_m1 */\nGTP_APM /* N82_m1 */\nendmodule')
    def test_line_provenance(self):
        self.assertEqual([r['line'] for r in extract_native('\n'+leaf()+'\n\n'+leaf('N82'))],[2,4])
    def test_multiple_expressions_rejected(self):
        with self.assertRaises(ValueError):parse_expression('(a)(b)')

if __name__=='__main__':unittest.main(verbosity=2)
