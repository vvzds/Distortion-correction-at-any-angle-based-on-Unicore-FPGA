"""Convert copies of existing databases with the installed vendor tool; no PNR."""
from pathlib import Path
import hashlib,json,shutil,subprocess,time,concurrent.futures
W=Path(__file__).resolve().parent;RUN=Path('D:/g6_locality_runs_20261022')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def export(seed):
    src=RUN/f'seed_{seed}';out=W/f'native_seed_{seed}';out.mkdir()
    sources={'mapped':src/'device_map/hdmi_ddr_ov5640_top_map.adf','routed':src/'place_route/hdmi_ddr_ov5640_top_pnr.adf'}
    anchors={str(p):sha(p) for p in sources.values()}
    for label,p in sources.items():
        shutil.copy2(p,out/(label+'.adf'))
        if sha(out/(label+'.adf'))!=anchors[str(p)]:raise RuntimeError('Copy mismatch')
    script='set_arch -family Logos2 -device PG2L100H -speedgrade -6 -package FBG676\n'
    for label in sources:
        script+=f'puts "BINDING_EXPORT_START={label}"\n.switch_db -input {{{(out/(label+".adf")).as_posix()}}} -output {{{(out/(label+".txt")).as_posix()}}}\nputs "BINDING_EXPORT_DONE={label}"\n'
    script+='puts "BINDING_EXPORT_FINISHED"\n'
    (out/'export.tcl').write_text(script,encoding='utf-8')
    started=time.time()
    with (out/'console.log').open('wb') as log:
        p=subprocess.Popen(['D:/pango/PDS_2022.2-SP6.4/bin/pds_shell.exe','-file',str(out/'export.tcl')],cwd=out,stdout=log,stderr=subprocess.STDOUT)
        try:code=p.wait(timeout=900)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True)
            raise
    for path,digest in anchors.items():
        if sha(Path(path))!=digest:raise RuntimeError('Original changed')
    if code!=0 or 'BINDING_EXPORT_FINISHED' not in (out/'console.log').read_text(errors='replace'):
        raise RuntimeError(f'Export failed seed {seed}: exit {code}')
    rec={'seed':seed,'exit_code':code,'seconds':time.time()-started,'source_sha256':anchors,
         'tool_sha256':sha(Path('D:/pango/PDS_2022.2-SP6.4/bin/pds_shell.exe')),
         'files_sha256':{p.name:sha(p) for p in out.iterdir() if p.is_file()}}
    (out/'export_receipt.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
    print(f'Exported seed {seed}, {rec["seconds"]:.1f}s; source hashes unchanged',flush=True)
    return rec
if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--seeds',type=int,nargs='+',default=[2,3,5,7,8,9,10,11]);parser.add_argument('--workers',type=int,default=2);args=parser.parse_args()
    if len(set(args.seeds))!=len(args.seeds) or args.workers<1:raise SystemExit('Invalid seeds/workers')
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures={pool.submit(export,s):s for s in args.seeds}
        rows=[]
        for f in concurrent.futures.as_completed(futures):rows.append(f.result())
    (W/'native_batch_receipt.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
