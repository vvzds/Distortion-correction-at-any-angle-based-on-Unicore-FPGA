"""Offline independent review of the full text exports included in delivery."""
from pathlib import Path
import hashlib,json
from binding_audit import extract_native,vm_inventory,compare
ROOT=Path(__file__).resolve().parent
def run():
    results=[]
    for seed in [2,3,5,7,8,9,10,11]:
        p=ROOT/'native_evidence'/f'seed_{seed}'
        receipt=json.loads((p/'original_process_receipt.json').read_text(encoding='utf-8'))
        vm=p/'hdmi_ddr_ov5640_top_syn.vm'
        expected=receipt['artifacts_sha256']['synthesize/hdmi_ddr_ov5640_top_syn.vm'].lower()
        if hashlib.sha256(vm.read_bytes()).hexdigest()!=expected:raise ValueError('Original VM hash mismatch')
        inventory=vm_inventory(vm.read_text(encoding='utf-8'))
        row={'seed':seed}
        er=json.loads((p/'export_receipt.json').read_text(encoding='utf-8'))
        for stage in ['mapped','routed']:
            f=p/(stage+'.txt')
            if hashlib.sha256(f.read_bytes()).hexdigest()!=er['files_sha256'][f.name]:raise ValueError('Native export hash mismatch')
            row[stage]=compare(extract_native(f.read_text(encoding='utf-8')),inventory)
            if not row[stage]['confirmed']:raise ValueError('Binding check failed '+str(row))
        results.append(row)
    print(json.dumps({'result':'PASS: exported leaf properties match both tree inventories for all 8 seeds',
                      'limitation':'Current exported evidence only; historical ADF hash gap and timing acceptance remain separate',
                      'seeds':results},ensure_ascii=False,indent=2))
if __name__=='__main__':run()
