set_arch -family Logos2 -device PG2L100H -speedgrade -6 -package FBG676
puts "BINDING_EXPORT_START=mapped"
.switch_db -input {D:/FPGA_management/work/G6_binding_audit_20261023/native_seed_8/mapped.adf} -output {D:/FPGA_management/work/G6_binding_audit_20261023/native_seed_8/mapped.txt}
puts "BINDING_EXPORT_DONE=mapped"
puts "BINDING_EXPORT_START=routed"
.switch_db -input {D:/FPGA_management/work/G6_binding_audit_20261023/native_seed_8/routed.adf} -output {D:/FPGA_management/work/G6_binding_audit_20261023/native_seed_8/routed.txt}
puts "BINDING_EXPORT_DONE=routed"
puts "BINDING_EXPORT_FINISHED"
