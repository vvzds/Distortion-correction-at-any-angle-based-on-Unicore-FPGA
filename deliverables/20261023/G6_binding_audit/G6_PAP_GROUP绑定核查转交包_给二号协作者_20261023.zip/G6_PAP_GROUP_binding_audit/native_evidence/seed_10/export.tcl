# Equivalent Tcl replay; actual commands are in commands.json
.switch_db -input {D:/FPGA_management/work/G6_binding_audit_20261023/native_direct_seed_10/mapped.adf} -output {D:/FPGA_management/work/G6_binding_audit_20261023/native_direct_seed_10/mapped.txt}
.switch_db -input {D:/FPGA_management/work/G6_binding_audit_20261023/native_direct_seed_10/routed.adf} -output {D:/FPGA_management/work/G6_binding_audit_20261023/native_direct_seed_10/routed.txt}
