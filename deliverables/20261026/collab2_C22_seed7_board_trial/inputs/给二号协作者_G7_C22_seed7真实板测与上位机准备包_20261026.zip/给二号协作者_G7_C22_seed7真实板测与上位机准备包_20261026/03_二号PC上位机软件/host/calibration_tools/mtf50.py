# -*- coding: utf-8 -*-
"""
mtf50.py —— MTF50 测量（斜棱/斜刃法，赛题 SFR 判据工具）
================================================================
图卡 : 黑白刀刃斜边卡，刃倾角 5~15 度（打印或采购 SFR 卡）
用法 : python mtf50.py IMG.png --roi x y w h
       ROI 框住刃及其两侧渐变带（各留 >=40px），ROI 不可含其他边缘
输出 : MTF 曲线数据 mtf_curve.csv + MTF50（cy/px，cycles/pixel）
       同卡同 ROI 矫正前后各测一次，MTF50 越高清晰度越好

E7 修订（2026-10-19，响应二号 Host_review 复核 R06 阻塞项）：
  1. Sobel 输出改 CV_64F，与 float64 输入一致（原 CV_32F 组合在
     OpenCV 4.10 实测报 "Unsupported combination of buffer format
     (=6), and destination format (=5)"，完整 CLI 因此不可运行）；
  2. 平坦/无效 ROI 防御：imread 返回值、ROI 越界/面积、梯度候选点
     数、投影跨度、ESF/LSF 有效性、MTF 零频值逐级校验；
  3. 无效测量统一出口 fail()：打印原因并返回可识别退出码，不输出
     NaN 或任意 MTF50 数值。

E8 修订（2026-10-19，响应二号 E7 修订复核 R06 新增遗漏）：
  4. 最终候选集复核：非零梯度 >= 50 不等价于筛选后候选 >= 50——
     均匀渐变图梯度恒定非零，90 分位恰等于该恒定值，严格大于选出
     空集，空矩阵 SVD 后 V[0] 越界（IndexError exit1，未走统一
     fail 出口）。现于 X.mean/SVD 之前复核候选数，渐变图经既有
     "无有效梯度"路径统一 exit3；
  5. SVD/返回值防御：候选坐标有限性、LinAlgError 捕获、V 维度
     校验，退化一律 return None 回统一 fail() 出口，不输出伪 MTF50。
退出码 : 0 正常 / 2 图像读取失败 / 3 ROI 无效 / 4 ESF-LSF-零频无效
         / 5 MTF50 未找到（此时 mtf_curve.csv 仍写出供诊断）
"""
import cv2
import argparse
import numpy as np
import sys

EXIT_IMG_READ = 2      # 图像读取失败
EXIT_ROI_INVALID = 3   # ROI 无效（越界/面积不足/全平坦/梯度候选不足）
EXIT_ESF_INVALID = 4    # ESF/LSF/零频无效
EXIT_M50_NOT_FOUND = 5  # MTF50 未找到
MIN_ROI_AREA = 4096     # 64x64：刃+两侧渐变带的最低分析面积
MIN_GRAD_PTS = 50       # 梯度主方向估计的最低候选点数
MIN_ESF_PTS = 16        # oversample 后 ESF 的最低点数


def fail(code, reason):
    """E7：无效测量统一出口——打印原因并按可识别状态码退出，不输出任何 MTF50 数值。"""
    print('无有效测量: %s' % reason)
    sys.exit(code)


def edge_angle(g):
    """刃主方向角：图像梯度协方差矩阵主特征向量（刃方向）"""
    # E7：CV_32F -> CV_64F，与 float64 输入一致，避免 OpenCV 4.10+ 报组合不支持
    gx = cv2.Sobel(g, cv2.CV_64F, 1, 0, ksize=3)
    gy = cv2.Sobel(g, cv2.CV_64F, 0, 1, ksize=3)
    mag = np.hypot(gx, gy)
    if not np.isfinite(mag).all():
        return None                                   # E7：图像含 NaN/Inf
    # E7：以非零梯度点数判定平坦（锐刃梯度集中在窄带、分位值可为 0，
    # 不能用分位值是否为 0 判平坦，否则会把锐利刃误判为无效）
    if int((mag > 0).sum()) < MIN_GRAD_PTS:
        return None                                   # E7：全平坦/近全平坦 ROI，SFR 不适用
    thr = np.percentile(mag, 90)
    m = mag > thr if thr > 0 else mag > 0
    # E8：最终候选集复核——非零梯度 >= 50 不等价于筛选后候选 >= 50
    # （均匀渐变图梯度恒定非零，严格大于 90 分位选出空集），必须在
    # X.mean/SVD 之前拦截，否则空矩阵 SVD 后 V[0] 越界（R06 新增遗漏）
    if int(m.sum()) < MIN_GRAD_PTS:
        return None                                   # E8：候选集为空/不足（含恒定梯度渐变图），SFR 不适用
    X = np.stack([gx[m], gy[m]], 1)
    Xc = X - X.mean(0)
    if not np.isfinite(Xc).all():
        return None                                   # E8：候选点坐标含非有限值
    try:
        _, _, V = np.linalg.svd(Xc, full_matrices=False)
    except np.linalg.LinAlgError:
        return None                                   # E8：SVD 不收敛
    if V.ndim != 2 or V.shape[0] < 1:
        return None                                   # E8：V 维度退化，无主方向可取
    return V[0]                                # 梯度主方向 = 刃法向


def main():
    ap = argparse.ArgumentParser(description='斜棱法 MTF50')
    ap.add_argument('img')
    ap.add_argument('--roi', nargs=4, type=int, required=True,
                    metavar=('x', 'y', 'w', 'h'))
    a = ap.parse_args()

    x, y, w, h = a.roi
    img = cv2.imread(a.img)
    # E7：imread 失败返回 None（文件不存在，或路径含中文等非 ASCII 字符时
    # 部分 OpenCV 构建不可读）——明确报错而非后续环节崩溃
    if img is None:
        fail(EXIT_IMG_READ, '图像读取失败: %s（建议确认路径存在，图像目录用英文路径）' % a.img)
    if w <= 0 or h <= 0 or x < 0 or y < 0 \
            or y + h > img.shape[0] or x + w > img.shape[1]:
        fail(EXIT_ROI_INVALID, 'ROI 越界或非法: x=%d y=%d w=%d h=%d，图像 %dx%d'
             % (x, y, w, h, img.shape[1], img.shape[0]))
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)[y:y+h, x:x+w].astype(np.float64)
    if g.size < MIN_ROI_AREA:
        fail(EXIT_ROI_INVALID, 'ROI 面积不足: %dpx < %dpx（ROI 须框住刃及两侧渐变带各>=40px）'
             % (g.size, MIN_ROI_AREA))
    nrm = edge_angle(g)                            # 刃法向单位向量
    if nrm is None:
        fail(EXIT_ROI_INVALID, 'ROI 无有效梯度（全平坦或梯度候选点不足），SFR 分析不适用')
    # ---- 沿法向投影：每个像素 -> (投影位置, 灰度) ----
    ys, xs = np.mgrid[0:g.shape[0], 0:g.shape[1]]
    pos = (xs * nrm[0] + ys * nrm[1]).ravel()
    val = g.ravel()
    o = np.argsort(pos)
    pos, val = pos[o], val[o]
    # E7：排序后首尾即投影跨度，退化说明刃方向/位置异常（SFR 不适用）
    if pos[-1] - pos[0] < 8.0:
        fail(EXIT_ROI_INVALID, '法向投影跨度退化（%0.2fpx），刃方向/位置异常'
             % (pos[-1] - pos[0]))
    # ---- oversample: 1/8 像素 bin 聚合 -> ESF ----
    # R06 修订：原式 val[i-1:i+1] 用 grid 序号 i 而非排序索引 idx[i]，
    # 大部分样本取错位置。改为标准线性插值：grid[i] 落在
    # pos[idx[i]-1] < grid[i] <= pos[idx[i]]，两端正确加权；pos 重合
    # （空 bin）时退化为取左端点值。
    grid = np.arange(pos[0], pos[-1], 0.125)
    idx = np.clip(np.searchsorted(pos, grid), 1, len(pos) - 1)
    pl, pr = pos[idx - 1], pos[idx]
    span = pr - pl
    with np.errstate(divide='ignore', invalid='ignore'):
        wgt = np.where(span > 0, (grid - pl) / np.where(span > 0, span, 1.0), 0.0)
    wgt = np.clip(wgt, 0.0, 1.0)
    esf = val[idx - 1] * (1.0 - wgt) + val[idx] * wgt
    esf = cv2.GaussianBlur(esf.reshape(-1, 1), (1, 5), 0).ravel()   # 轻度去噪
    # ---- E7：ESF 有效性 ----
    if esf.size < MIN_ESF_PTS or not np.isfinite(esf).all():
        fail(EXIT_ESF_INVALID, 'ESF 退化（点数 %d 或含非有限值）' % esf.size)
    # ---- 差分 -> LSF（汉宁窗抑制边界效应）----
    lsf = np.diff(esf)
    win = np.hanning(len(lsf))
    lsf = lsf * win
    # ---- FFT -> MTF，归一化（0 频=1）----
    mtf = np.abs(np.fft.rfft(lsf))
    # E7：零频值校验——LSF 全 0/能量退化时不得除零产生 NaN
    if mtf[0] <= 0 or not np.isfinite(mtf).all():
        fail(EXIT_ESF_INVALID, 'LSF 零频分量无效（ESF/LSF 退化），无法归一化')
    mtf = mtf / mtf[0]
    # 频轴: 采样间隔 0.125px -> 频率分辨率 1/(0.125*N)
    freq = np.fft.rfftfreq(len(lsf), d=0.125)      # cy/px
    # ---- MTF50 插值 ----
    m50 = None
    for i in range(1, len(mtf)):
        if mtf[i-1] >= 0.5 > mtf[i]:
            t = (mtf[i-1] - 0.5) / (mtf[i-1] - mtf[i])
            m50 = freq[i-1] + t * (freq[i] - freq[i-1])
            break
    np.savetxt('mtf_curve.csv', np.stack([freq, mtf], 1), delimiter=',',
               header='freq_cy_per_px,mtf', comments='')
    if m50 is None:
        # E7：曲线仍写出供诊断，但以退出码 5 明确"未找到"，不伪称测量成功
        fail(EXIT_M50_NOT_FOUND, 'MTF50 未找到（刃太软/ROI 不当）；mtf_curve.csv 已写出供诊断')
    print(f'MTF50 = {m50:.4f} cy/px')
    print('曲线已存 mtf_curve.csv（同图卡同 ROI 矫正前后对比）')


if __name__ == '__main__':
    main()
