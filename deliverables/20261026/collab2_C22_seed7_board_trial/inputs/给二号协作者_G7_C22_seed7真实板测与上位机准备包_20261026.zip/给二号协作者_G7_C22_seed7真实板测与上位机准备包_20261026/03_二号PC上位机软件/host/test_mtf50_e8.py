# -*- coding: utf-8 -*-
# E8 自测：完整 CLI 路径验证（合成斜边 + 无效输入拒绝 + 均匀渐变图拒绝）。
# 运行：python test_mtf50_e8.py   （退出 0 = 全部通过）
# 环境：Python3 + numpy + opencv（本机实测 cv2 5.0.0 / numpy 2.5.4，
#       二号环境 cv2 4.10.0 / numpy 2.3.5 亦应通过——脚本只用稳定接口）
# E8 修订（2026-10-19，在 E7 自测基础上）：
#   1. 新增 T8：水平/垂直均匀灰度渐变图（恒定梯度，严格大于 90 分位
#      选出空集）必须 exit3 拒绝且不输出 MTF50——R06 新增遗漏回归；
#   2. 自测计数修正：按 check() 实际调用数累计统计，输出与断言数
#      一致（E7 版 11 个 check() 硬编码 12，已废弃）。
import cv2
import numpy as np
import subprocess
import sys
import os
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
TOOL = os.path.join(HERE, 'calibration_tools', 'mtf50.py')
FAILED = []
TOTAL = [0]                                             # E8：check() 实际调用计数


def synth_edge(path, shape=(512, 512), theta_deg=10.0, sigma=1.0, invert=False):
    """合成斜刃图：刃过中心，倾角 theta，高斯模糊 sigma 模拟镜头。"""
    h, w = shape
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float64)
    t = np.deg2rad(theta_deg)
    d = (xx - w / 2) * np.cos(t) + (yy - h / 2) * np.sin(t)
    g = np.where(d > 0, 255.0, 0.0)
    if sigma > 0:
        g = cv2.GaussianBlur(g, (0, 0), sigma)
    if invert:
        g = 255.0 - g
    img = np.clip(g, 0, 255).astype(np.uint8)
    ok, buf = cv2.imencode('.png', img)
    assert ok
    with open(path, 'wb') as f:
        f.write(buf.tobytes())


def run_cli(img, roi, cwd):
    p = subprocess.run([sys.executable, '-B', TOOL, img, '--roi'] + [str(v) for v in roi],
                       capture_output=True, text=True, cwd=cwd)
    return p.returncode, (p.stdout or '') + (p.stderr or '')


def parse_m50(out):
    for ln in out.splitlines():
        if ln.startswith('MTF50 = '):
            return float(ln.split('=')[1].split()[0])
    return None


def check(name, cond, detail=''):
    tag = 'PASS' if cond else 'FAIL'
    TOTAL[0] += 1                                       # E8：每次调用累计
    print('%s %s %s' % (tag, name, detail))
    if not cond:
        FAILED.append(name)


def main():
    tmp = tempfile.mkdtemp(prefix='mtf_e8_')
    imgs = {}
    for tag, kw in [('s1', dict(sigma=1.0)), ('s3', dict(sigma=3.0)),
                    ('inv', dict(sigma=1.0, invert=True)), ('flat', dict())]:
        imgs[tag] = os.path.join(tmp, 'edge_%s.png' % tag)
        if tag == 'flat':
            cv2.imencode('.png', np.full((512, 512), 128, np.uint8))[1].tofile(imgs[tag])
        else:
            synth_edge(imgs[tag], **kw)

    rc1, out1 = run_cli(imgs['s1'], (156, 156, 200, 200), tmp)
    m1 = parse_m50(out1)
    check('T1 sigma1 exit=0', rc1 == 0, 'rc=%d out=%r' % (rc1, out1.strip()[:80]))
    check('T1 sigma1 MTF50>0', m1 is not None and m1 > 0.02, 'm50=%s' % m1)

    rc3, out3 = run_cli(imgs['s3'], (156, 156, 200, 200), tmp)
    m3 = parse_m50(out3)
    check('T2 sigma3 exit=0', rc3 == 0, 'rc=%d' % rc3)
    check('T2 模糊增大读数下降', m3 is not None and m1 is not None and m3 < m1,
          'm50_s1=%s m50_s3=%s' % (m1, m3))

    rci, outi = run_cli(imgs['inv'], (156, 156, 200, 200), tmp)
    mi = parse_m50(outi)
    check('T3 反极性 exit=0', rci == 0, 'rc=%d' % rci)
    check('T3 双极性读数接近', mi is not None and m1 is not None and
          abs(mi - m1) / m1 < 0.15, 'm50_pos=%s m50_neg=%s' % (m1, mi))

    rc4, out4 = run_cli(imgs['flat'], (100, 100, 200, 200), tmp)
    check('T4 平坦ROI 拒绝(exit=3)', rc4 == 3, 'rc=%d out=%r' % (rc4, out4.strip()[:60]))
    check('T4 平坦ROI 不输出MTF50', parse_m50(out4) is None)

    rc5, out5 = run_cli(imgs['s1'], (400, 400, 200, 200), tmp)
    check('T5 ROI越界 拒绝(exit=3)', rc5 == 3, 'rc=%d out=%r' % (rc5, out5.strip()[:60]))

    rc6, out6 = run_cli(os.path.join(tmp, 'no_such.png'), (0, 0, 64, 64), tmp)
    check('T6 图不存在 拒绝(exit=2)', rc6 == 2, 'rc=%d out=%r' % (rc6, out6.strip()[:60]))

    rc7, out7 = run_cli(imgs['s1'], (10, 10, 0, 100), tmp)
    check('T7 非法ROI(w=0) 拒绝(exit=3)', rc7 == 3, 'rc=%d out=%r' % (rc7, out7.strip()[:60]))

    # E8 T8：均匀灰度渐变图——恒定梯度非零、严格大于 90 分位选出空集，
    # 修复前 L58 V[0] IndexError exit1，修复后须统一 exit3 拒绝
    ramp_h = os.path.join(tmp, 'ramp_h.png')
    ramp_v = os.path.join(tmp, 'ramp_v.png')
    cv2.imencode('.png', np.tile(np.arange(256, dtype=np.uint8), (256, 1)))[1].tofile(ramp_h)
    cv2.imencode('.png', np.tile(np.arange(256, dtype=np.uint8)[:, None], (1, 256)))[1].tofile(ramp_v)
    rc8h, out8h = run_cli(ramp_h, (32, 32, 192, 192), tmp)
    check('T8 水平渐变图 拒绝(exit=3)', rc8h == 3, 'rc=%d out=%r' % (rc8h, out8h.strip()[:60]))
    check('T8 水平渐变图 不输出MTF50', parse_m50(out8h) is None)
    rc8v, out8v = run_cli(ramp_v, (32, 32, 192, 192), tmp)
    check('T8 垂直渐变图 拒绝(exit=3)', rc8v == 3, 'rc=%d out=%r' % (rc8v, out8v.strip()[:60]))
    check('T8 垂直渐变图 不输出MTF50', parse_m50(out8v) is None)

    # E8：计数按 check() 实际调用数累计，输出与断言数一致
    n_total = TOTAL[0]
    n_pass = n_total - len(FAILED)
    print('=== E8 selftest: %d/%d PASS ===' % (n_pass, n_total))
    sys.exit(1 if FAILED else 0)


if __name__ == '__main__':
    main()
