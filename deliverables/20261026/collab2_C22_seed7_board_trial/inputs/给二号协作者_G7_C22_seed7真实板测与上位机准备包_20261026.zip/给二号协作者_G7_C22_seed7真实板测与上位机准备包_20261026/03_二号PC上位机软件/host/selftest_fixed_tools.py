# -*- coding: utf-8 -*-
"""
selftest_fixed_tools.py —— 2026-10-18 标定工具修订自检（设计方回传证据）
========================================================================
运行需求：仅 numpy（无 cv2/pyserial 亦可运行全部探针）。
证据分级：
  [数值探针]    直接执行合成数据计算，给出量化结果
  [源码段实跑]  从交付 .py 文件中提取纯函数源码段 exec 后实跑（被测代码=交付原文）
  [源码断言]    对交付源码的文本断言（cv2/pyserial 依赖路径，须二号环境实跑复核）
"""
import json
import re
import sys
import numpy as np

BASE = __file__.rsplit('\\', 1)[0] if '\\' in __file__ else '.'
CAL = f'{BASE}\\calibration_tools\\calibrate.py'
results = []


def report(tag, name, ok, detail):
    results.append(ok)
    print(f'[{tag}] {"PASS" if ok else "FAIL"}  {name}  {detail}')


# ---------- 源码段提取：q16_16 / g02_violations（源码段实跑） ----------
src = open(CAL, encoding='utf-8').read()
seg = re.search(r'def q16_16.*?\n\ndef g02_violations.*?\n    return .*?\n', src, re.S).group(0)
ns = {}
exec(compile(seg, CAL, 'exec'), {'np': np}, ns)
q16_16, g02_violations = ns['q16_16'], ns['g02_violations']
report('源码段实跑', 'T1 从 calibrate.py 提取 q16_16/g02_violations', True,
       f'共 {len(seg)} 字符，与交付文件逐字一致')

# ---------- T2 R03 编码域（数值探针） ----------
def q16_dec(b4):
    u = int.from_bytes(b4, 'little')
    return (u - (1 << 32) if u >= (1 << 31) else u) / 65536.0

ok_p = dict(fx=1000.0, fy=1000.0, cx=960.0, cy=540.0, k1=-0.01, k2=0.005, p1=0.001, p2=-0.002)
rt = max(abs(q16_dec(q16_16(v)) - v) for v in ok_p.values())
report('数值探针', 'T2 R03 合法组 Q16.16 量化往返误差 <= 0.5 LSB', rt <= 0.5 / 65536.0,
       f'max |Δ| = {rt * 65536.0:.6f} LSB')
v_out = g02_violations(dict(fx=65536.0, fy=1000.0, cx=960.0, cy=540.0,
                            k1=0.0, k2=0.0, p1=0.0, p2=0.0))
report('数值探针', 'T2 R03 越界值 65536.0 被 G02 预检拦截（不进编码/发送）',
       len(v_out) == 1 and v_out[0][0] == 'fx',
       f'拦截 {[(x[0], x[1]) for x in v_out]}')
kb = q16_16(-0.5)
report('数值探针', 'T2 R03 边界负值 k1=-0.5 编码不回绕（-32768 -> 0x8000 小端）',
       q16_dec(kb) == -0.5 and kb == b'\x00\x80\xff\xff',
       f'bytes={kb.hex()} 解码={q16_dec(kb)}（Q16.16 有符号小端无回绕）')

# ---------- T3 R05 linearity（数值探针，新旧对照重现二号探针） ----------
# 45° 例：9 个点共线于 y=x 决定 PCA 主轴，1 个点带垂直残差向量
# (2.828, -2.828)：分量 max = 2.828，欧氏垂距 = 4.000
base = np.array([[float(t), float(t)] for t in range(99)])
off = np.array([49.0, 49.0]) + np.array([2.828, -2.828])
pts = np.vstack([base, off])
c = pts.mean(0)
u = np.linalg.svd(pts - c, full_matrices=False)[2][0]
resid = (pts - c) - ((pts - c) @ u)[:, None] * u
new_dev = float(np.linalg.norm(resid, axis=1).max())
old_dev = float(np.abs(resid).max())
# T3a 公式对照（二号探针同型）：固定理想轴下同一残差向量的两公式读数
rv = np.array([2.828, -2.828])
report('数值探针', 'T3a R05 公式对照：二范数（修订版）读数', abs(np.linalg.norm(rv) - 4.000) < 0.005,
       f'欧氏垂距={np.linalg.norm(rv):.3f}px（期望 4.000）')
report('数值探针', 'T3a R05 公式对照：分量 max（旧版）重现二号探针',
       abs(float(np.abs(rv).max()) - 2.828) < 0.005,
       f'旧公式读数={float(np.abs(rv).max()):.3f}px（二号 review_claim_probes.json 同型结论）')
# T3b 端到端（完整 SVD 公式）：45° 残差方向下新旧读数比应为 √2
ratio = new_dev / old_dev
report('数值探针', 'T3b R05 端到端 SVD：新旧公式读数比 = sqrt(2)',
       abs(ratio - np.sqrt(2)) < 0.01,
       f'新={new_dev:.3f}px 旧={old_dev:.3f}px 比值={ratio:.4f}（期望 1.4142，'
       f'PCA 主轴受离轴点轻微扰动属正常，比值判据不受影响）')
s_old = np.diff(np.array([255, 0], np.uint8))
s_new = np.diff(np.array([255, 0], np.float64))
report('数值探针', 'T3 R05 uint8 回绕修复（255->0 差分）', s_new[0] == -255.0,
       f'旧 uint8 差分={int(s_old[0])}（回绕错误 +1），新 float64 差分={s_new[0]:.0f}（正确）')

# ---------- T4 R06 mtf50 ESF 插值（数值探针，新旧对照重现二号探针） ----------
rng = np.random.default_rng(7)
pos = np.sort(rng.uniform(0, 100, 400))
val = np.where(pos < 50, 10.0, 200.0) + rng.normal(0, 1, 400).clip(-5, 5)
grid = np.arange(pos[0], pos[-1], 0.125)
idx = np.clip(np.searchsorted(pos, grid), 1, len(pos) - 1)
# 修订版（与 mtf50.py L47-54 逐行同构）
pl, pr = pos[idx - 1], pos[idx]
span = pr - pl
with np.errstate(divide='ignore', invalid='ignore'):
    wgt = np.where(span > 0, (grid - pl) / np.where(span > 0, span, 1.0), 0.0)
wgt = np.clip(wgt, 0.0, 1.0)
esf_new = val[idx - 1] * (1.0 - wgt) + val[idx] * wgt
# 逐点参考线性插值（独立实现）
esf_ref = np.array([np.interp(g, pos, val) for g in grid])
d_new = float(np.abs(esf_new - esf_ref).max())
report('数值探针', 'T4 R06 修订版 ESF vs 逐点参考插值 max|Δ|', d_new < 1e-9,
       f'max|Δ|={d_new:.3e}（数值一致）')
# 旧表达式重现（val[i-1:i+1].mean()，i 为 grid 序号——二号探针结论）
# 注：i=0 时 val[-1:1] 为空切片产生 nan，是旧式又一缺陷，一并计入证据
with np.errstate(invalid='ignore'):
    esf_old = np.array([val[i - 1:i + 1].mean() if val[i - 1:i + 1].size else np.nan
                        for i in range(len(grid))])
d_old = float(np.nanmax(np.abs(esf_old - esf_ref)))
n_nan = int(np.isnan(esf_old).sum())
report('数值探针', 'T4 R06 旧索引错误重现二号探针（对照证据）', d_old > 100,
       f'旧式 vs 参考 max|Δ|={d_old:.0f} 灰度级；另暴露 i=0 空切片 nan {n_nan} 处（旧式额外缺陷）')

# ---------- T5 R04 status_map 结构（源码断言 + 数值比对） ----------
sm_uart = json.load(open(f'{BASE}\\UART_HOST_TOOL\\status_map_uart.json', encoding='utf-8'))
sm_doc = json.load(open(f'{BASE}\\docs\\status_map.json', encoding='utf-8'))
ok_fields = isinstance(sm_uart.get('fields'), dict)
report('源码断言', 'T5 R04 status_map_uart.json fields 为对象（适配 format_status）',
       ok_fields, f"type={type(sm_uart['fields']).__name__}（docs 版为 "
       f"{type(sm_doc.get('fields')).__name__}，故 docs 版不可直接用于 read-0x05）")
# 位域语义一致性：按 name 对齐，逐项比对 lsb/width（由 doc 的 bits '[msb:lsb]' 或单值 'n' 解析）
# 注：uart 适配版省略 reserved（保留位无解码语义，缺席不影响 read-0x05），
# 判据 = 非保留项逐项一致 + 两版有效位域无冲突。
u_map = {k: (v['lsb'], v['width']) for k, v in sm_uart['fields'].items()}
d_map = {}
for it in sm_doc['fields']:
    parts = [int(x) for x in it['bits'].strip('[]').split(':')]
    if len(parts) == 1:
        d_map[it['name']] = (parts[0], 1)
    else:
        d_map[it['name']] = (parts[1], parts[0] - parts[1] + 1)
d_eff = {k: v for k, v in d_map.items() if k != 'reserved'}
diffs = [k for k in d_eff if u_map.get(k) != d_eff[k]] + \
        [k for k in u_map if k not in d_eff]
report('数值探针', 'T5 R04 两份 status_map 有效字段逐项一致（冻结位域不改）',
       not diffs, f'{len(d_eff)} 项非保留字段 lsb/width 逐项比对全一致；'
       f'reserved（{d_map.get("reserved")}）在 uart 适配版中省略，无解码语义' if not diffs
       else f'差异: {[(k, u_map.get(k), d_eff.get(k)) for k in diffs]}')

# ---------- T6 R01/R02/H08/H09 源码断言（cv2 依赖路径，标注待二号实跑） ----------
cal_src = src
cap_src = open(f'{BASE}\\calibration_tools\\capture.py', encoding='utf-8').read()
lin_src = open(f'{BASE}\\calibration_tools\\linearity.py', encoding='utf-8').read()
mtf_src = open(f'{BASE}\\calibration_tools\\mtf50.py', encoding='utf-8').read()
rdm_src = open(f'{BASE}\\README_HOST_PC.md', encoding='utf-8').read()
report('源码断言', 'T6 R01 calibrate.py 含 CALIB_FIX_K3 + zeros(5) + dist_full 记录',
       'CALIB_FIX_K3' in cal_src and 'np.zeros(5' in cal_src and 'dist_full' in cal_src,
       'flags 显式化；k3 固定 0；json 存完整 5 元素 dist')
report('源码断言', 'T6 R02 calibrate.py 逐张 shape 校验 + imageSize 显式 (1920,1080)',
       'img.shape[:2] != (1080, 1920)' in cal_src and '(1920, 1080)' in cal_src,
       '不可读/非1080p 图 skip；imageSize 不再取循环末张 g.shape')
report('源码断言', 'T6 R02 capture.py 硬拒绝 + 保存前实帧核对',
       '拒绝运行' in cap_src and 'img.shape[:2] != (1080, 1920)' in cap_src,
       '启动即 SystemExit；保存前以实帧 shape 为准')
report('源码断言', 'T6 H08 calibrate.py 下发入口 = send-0x01 / read-0x05 + status_map_uart.json',
       'send-0x01' in cal_src and 'read-0x05' in cal_src
       and 'status_map_uart.json' in cal_src and '十六进制模式' not in cal_src,
       '旧"十六进制模式/--status"文案已清除')
report('源码断言', 'T6 H09 README 正文无"画面应无可见变化"验收措辞',
       '画面应无可见变化' not in rdm_src and '数据判据' in rdm_src,
       '§4 效果验收改为 linearity/MTF50 数据判据（§8 修订记录中的引用文字除外）')
report('源码断言', 'T6 R05/R06 修订落位', 'np.float64' in lin_src
       and '二范数' in lin_src and '线性插值' in mtf_src and 'isnan' not in mtf_src,
       'float64 差分+二范数；标准线性插值+恒真 isnan 分支已删')

# ---------- 总结 ----------
n_pass = sum(results)
print(f'\n=== SELFTEST {"PASSED" if n_pass == len(results) else "FAILED"}: '
      f'{n_pass}/{len(results)} ===')
sys.exit(0 if n_pass == len(results) else 1)
