onerror {quit -code 1 -f}
vlib work
vlog undistort_core.v undistort_line_cache.v undistort_bilinear.v undistort_map.v ../cache_input_directed_tb.v
vsim -voptargs=+acc work.cache_input_directed_tb
onfinish stop
run -all
quit -code 0 -f
