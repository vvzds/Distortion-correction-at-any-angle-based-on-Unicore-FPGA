`timescale 1ns/1ps
module cache_input_directed_tb;
reg clk=0; always #4 clk=~clk;
reg rst_n=0,clear=0,req=0,begin_load=0,vld=0,last=0;
reg [7:0] ba=0,bb=1,lb=0;
reg [10:0] sx=0,lr=0;
reg [255:0] data=0;
reg [11:0] wx=0,wy=0;
wire cv;wire [15:0] p00,p01,p10,p11;
wire ha,hb,ph,ld,le;wire [7:0] bqa,bqb;
integer errors=0,checked=0,cycle=0,clear_count=0,reset_count=0,overlap_count=0;
integer i,j,k,n,fd,seed=32'h21651026;
reg pv[0:3]; integer qa[0:3],qb[0:3],qx[0:3],qw[0:3],qy[0:3];
reg [26:0] hx=0,hy=0;
wire [15:0] cp00,cp01,cp10,cp11;wire ccvalid;
undistort_line_cache cache(
.clk(clk),.rst_n(rst_n),.i_frame_clear(clear),.i_load_begin(begin_load),
.i_load_bank(lb),.i_load_row(lr),.i_load_vld(vld),.i_load_data(data),.i_load_last(last),
.o_load_done(ld),.o_load_error(le),.i_query_row_a(11'd100),.i_query_row_b(11'd101),
.o_hit_a(ha),.o_hit_b(hb),.o_bank_a(bqa),.o_bank_b(bqb),
.i_prefetch_row(11'd102),.o_prefetch_hit(ph),.i_sample_req(req),
.i_sample_bank_a(ba),.i_sample_bank_b(bb),.i_sample_x(sx),
.o_sample_valid(cv),.o_p00(p00),.o_p01(p01),.o_p10(p10),.o_p11(p11));
undistort_core core(.clk(clk),.rst_n(rst_n),
.i_fx(32'd65536000),.i_fy(32'd65536000),.i_cx(32'd62914560),.i_cy(32'd35389440),
.i_k1(32'd0),.i_k2(32'd0),.i_p1(32'd0),.i_p2(32'd0),
.i_aff_a11(32'h10000),.i_aff_a12(32'd0),.i_aff_a21(32'd0),.i_aff_a22(32'h10000),
.i_aff_tx(32'd0),.i_aff_ty(32'd0),.i_aff_en(1'b0),.i_frame_start(1'b0),
.i_corr_src_hold_gnt(1'b0),.i_corr_src_slot(2'd0),.i_corr_rd_gnt(1'b0),
.i_corr_rd_vld(vld),.i_corr_rd_data(data),.i_corr_rd_last(last));
assign ccvalid=core.sample_valid;
assign cp00=core.p00;assign cp01=core.p01;assign cp10=core.p10;assign cp11=core.p11;
initial begin
 force core.sample_dispatch=req;force core.head_x=hx;force core.head_y=hy;
 force core.bank_a=ba;force core.bank_b=bb;force core.cache_load_begin=begin_load;
 force core.load_bank=lb;force core.load_row=lr;force core.u_cache.i_frame_clear=clear;
end
always @* begin hx={sx,wx,4'b0};hy={11'd0,wy,4'b0};end
function [15:0] pixel;
input integer bank,x;
begin pixel=((bank+1)*16'h2137) ^ (x*16'h01bd) ^ (x/16*16'h3001);end
endfunction
task fail;input [8*100-1:0] msg;
begin if(errors<16)$display("FAIL cycle=%0d %0s",cycle,msg);errors=errors+1;end endtask
always @(posedge clk) begin
 cycle=cycle+1;
 if(!rst_n || clear)begin for(n=0;n<4;n=n+1)pv[n]=0;end
 else begin
  for(n=3;n>0;n=n-1)begin pv[n]=pv[n-1];qa[n]=qa[n-1];qb[n]=qb[n-1];qx[n]=qx[n-1];qw[n]=qw[n-1];qy[n]=qy[n-1];end
  pv[0]=req;qa[0]=ba;qb[0]=bb;qx[0]=sx;qw[0]=wx;qy[0]=wy;
 end
 #1;
 if(cv!==pv[3] || ccvalid!==pv[3])fail("valid latency / flush mismatch");
 if(pv[3])begin
  checked=checked+1;
  if(p00!==pixel(qa[3],qx[3]) || p10!==pixel(qb[3],qx[3]) ||
     p01!==pixel(qa[3],qx[3]==1919?1919:qx[3]+1) ||
     p11!==pixel(qb[3],qx[3]==1919?1919:qx[3]+1))fail("standalone pixel mismatch");
  if({cp00,cp01,cp10,cp11}!=={p00,p01,p10,p11})fail("integrated core cache mismatch");
  if(core.interp_wx!==qw[3] || core.interp_wy!==qy[3])fail("weight transaction alignment mismatch");
 end
 if(le || core.load_error)fail("load protocol error");
end
task tick;input rr;input integer x,a,b,w,y;
begin
 @(negedge clk);req=rr;sx=x;ba=a;bb=b;wx=w;wy=y;@(posedge clk);#2;
end endtask
task load_bank;input integer bank;
begin
 @(negedge clk);req=0;begin_load=1;lb=bank;lr=100+bank;
 @(negedge clk);begin_load=0;vld=1;
 for(i=0;i<120;i=i+1)begin
  for(j=0;j<16;j=j+1)data[16*j+:16]=pixel(bank,i*16+j);
  last=(i==119);@(negedge clk);
 end
 vld=0;last=0;@(posedge clk);#2;
end endtask
initial begin
 for(k=0;k<4;k=k+1)pv[k]=0;
 repeat(3)@(negedge clk);rst_n=1;
 for(k=0;k<4;k=k+1)load_bank(k);
 if(!ha || !hb || !ph || bqa!=0 || bqb!=1)fail("tag load/query mismatch");
 for(k=0;k<16;k=k+1)begin
  tick(1,15,k/4,k%4,k*233,k*197);tick(0,937,0,0,4095,1);
  tick(1,16,k%4,k/4,4095-k*119,k*257);tick(0,300,0,0,3,4);
  tick(1,1919,k/4,k%4,k*137,4095-k*131);tick(0,2,0,0,17,31);
 end
 for(k=0;k<600;k=k+1)begin
  tick(1,($random(seed)&32'h7fffffff)%1920,k%4,(k+1)%4,($random(seed)&4095),($random(seed)&4095));
  tick(0,($random(seed)&32'h7fffffff)%1920,0,0,4095,4095);
  if(k%7==0)tick(0,345,3,2,12,13);
 end
 repeat(6)tick(0,345,3,2,12,13);
 for(k=0;k<4;k=k+1)begin
  tick(1,15+k,k%4,(k+1)%4,200+k,300+k);
  for(j=0;j<k;j=j+1)tick(0,1000,3,2,4095,4095);
  @(negedge clk);req=0;clear=1;clear_count=clear_count+1;
  @(posedge clk);#2;if(ha || hb || ph)fail("clear failed to invalidate tags");
  @(negedge clk);clear=0;repeat(6)tick(0,0,0,1,0,0);
 end
 @(negedge clk);req=1;clear=1;sx=31;
 @(negedge clk);req=0;clear=0;clear_count=clear_count+1;
 repeat(6)tick(0,0,0,1,0,0);
 for(k=0;k<4;k=k+1)begin
  tick(1,1919-k,k%4,(k+1)%4,777,2222);
  for(j=0;j<k;j=j+1)tick(0,0,0,1,0,0);
  @(negedge clk);req=0;rst_n=0;reset_count=reset_count+1;
  #1;if(cv || ccvalid)fail("asynchronous reset valid not cleared");
  repeat(2)@(negedge clk);rst_n=1;repeat(6)tick(0,0,0,1,0,0);
 end
 for(k=0;k<4;k=k+1)load_bank(k);
 @(negedge clk);begin_load=1;lb=3;lr=103;
 @(negedge clk);begin_load=0;vld=1;
 for(k=0;k<120;k=k+1)begin
  req=(k%2==0);sx=(k*17)%1920;ba=0;bb=1;wx=(k*113)%4096;wy=(k*211)%4096;
  for(j=0;j<16;j=j+1)data[16*j+:16]=pixel(3,k*16+j);
  last=(k==119);overlap_count=overlap_count+req;@(negedge clk);
 end
 req=0;vld=0;last=0;repeat(8)tick(0,0,0,1,0,0);
 fd=$fopen("directed_result.txt","w");
 $fdisplay(fd,"DIRECTED errors=%0d checked=%0d clears=%0d resets=%0d overlap=%0d",errors,checked,clear_count,reset_count,overlap_count);
 if(errors==0 && checked>=700 && clear_count==5 && reset_count==4 && overlap_count==60)begin
  $fdisplay(fd,"DIRECTED_PASS");$display("DIRECTED_PASS checked=%0d",checked);
 end else begin $fdisplay(fd,"DIRECTED_FAIL");$display("DIRECTED_FAIL errors=%0d checked=%0d",errors,checked);end
 $fclose(fd);$finish;
end
initial begin #1000000;$display("DIRECTED_TIMEOUT");$finish;end
endmodule
