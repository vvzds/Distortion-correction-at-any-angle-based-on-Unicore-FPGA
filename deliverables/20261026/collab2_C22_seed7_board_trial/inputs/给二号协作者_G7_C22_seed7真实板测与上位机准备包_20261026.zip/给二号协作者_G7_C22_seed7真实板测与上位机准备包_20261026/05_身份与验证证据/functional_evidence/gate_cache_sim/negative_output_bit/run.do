onerror {quit -code 1 -f}
vlib work
vlog ../GTP_DFF_C.v ../GTP_DFF_CE.v ../GTP_DFF_E.v ../GTP_DRM36K_E1.v ../GTP_GRS.v ../GTP_INBUF.v ../GTP_INV.v ../GTP_LUT2.v ../GTP_LUT3.v ../GTP_LUT4.v ../GTP_LUT5.v ../GTP_LUT6.v ../GTP_LUT6CARRY.v ../GTP_LUT6D.v ../GTP_MUX2LUT6.v ../GTP_MUX2LUT7.v ../GTP_MUX2LUT8.v ../GTP_OUTBUF.v ../GTP_RAM64X1DP.v ../INT_LUTMUX2_UDP.v ../INT_LUTMUX4_UDP.v ../undistort_line_cache_syn.v ../undistort_core.v ../undistort_line_cache.v ../undistort_bilinear.v ../undistort_map.v cache_input_directed_tb.v
vsim -voptargs=+acc work.cache_input_directed_tb
onfinish stop
run -all
quit -code 0 -f
