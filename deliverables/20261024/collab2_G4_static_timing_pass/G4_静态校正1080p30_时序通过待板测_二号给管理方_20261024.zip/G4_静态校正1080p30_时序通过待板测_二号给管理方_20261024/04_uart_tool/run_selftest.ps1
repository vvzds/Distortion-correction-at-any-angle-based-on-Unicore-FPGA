param([string]$Python='python')
$ErrorActionPreference='Stop'
$projectRoot=$PSScriptRoot
$logs=Join-Path $projectRoot 'verification'
New-Item -ItemType Directory -Path $logs -Force | Out-Null
$env:PYTHONIOENCODING='utf-8'
$log=Join-Path $logs 'selftest_console.log'
& $Python -B (Join-Path $projectRoot 'uart_tool.py') selftest 2>&1 |
    Tee-Object -FilePath $log -Encoding UTF8
$code=$LASTEXITCODE
if($code -ne 0 -or !(Select-String -LiteralPath $log -Pattern '^=== ALL TESTS PASSED ===$' -Quiet)) {
    throw "UART selftest failed; see $log"
}
