from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
entries=json.loads((root/'SHA256.json').read_text(encoding='utf-8'))
bad=[name for name,digest in entries.items() if not (root/name).is_file() or hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest]
print('PASS' if not bad else 'FAIL: '+repr(bad))
raise SystemExit(bool(bad))
