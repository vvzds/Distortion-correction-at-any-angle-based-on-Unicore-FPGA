cd [file dirname [info script]]
set_arch -family Logos2 -device PG2L100H -speedgrade -6 -package FBG676
add_constraint "HDMI_DDR3_OV5640_test.fdc"
add_constraint "device_map/hdmi_ddr_ov5640_top.pcf"
pnr -force_to_run -input_db_file "device_map/hdmi_ddr_ov5640_top_map.adf" -gplace_seed 4 -groute_seed 5 -optimize_multi_corner_timing -fix_hold_violation -fix_hold_violation_iterations 20
report_timing
