cd [file dirname [info script]]
set_arch -family Logos2 -device PG2L100H -speedgrade -6 -package FBG676
gen_bit_stream -force_to_run -input_db_file "place_route/hdmi_ddr_ov5640_top_pnr.adf"
