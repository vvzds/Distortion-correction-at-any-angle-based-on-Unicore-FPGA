`timescale 1ns/1ps
module host_control_tb;
    reg clk=0;always #4 clk=~clk;
    reg rst_n=0,rx=1,busy=1;
    wire tx,pending;wire [511:0] cfg;wire [15:0] active_seq;
    wire [31:0] errors,packets;
    host_control #(.CLOCK_HZ(1152000),.BAUD(115200)) dut(
        .clk(clk),.rst_n(rst_n),.uart_rx(rx),.uart_tx(tx),.busy(busy),
        .telemetry(256'h0000000a00000009000000080000000700000006000000050000000400000003),
        .cfg(cfg),.pending(pending),.active_sequence(active_seq),.rx_errors(errors),.valid_packets(packets));
    wire tx_byte_valid,tx_byte_error;wire [7:0] tx_byte;
    wire dummy_tx,dummy_busy;
    uart_phy #(.CLOCK_HZ(1152000),.BAUD(115200)) monitor(
        clk,rst_n,tx,dummy_tx,tx_byte_valid,tx_byte_error,tx_byte,1'b0,8'd0,dummy_busy);
    reg [7:0] reply[0:56];integer reply_count=0;
    always @(posedge clk) if(tx_byte_valid) begin
        if(reply_count>56) $fatal(1,"Too many reply bytes");
        reply[reply_count]=tx_byte;reply_count=reply_count+1;
    end
    function [15:0] crc_byte;
        input [15:0] old_crc;input [7:0] b;reg [15:0] c;integer k;
        begin c=old_crc^{b,8'd0};for(k=0;k<8;k=k+1)c=c[15]?(c<<1)^16'h1021:c<<1;crc_byte=c;end
    endfunction
    task send_byte;
        input [7:0] b;integer k;
        begin
            @(negedge clk);rx=0;repeat(10) @(negedge clk);
            for(k=0;k<8;k=k+1)begin rx=b[k];repeat(10) @(negedge clk);end
            rx=1;repeat(10) @(negedge clk);
        end
    endtask
    reg [511:0] payload,initial_cfg;
    reg [15:0] checksum;
    task send_packet;
        input [7:0] command,length;input [15:0] seq;input bad_crc;
        integer j;reg [7:0] b;
        begin
            checksum=16'hffff;
            send_byte(8'haa);send_byte(8'h55);
            send_byte(1);checksum=crc_byte(checksum,1);
            send_byte(command);checksum=crc_byte(checksum,command);
            send_byte(length);checksum=crc_byte(checksum,length);
            send_byte(seq[7:0]);checksum=crc_byte(checksum,seq[7:0]);
            send_byte(seq[15:8]);checksum=crc_byte(checksum,seq[15:8]);
            for(j=0;j<length;j=j+1) begin b=payload[j*8+:8];send_byte(b);checksum=crc_byte(checksum,b);end
            send_byte(checksum[7:0]^{7'd0,bad_crc});send_byte(checksum[15:8]);
            repeat(12) @(negedge clk);
        end
    endtask
    integer k;reg [15:0] response_crc;
    initial begin
        repeat(8) @(negedge clk);rst_n=1;
        repeat(8) @(negedge clk);initial_cfg=cfg;
        if(cfg[6*32+:32]!=98809312) $fatal(1,"Missing real boot calibration");
        payload=cfg;payload[0+:32]=178000;
        send_packet(8'h10,64,16'h1234,1);
        if(pending || cfg!==initial_cfg || errors!=1) $fatal(1,"Bad CRC changed configuration");
        send_packet(8'h10,64,16'h1235,0);
        if(!pending || cfg!==initial_cfg || active_seq!=0) $fatal(1,"Busy configuration changed");
        busy=0;repeat(4) @(negedge clk);
        if(pending || cfg!==payload || active_seq!=16'h1235) $fatal(1,"Atomic apply failed");
        busy=1;payload[6*32+:32]=0;
        send_packet(8'h10,64,16'h1236,0);
        if(pending || active_seq!=16'h1235 || errors!=2) $fatal(1,"Invalid focal length accepted");
        payload=cfg;payload[1*32+:32]=100;
        send_packet(8'h10,64,16'h1237,0);
        payload[1*32+:32]=200;
        send_packet(8'h10,64,16'h1238,0);
        if(active_seq!=16'h1235 || !pending) $fatal(1,"Pending overwrite violated frame atomicity");
        busy=0;repeat(4) @(negedge clk);
        if(cfg!==payload || active_seq!=16'h1238) $fatal(1,"Latest complete pending group not applied");
        send_packet(8'h20,0,16'habcd,0);
        wait(reply_count==57);repeat(20) @(negedge clk);
        if(reply[0]!=8'haa || reply[1]!=8'h55 || reply[3]!=8'ha0 || reply[4]!=48 ||
           reply[5]!=8'hcd || reply[6]!=8'hab) $fatal(1,"Response header");
        response_crc=16'hffff;
        for(k=2;k<=54;k=k+1)response_crc=crc_byte(response_crc,reply[k]);
        if({reply[56],reply[55]}!==response_crc) $fatal(1,"Response CRC");
        if({reply[12],reply[11]}!=16'h1238) $fatal(1,"Response active active_seq");
        $display("PASS host_control CRC, bounds, frame atomicity, pending replacement and status");$finish;
    end
    initial begin #20000000;$fatal(1,"Timeout");end
endmodule
