// Production correction path; all signals share the 125 MHz DDR clock.
wire [511:0] correction_config;
wire correction_busy,config_pending,core_fault;
wire [31:0] corrected_frames,frame_cycles,read_wait_cycles,write_wait_cycles;
wire [31:0] source_read_beats,invalid_pixel_count,patch_overflows;
wire [31:0] host_rx_errors,host_packet_count;
wire [15:0] active_config_sequence;
wire [1:0] adaptive_mode;
wire [31:0] correction_flags={26'd0,adaptive_mode,corr_protocol_error,core_fault,config_pending,correction_busy};
host_control u_host_control(
    .clk(corr_clk),.rst_n(corr_rst_n),.uart_rx(uart_rx),.uart_tx(uart_tx),
    .busy(correction_busy),
    .telemetry({correction_flags,patch_overflows,invalid_pixel_count,source_read_beats,
                write_wait_cycles,read_wait_cycles,frame_cycles,corrected_frames}),
    .cfg(correction_config),.pending(config_pending),.active_sequence(active_config_sequence),
    .rx_errors(host_rx_errors),.valid_packets(host_packet_count)
);
tile_engine u_tile_engine(
    .clk(corr_clk),.rst_n(corr_rst_n),.frame_update(o_frame_update),
    .cfg(correction_config),.config_pending(config_pending),.busy(correction_busy),
    .src_req(corr_src_hold_req),.src_gnt(corr_src_hold_gnt),.src_slot(corr_src_slot),.src_rel(corr_src_rel),
    .rd_req(corr_rd_req),.rd_addr(corr_rd_addr),.rd_len(corr_rd_len),
    .rd_gnt(corr_rd_gnt),.rd_valid(corr_rd_vld),.rd_last(corr_rd_last),.rd_data(corr_rd_data),
    .slot_req(corr_wr_slot_req),.slot_gnt(corr_wr_slot_gnt),.slot(corr_wr_slot),
    .wr_req(corr_wr_req),.wr_addr(corr_wr_addr),.wr_data(corr_wr_data),.wr_gnt(corr_wr_gnt),
    .commit(corr_wr_commit),.published(corr_pub_pulse),
    .frame_count(corrected_frames),.last_cycles(frame_cycles),
    .last_rd_wait(read_wait_cycles),.last_wr_wait(write_wait_cycles),
    .last_read_beats(source_read_beats),.last_invalid(invalid_pixel_count),
    .overflow_tiles(patch_overflows),.protocol_fault(core_fault),.gamma_mode(adaptive_mode)
);
