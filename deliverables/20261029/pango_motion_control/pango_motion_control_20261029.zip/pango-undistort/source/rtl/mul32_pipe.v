`timescale 1ns/1ps
// Exact signed 32x32 product, II=1, four register stages. Explicit 16-bit
// partial products prevent the vendor mapper from building a long unregistered
// DSP cascade. Register every accumulation boundary; no truncation is added.
module mul32_pipe(input wire clk,
    input wire signed [31:0] a,b,
    output reg signed [63:0] product
);
    reg signed [33:0] ll;
    reg signed [32:0] lh,hl;
    reg signed [31:0] hh;
    reg signed [33:0] middle,ll_d;
    reg signed [31:0] hh_d;
    reg signed [63:0] low_middle,high_part;
    always @(posedge clk) begin
        ll<=$signed({1'b0,a[15:0]})*$signed({1'b0,b[15:0]});
        lh<=$signed({1'b0,a[15:0]})*$signed(b[31:16]);
        hl<=$signed(a[31:16])*$signed({1'b0,b[15:0]});
        hh<=$signed(a[31:16])*$signed(b[31:16]);
        middle<=$signed({lh[32],lh})+$signed({hl[32],hl});ll_d<=ll;hh_d<=hh;
        low_middle<=$signed(ll_d)+($signed({{30{middle[33]}},middle})<<<16);
        high_part<=$signed({{32{hh_d[31]}},hh_d})<<<32;
        product<=low_middle+high_part;
    end
endmodule
