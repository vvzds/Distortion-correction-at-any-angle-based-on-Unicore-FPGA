# 接板验收步骤

2026-10-29 实板验收完成。板卡 PG2L100H（JTAG ID `0x00602899`），CP210x UART 为 COM9。正式 seed 3 发布位流 SHA256 `38ab1af1fc0fe1c15a7934d91b343679b0d4c999d788714bcf9b199b13a42ffd` 已通过普通 JTAG 下载到 SRAM，PDS 报告 `done=1`；没有写入 Flash。完整数据见 `reports/board_runs/` 和 `release/board_acceptance.json`。

发布帧率按 UART `corrected_frames` 差值除以主机 monotonic 实测秒数，不以 HDMI 刷新率推断。

1. 确认 PG2L100H-6 FBG676、OV5640、HDMI 和 3.3V UART 接线；UART RX/TX 是 B24/C24，115200-8-N-1。
2. 启动 PDS JTAG server：`Start-Process D:\pango\PDS_2022.2-SP6.4\bin\cdt_js.exe -ArgumentList '-port 65421 -work_dir D:/restart/fpga-undistort/reports/board_runs' -WindowStyle Hidden`，再运行 `python tools/program_sram.py --server-port 65421 --output reports/board_runs/<新目录>`。脚本会核对位流 SHA256 和器件 ID，并采用普通 JTAG（program=0）写入 SRAM；不写 Flash。此前试用关断+ISC（program=3）后逻辑未启动，本板已验证应使用普通 JTAG。
3. 上电后运行 `python host/control.py ports`，确认串口；运行 `python host/control.py status --port COMx`，确认固件身份已由工具校验、发布帧计数递增且无 fault；初始化是否完成同时观察板上 LED 和视频。
4. 发送默认真实标定：`python host/control.py send --port COMx --angle 0`；确认返回 `active_sequence` 已变化。
5. 发送高阶场景：`python host/control.py send --port COMx --angle 45 --auto-crop`；观察 HDMI 图像，再运行 `python host/control.py monitor --port COMx --seconds 10 --output reports/board_fps.json`。
6. 以 `actual_new_frame_fps` 和板端 `cycles`/`read_wait`/`write_wait` 判断吞吐；保存 UART 原始收发数据与完整状态。

如果出现 `core_fault`、`write_fault`、patch overflow 或序号不变化，停止继续发送，保留状态和位流 SHA256。不要在未保存状态前反复改参数。

`python tools/board_test.py --port COMx --output reports/board_runs/<新目录> --seconds 10` 可连续测量默认、45°、90°、组合仿射和 Gamma 场景，保存 UART 原始收发字节、参数生效回执及发布帧数差。`--probe-only` 只查询身份；`--capture` 短时占用已识别的 Hagibis 并保存三帧。`--worst-case` 测45°不裁边；`--sweep` 每15°验证一个完整角度周期。正常运行结束会恢复0°真实标定和自适应Gamma。脚本记录的位流 SHA 是待测文件身份，下载证据仍须由 PDS 原始日志提供。

本轮实测：默认、45°/90°自动裁边、17°+平移+剪切、Gamma五个场景均有非黑1920×1080图像，帧率29.977–30.002 fps；45°不裁边连续180.49秒达到29.996 fps；0–345°每15°切换，共24个命令全部确认在帧界生效，29.933–30.175 fps。各运行无RX error、core/write fault或tile overflow。45°不裁边时`invalid_pixels=453788`（valid fraction78.12%），为旋转后超出源画面的黑边；自动裁边场景的invalid count为0。测试结束已恢复0°真实标定和自适应Gamma。

用户提供的11×8内角点棋盘直线RMS中位数：旁路`k1/k2/p1/p2=0`为2.674 px，真实标定校正为0.115 px，回切旁路为2.689 px，回切差0.016 px。采集是Hagibis MJPG解码帧，不是FPGA DDR像素转储。MTF50探索性输出边缘样本数量不足，不能作为实板清晰度结论或ISO12233测量。

排障记录：CP210x驱动安装后出现COM9。首轮使用program=3（ISC+关断重配置）后心跳和DDR灯不亮、画面全黑；同一位流改用program=0后正常启动，UART身份及递增发布计数均确认。PDS状态寄存器报告`over_temp=1`；用户未观察到明显过热，但未量测结温，原因未知。

复摆棋盘格后的首次采集时，板卡刚被断电，故UART无响应且画面全黑；没有把黑帧用于质量分析。用户重新上电并授权下载后，普通JTAG SRAM配置成功（done=1，未写Flash）。随后旁路、真实标定和旁路三段各测得30.034 fps；全部9帧都检测到88个内角点。直线RMS中位数为2.881 px、0.159 px、2.871 px，重复旁路差0.009 px，校正改善18.2倍。证据见`reports/board_runs/20261029_1540_checker_repositioned/`和`release/board_acceptance.json`。
