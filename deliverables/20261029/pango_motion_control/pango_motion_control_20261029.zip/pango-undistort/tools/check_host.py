"""Offline host checks, including a withdrawn Tk instance; no port is opened."""
import binascii,hashlib,json,struct,sys,time,tkinter as tk
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'host'))
from protocol import packet,decode,parse_status,Connection,MAGIC
from model import load_calibration,affine,preflight
from gui import Application

start=time.monotonic();checks=[]
assert binascii.crc_hqx(b'123456789',0xffff)==0x29b1
data=packet(0x10,65535,bytes(range(64)))
assert decode(data)==(0x10,65535,bytes(range(64)))
bad=bytearray(data);bad[14]^=1
try:decode(bad)
except ValueError:pass
else:raise AssertionError('Bad CRC accepted')
checks.append('CRC16 check vector, packet round trip and corruption rejection')
status=parse_status(struct.pack('<12I',MAGIC,(8<<16)|7,123,3125000,4,5,6,7,8,0b101111,9,10))
assert status['active_sequence']==7 and status['pending_sequence']==8
assert status['processing_capacity_fps']==40 and status['gamma_mode']==2
assert status['core_fault'] and status['write_fault'] and status['pending'] and status['busy']
checks.append('Status field positions, flags and cycle-to-capacity conversion')

class MockPort:
    def write(self,data):self.last=data
link=Connection.__new__(Connection);link.serial=MockPort();link.sequence=65534
previous=dict(status,active_sequence=65535,pending_sequence=0)
def mock_status():
    if not hasattr(link.serial,'last'):return previous
    return dict(status,active_sequence=decode(link.serial.last)[1],core_fault=False,write_fault=False)
link.status=mock_status
regs,_=preflight(load_calibration(),affine(),False)
link.configure(regs)
assert decode(link.serial.last)[1]==1
checks.append('Sequence wrap cannot match an old active/pending configuration')

root=tk.Tk();root.withdraw()
app=Application(root);root.update_idletasks()
assert len(root.winfo_children())>0 and app.link is None
_,report,parameters=app.prepare(dict(angle=90,zoom=2.,tx=0.,ty=0.,shear=0.),True,True)
assert parameters['zoom']==2. and report['valid_fraction']==1.
app.angle.set('invalid');assert app.parameters() is None
root.destroy()
checks.append('Hidden GUI initialization, no implicit serial open, manual zoom preserved, invalid text handled')
report={'passed':True,'hardware_opened':False,'elapsed_seconds':time.monotonic()-start,'checks':checks,
        'inputs_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in (ROOT/'host').glob('*.py')}}
(ROOT/'reports/host_checks.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('PASS host checks:',len(checks))
