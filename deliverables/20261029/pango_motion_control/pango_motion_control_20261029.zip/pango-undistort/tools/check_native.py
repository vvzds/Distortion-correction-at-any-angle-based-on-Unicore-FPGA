import sys,argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tools'))
from generate_frame_vectors import generate
from run_sim import run
p=argparse.ArgumentParser();p.add_argument('--angle',type=float,default=45);p.add_argument('--zoom',type=float,default=1)
p.add_argument('--latency',type=int,default=24);p.add_argument('--gap',type=int,default=4);p.add_argument('--period',type=int,default=514)
p.add_argument('--next-angle',type=float)
a=p.parse_args();tag=generate(a.angle,a.zoom);folder=ROOT/'build/vectors'
extra=[];suffix=''
if a.next_angle is not None:
    tag2=generate(a.next_angle,a.zoom);suffix=f'_then{a.next_angle:g}'
    extra=['+CONFIG2='+str(folder/f'frame_config_{tag2}.hex'),'+GOLDEN2='+str(folder/f'golden_{tag2}.hex')]
run('native_video_tb',['source/rtl/mul32_pipe.v','source/rtl/brown_map.v','source/rtl/patch_store.v','source/rtl/bilinear_rgb.v',
    'source/rtl/adaptive_gamma.v','source/rtl/tile_engine.v','source/rtl/tile_write_pack.v',
    'source/rtl/corr_read_bridge.v','source/rtl/corr_write_arb.v','sim/native_video_tb.v'],
    ['+CONFIG='+str(folder/f'frame_config_{tag}.hex'),'+GOLDEN='+str(folder/f'golden_{tag}.hex'),
     '+RESULT='+str(ROOT/f'reports/native_{tag}{suffix}_latency{a.latency}_period{a.period}.json'),
     f'+LATENCY={a.latency}',f'+GAP={a.gap}',f'+PERIOD={a.period}',*extra])
