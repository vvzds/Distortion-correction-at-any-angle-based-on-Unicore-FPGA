"""Build the full source/bitstream package and a verifiable SHA256 manifest."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    files = sorted(path for path in ROOT.rglob('*') if path.is_file() and
                   '__pycache__' not in path.parts and path.suffix != '.pyc' and
                   path.name != 'DELIVERY_SHA256.json')
    hashes = {path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
              for path in files}
    manifest = ROOT/'DELIVERY_SHA256.json'
    manifest.write_text(json.dumps(hashes, indent=2)+'\n', encoding='utf-8')
    archive = output_dir/'pango_command_affine_20261029.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=6) as destination:
        for path in sorted(files+[manifest]):
            destination.write(path, Path('pango-undistort')/path.relative_to(ROOT))
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    (output_dir/(archive.stem+'.sha256')).write_text(
        f'{digest}  {archive.name}\n', encoding='ascii')
    print(json.dumps({'archive': str(archive), 'files': len(files)+1,
                      'sha256': digest, 'clean_smooth_bitstream_sha256':
                      hashes['release/pango_undistort_clean_smooth.sbit']}, indent=2))


if __name__ == '__main__':
    main()
