`timescale 1ns/1ps

module diag_counter_tb;
    reg clk = 0;
    reg rst_n = 0;
    reg camera_vsync = 0;
    reg raw_complete = 0;
    reg corrected_publish = 0;
    reg hdmi_advance = 0;
    reg passed = 0;
    always #4 clk = ~clk;

    corr_top #(.CLK_FREQ(12_500_000), .SIM_MODE(1)) dut (
        .clk(clk), .rst_n(rst_n), .i_uart_rx(1'b1), .o_uart_tx(),
        .i_frame_wcnt(2'b00), .i_frame_update(raw_complete),
        .i_camera_vsync(camera_vsync), .i_display_advance(hdmi_advance),
        .o_corr_src_hold_req(), .i_corr_src_hold_gnt(1'b0),
        .i_corr_src_slot(2'b00), .o_corr_src_rel(),
        .o_corr_rd_req(), .o_corr_rd_addr(), .o_corr_rd_len(),
        .i_corr_rd_gnt(1'b0), .i_corr_rd_vld(1'b0),
        .i_corr_rd_data(256'b0), .i_corr_rd_last(1'b0),
        .o_corr_wr_slot_req(), .i_corr_wr_slot_gnt(1'b0),
        .i_corr_wr_slot(3'b0), .o_corr_wr_commit(),
        .o_corr_wr_req(), .o_corr_wr_addr(), .o_corr_wr_data(),
        .i_corr_wr_gnt(1'b0), .i_corr_pub_pulse(corrected_publish)
    );

    task advance_page;
        begin
            @(negedge clk);
            force dut.status_read_pulse = 1'b1;
            @(negedge clk);
            release dut.status_read_pulse;
            #1;
        end
    endtask

    task expect_page;
        input [1:0] page;
        input [15:0] count;
        begin
            #1;
            if (dut.w_status[31:16] !== count ||
                dut.w_status[15:12] !== 4'hD ||
                dut.w_status[11:10] !== page) begin
                $display("FAIL page=%d count=%d got=%h", page, count, dut.w_status);
                $fatal(1);
            end
        end
    endtask

    initial begin
        repeat (4) @(negedge clk);
        rst_n = 1;
        @(negedge clk); camera_vsync = 1;
        repeat (4) @(negedge clk);
        camera_vsync = 0;
        repeat (4) @(negedge clk);
        raw_complete = 1; corrected_publish = 1; hdmi_advance = 1;
        @(negedge clk);
        raw_complete = 0; corrected_publish = 0; hdmi_advance = 0;
        repeat (2) @(negedge clk);
        expect_page(0, 1);
        advance_page(); expect_page(1, 1);
        advance_page(); expect_page(2, 1);
        advance_page(); expect_page(3, 1);
        advance_page(); expect_page(0, 1);
        passed = 1;
        $display("PASS four-stage counters and page rotation");
        #40;
        $finish;
    end
endmodule
