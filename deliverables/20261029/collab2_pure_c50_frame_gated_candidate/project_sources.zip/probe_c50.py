#!/usr/bin/env python3
"""Read C50 diagnostic counters over the existing 0x05 UART status command."""

import argparse
import csv
import struct
import time

import serial


REQUEST = bytes.fromhex("AA 55 05 00 00")
NAMES = ("camera_vsync", "raw_complete", "corrected_publish", "hdmi_advance")


def read_exact(port, size, deadline):
    data = bytearray()
    while len(data) < size:
        if time.monotonic() >= deadline:
            raise TimeoutError("UART status reply timed out")
        data.extend(port.read(size - len(data)))
    return bytes(data)


def read_status(port):
    port.reset_input_buffer()
    if port.write(REQUEST) != len(REQUEST):
        raise IOError("short UART request write")
    port.flush()
    deadline = time.monotonic() + 1.5
    previous = 0
    while True:
        byte = read_exact(port, 1, deadline)[0]
        if previous == 0xAA and byte == 0x55:
            break
        previous = byte
    payload = read_exact(port, 7, deadline)
    if payload[:2] != b"\x05\x04" or payload[-1] != sum(payload[2:6]) & 0xFF:
        raise ValueError("invalid UART status reply: " + payload.hex())
    word = struct.unpack("<I", payload[2:6])[0]
    if (word >> 12) & 0xF != 0xD:
        raise ValueError("bitstream lacks four-stage diagnostics: 0x%08X" % word)
    return (word >> 10) & 3, (word >> 16) & 0xFFFF, word


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", default="COM11")
    parser.add_argument("--seconds", type=float, default=30.0)
    parser.add_argument("--csv", default="c50_four_stage_counts.csv")
    args = parser.parse_args()
    if args.seconds <= 0:
        parser.error("--seconds must be positive")

    samples = {}
    start = time.monotonic()
    with serial.Serial(args.port, 115200, timeout=0.05) as port, open(
        args.csv, "w", newline="", encoding="utf-8"
    ) as output:
        writer = csv.writer(output)
        writer.writerow(("elapsed_s", "stage", "count", "status_hex"))
        while time.monotonic() - start < args.seconds:
            page, count, word = read_status(port)
            elapsed = time.monotonic() - start
            writer.writerow(("%.6f" % elapsed, NAMES[page], count, "%08X" % word))
            samples.setdefault(page, []).append((elapsed, count))
        output.flush()

    for page, name in enumerate(NAMES):
        values = samples.get(page, [])
        if len(values) < 2:
            print("%s: insufficient samples" % name)
            continue
        elapsed = values[-1][0] - values[0][0]
        # Adjacent deltas handle a 16-bit wrap during a longer run.
        delta = sum((b[1] - a[1]) & 0xFFFF for a, b in zip(values, values[1:]))
        print("%s: %d events / %.3f s = %.3f/s" % (name, delta, elapsed, delta / elapsed))
    print("Raw samples: " + args.csv)


if __name__ == "__main__":
    main()
