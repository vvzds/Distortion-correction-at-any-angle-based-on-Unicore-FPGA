import struct
import sys
import types
import unittest

sys.modules.setdefault("serial", types.SimpleNamespace())
import probe_c50


class FakePort:
    def __init__(self, response):
        self.response = bytearray(response)
        self.request = b""

    def reset_input_buffer(self):
        pass

    def write(self, data):
        self.request = data
        return len(data)

    def flush(self):
        pass

    def read(self, count):
        data = self.response[:count]
        del self.response[:count]
        return bytes(data)


def response(word):
    payload = struct.pack("<I", word)
    return b"\xaa\x55\x05\x04" + payload + bytes((sum(payload) & 0xFF,))


class ProbeTest(unittest.TestCase):
    def test_status_page_and_counter(self):
        word = (123 << 16) | (0xD << 12) | (2 << 10) | 0x112
        port = FakePort(response(word))
        self.assertEqual(probe_c50.read_status(port), (2, 123, word))
        self.assertEqual(port.request, probe_c50.REQUEST)

    def test_rejects_old_bitstream(self):
        with self.assertRaisesRegex(ValueError, "lacks four-stage"):
            probe_c50.read_status(FakePort(response(0x00000012)))


if __name__ == "__main__":
    unittest.main()
