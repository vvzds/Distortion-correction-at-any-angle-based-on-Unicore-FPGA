`timescale 1ns/1ps

module frame_gate_tb;
    reg clk = 0;
    reg rst_n = 0;
    reg raw_complete = 0;
    integer starts = 0;
    integer failures = 0;
    reg passed = 0;
    always #4 clk = ~clk;
    always @(posedge clk)
        if (rst_n && dut.w_start_gated) starts = starts + 1;

    corr_top #(.CLK_FREQ(12_500_000), .SIM_MODE(1)) dut (
        .clk(clk), .rst_n(rst_n), .i_uart_rx(1'b1), .o_uart_tx(),
        .i_frame_wcnt(2'b00), .i_frame_update(raw_complete),
        .i_camera_vsync(1'b0), .i_display_advance(1'b0),
        .o_corr_src_hold_req(), .i_corr_src_hold_gnt(1'b0),
        .i_corr_src_slot(2'b00), .o_corr_src_rel(),
        .o_corr_rd_req(), .o_corr_rd_addr(), .o_corr_rd_len(),
        .i_corr_rd_gnt(1'b0), .i_corr_rd_vld(1'b0),
        .i_corr_rd_data(256'b0), .i_corr_rd_last(1'b0),
        .o_corr_wr_slot_req(), .i_corr_wr_slot_gnt(1'b0),
        .i_corr_wr_slot(3'b0), .o_corr_wr_commit(),
        .o_corr_wr_req(), .o_corr_wr_addr(), .o_corr_wr_data(),
        .i_corr_wr_gnt(1'b0), .i_corr_pub_pulse(1'b0)
    );

    task ticks;
        input integer count;
        begin repeat (count) @(negedge clk); end
    endtask

    task raw_event;
        begin
            raw_complete = 1;
            ticks(1);
            raw_complete = 0;
        end
    endtask

    task expect_starts;
        input integer expected;
        begin
            if (starts !== expected) begin
                failures = failures + 1;
                $display("start count got=%0d expected=%0d", starts, expected);
            end
        end
    endtask

    initial begin
        ticks(4); rst_n = 1;
        force dut.w_params_valid = 1'b1;
        force dut.w_frame_busy = 1'b0;
        ticks(8); expect_starts(0);

        raw_event(); ticks(5); expect_starts(1);
        force dut.w_frame_busy = 1'b1;
        ticks(3);
        force dut.w_frame_busy = 1'b0;
        ticks(8); expect_starts(1);

        force dut.w_frame_busy = 1'b1;
        raw_event(); ticks(2);
        raw_event(); ticks(2); expect_starts(1);
        force dut.w_frame_busy = 1'b0;
        ticks(6); expect_starts(2);
        force dut.w_frame_busy = 1'b1;
        ticks(2);
        force dut.w_frame_busy = 1'b0;
        ticks(8); expect_starts(2);

        force dut.w_params_valid = 1'b0;
        raw_event(); ticks(5); expect_starts(2);
        force dut.w_params_valid = 1'b1;
        ticks(6); expect_starts(3);
        force dut.w_frame_busy = 1'b1;
        ticks(2);
        force dut.w_frame_busy = 1'b0;
        ticks(8); expect_starts(3);

        force dut.w_frame_busy = 1'b1;
        raw_event();
        force dut.w_frame_busy = 1'b0;
        raw_complete = 1;
        ticks(1);
        raw_complete = 0;
        ticks(4); expect_starts(4);
        force dut.w_frame_busy = 1'b1;
        ticks(2);
        force dut.w_frame_busy = 1'b0;
        ticks(5); expect_starts(5);
        force dut.w_frame_busy = 1'b1;
        ticks(2);
        force dut.w_frame_busy = 1'b0;
        ticks(6); expect_starts(5);

        passed = failures == 0;
        $display("frame gate complete: starts=%0d failures=%0d", starts, failures);
    end
endmodule
