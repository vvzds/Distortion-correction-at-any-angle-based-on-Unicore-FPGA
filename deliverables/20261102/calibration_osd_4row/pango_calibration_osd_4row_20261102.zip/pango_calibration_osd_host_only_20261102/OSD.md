# HDMI 参数与画质叠层：实现和验收边界

> 本文记录 2026-10-31 原始 OSD 版本。2026-11-02 的四行 RTL 与上位机改版见 [CALIBRATION_ONLY_20261102.md](CALIBRATION_ONLY_20261102.md)；新版背景框只覆盖四行标定数值。

## 信号路径

OV5640 → RAW8/Bayer → DDR采集帧 → Brown4/双线性矫正 → DDR校正帧 → HDMI像素读出 → **OSD** → 开发板HDMI输出 → Hagibis HDMI IN → HDMI OUT显示屏。同时Hagibis USB3可由电脑采集测试图卡。OSD 位于最终RGB输出前，故不会回写到DDR或改动算法结果；它会出现在HDMI OUT和USB采集画面中。

OSD 使用8行、每行48字符的屏显文本。UART 115200新增CRC保护的行更新与显示开关命令，核心时钟到像素时钟使用请求/应答握手传输稳定的整行数据。显示开关只在视频帧边界切换。无上位机时OSD默认关闭，原校正画面仍输出。

## 屏显内容

- HOST CALIB FILE：从 `calibration/ov5640_1080p.json` 解析的 fx、fy、cx、cy、k1、k2、p1、p2。**不是FPGA寄存器回读**；若另一个上位机改过校正参数，这些值可能与实际生效值不一致。
- GRID RMS：在显示文字关闭期间，从3张1920×1080测试画面检测11×8棋盘角点，对行列做总最小二乘直线拟合，显示有效帧RMS中位数，单位像素。
- MTF50/SFR：同一无叠层棋盘图中的合格倾斜边缘，采用现有4倍过采样边缘扩展函数/线扩展函数估计50%处频率，单位cycles/output pixel；没有合格边缘就显示不可用。这是比较性估计，不是完整ISO12233认证。
- PUB FPS：板端累计完整校正帧发布数差 / 主机单调时钟秒数。第一个查询没有时间窗口，显示 `--.--`。它不等于摄像头每秒独特新源帧数，也不等于显示器刷新率。
- INV：上一发布帧的映射无效像素数；SEQ：板端当前active配置序号。板端核心/写入故障会在状态行显式标记。

不能把“线条直”当作锐度已验证，也不能用历史标定RMS代替当前实际测试。要比较矫正前后，应保持棋盘位置、曝光、焦距、裁剪和采集卡格式一致，分别采集干净画面后再对比。OSD区域不参与测量；本脚本测量前会短暂关闭OSD，捕获后恢复。

## 运行

1. 烧录**由本候选源码重新布线且通过时序检查**的位流。原`release/`位流没有OSD功能。
2. FPGA控制口与电脑连接，确认端口号。JY901P的COM12是另一条串口，不能当作FPGA控制口。
3. `python -m pip install -r requirements.txt`。自动识别Hagibis还需 `python -m pip install cv2-enumerate-cameras`；也可给 `--camera-index`。
4. 日常显示：`python host/osd_monitor.py --port COM11`。程序每秒刷新板端状态，Ctrl+C退出。
   原有 `python host/gui.py` 现有“HDMI参数叠层”开关和“测量图卡”按钮，适合边调仿射边展示。不能同时运行独立监控脚本和 GUI，因为它们占用同一个 FPGA 控制口。
5. 棋盘评估：`python host/osd_monitor.py --port COM11 --measure-once`。采集卡须连接USB3且不能被OBS等程序占用。测试图卡需包含完整11×8角点；MTF50需有符合角度、对比度和长度条件的边缘。
6. 离线主机检查：`python tools/check_osd_host.py`。RTL专用测试台：`python tools/run_sim.py video_osd_tb source/rtl/video_osd.v sim/video_osd_tb.v`。

## 待完成的资格验证

- ModelSim行像素、握手、显隐仿真，连同现有主链回归。
- 同一版本PDS综合与布线，setup/hold/recovery/removal全部闭合；记录相对基线的LUT/FF/DRM变化和WNS。
- 实板核对文字可读性、HDMI OUT无异常、UART命令及显示开关、矫正画面新帧率30/s；屏显样例必须拍照或采集留证。
- 通过配置回读或标定哈希闭环验证显示参数与真实板端参数一致。当前显示明确标为主机文件以防误判。

任何一项未完成，均不得用本候选替换原正式位流或声称板上通过。
