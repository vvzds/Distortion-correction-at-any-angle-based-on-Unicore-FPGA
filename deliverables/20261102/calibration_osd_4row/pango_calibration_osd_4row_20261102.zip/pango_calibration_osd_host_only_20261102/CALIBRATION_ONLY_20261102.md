# 标定参数专用 HDMI 显示工程

本工程由用户提供的 `pango_1080p30_HDMI_OSD_candidate_final_20261031.zip` 建立。只修改 `video_osd.v` 的四行显示边界和上位机屏显内容；采集、校正算法、IP 和板级约束沿用原包。旧位流 `release/osd_candidate_seed3_20261031.sbit` 保留供回退，其 SHA256 为 `f0917534a99df79905aba11331fd44e46ad2166c82216332f585727b81da6b66`。新四行位流的构建与资格记录见交付清单。

## HDMI 显示

只有以下四行文字，取自 `calibration/ov5640_1080p.json`：

```text
FX=1507.7104 FY=1507.4035
CX=883.5331 CY=568.6877
K1=-0.381483 K2=+0.156698
P1=-0.000303 P2=-0.000111
```

上位机每次开启叠层时还会向第 4 至第 7 行写入空格，清除旧版 FPS、画质、状态等文字。RTL 将深色背景与边框限制在 `x=24..807, y=24..127`，第 4 行文字以下恢复原始视频。UART 仍兼容 8 行协议，但第 4 至第 7 行不再绘制。

这些数字是**上位机标定文件解析值，不是 FPGA 配置寄存器回读值**。上位机可以解析 `fx/fy/cx/cy` 和 `k1/k2/p1/p2`，但若板端加载了另一套参数，屏显不能单独证明板端实际使用的是这一套。

## 使用

1. 将 `release/osd_calibration_4row_seed3_20261102.sbit` 下载到 FPGA SRAM；旧版 `release/osd_candidate_seed3_20261031.sbit` 仍保留供回退，但背景框仍有八行高。不写 Flash。新位流 SHA256 与 PDS 结果见 [FOUR_ROW_OSD_20261102.md](FOUR_ROW_OSD_20261102.md)。
2. FPGA 控制串口连接电脑后，在本目录执行 `python host/osd_monitor.py --port COMx`；把 `COMx` 换成实际端口。也可运行 `python host/gui.py`，连接串口后打开“HDMI参数叠层”。两者不可同时占用串口。
3. 如使用另一份标定文件，独立脚本传 `--calibration PATH`；GUI 中载入标定后，需要应用配置并重新打开叠层。

原包 `requirements.txt` 提供 Python 依赖。离线检查执行 `python tools/check_osd_host.py`，预览执行 `python tools/render_osd_preview.py`。本次没有连接板卡，实际屏显与 30 fps 均未重新板测。PDS 布线结果只证明新位流满足静态时序，不能替代板上验收。
