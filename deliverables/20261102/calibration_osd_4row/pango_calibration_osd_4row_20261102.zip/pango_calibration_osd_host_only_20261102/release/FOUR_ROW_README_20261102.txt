Four-row calibration HDMI OSD candidate for PG2L100H-6 FBG676.
Program osd_calibration_4row_seed3_20261102.sbit to SRAM only.
SHA256: 936faf1070b57a9aba778b0767a601f3de799b9f708bdaf1f5f4857e5d24467d
PDS 2022.2-SP6.1 seed 3: all timing constraints met.
Not yet programmed or measured on the board. See ../FOUR_ROW_OSD_20261102.md.
