# HDMI OSD 候选与原版同条件对照（2026-10-31）

来源：用户提供的 `pango_1080p30_software_release.zip` 原版。两组均使用本机 PDS 2022.2-SP6.1、PG2L100H-6 FBG676、同一板级约束、place/route seed 3。原压缩包历史发布记录使用 SP6.4；本报告用本机 SP6.1 重跑原版，以保证增量对比可解释。除 OSD RTL、UART 扩展及源清单外，候选沿用原工程。

| 项目 | 原版重跑 | HDMI OSD 候选 | 变化 |
|---|---:|---:|---:|
| LUT | 9,786 | 10,779 | +993 |
| FF | 13,209 | 17,100 | +3,891 |
| APM | 60 | 60 | 0 |
| DRM | 84.5 | 84.5 | 0 |
| 125 MHz DDR域 slow setup WNS | +0.593 ns | +0.543 ns | -0.050 ns |
| 74.25 MHz HDMI像素域 slow setup WNS | +9.021 ns | +1.372 ns | -7.649 ns |
| DDR域 slow hold WHS | +0.139 ns | +0.136 ns | -0.003 ns |
| HDMI像素域 slow hold WHS | +0.371 ns | +0.347 ns | -0.024 ns |
| 设计摘要 | All Constraints Met | All Constraints Met | 均通过 |

两组 slow/fast 角的 setup/hold/recovery/removal 报告都没有失败端点。本候选压缩了 HDMI 像素域时序余量；显示像素组合逻辑需上板复核。它没有改动摄像头采集、校正源读取、Brown4 映射、重采样、DDR 帧发布逻辑，因此不会凭这一改动提升或降低算法吞吐的理论预算；但真实 30 个不同校正画面/秒仍需板上计数实测。

已通过 `tools/check_host.py` 和 `tools/check_osd_host.py`，后者核对9个UART OSD命令、CRC封包、默认标定行和离线棋盘指标。ModelSim `vlog` 成功编译 `host_control.v` 与 `video_osd.v`，但本机 ModelSim 10.7 在加载设计时返回 `can't read "FileWatch(fileName)"`，因此**没有通过RTL功能仿真**。PDS 布线及生成位流成功不等价于功能仿真或实板证明。

本候选位流需要下载 SRAM 并通过显示器检查：上电无串口时画面与原版一致；GUI 打开 OSD 后文字出现在采集卡 HDMI OUT 屏幕与 USB 预览；切换仿射角度、开关 OSD、拍测试图卡、检查所有有效指标；持续统计 FPGA 发布帧率与不同的实际显示画面，确认没有新故障后才可考虑替换发布版。
