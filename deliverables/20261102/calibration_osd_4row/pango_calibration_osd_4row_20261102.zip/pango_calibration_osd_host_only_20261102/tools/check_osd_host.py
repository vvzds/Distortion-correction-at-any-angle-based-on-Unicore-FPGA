"""Offline OSD protocol and image-quality smoke check; opens no hardware."""
import json
from pathlib import Path
import sys

import cv2
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'host'))
from model import load_calibration
from osd_monitor import assess_frame,calibration_rows
from protocol import Connection,decode


class MockSerial:
    def __init__(self):self.writes=[]
    def write(self,data):self.writes.append(data);return len(data)


link=Connection.__new__(Connection)
link.serial=MockSerial()
link.sequence=10
rows=calibration_rows(load_calibration())
assert set(rows)==set(range(8))
assert all(rows[i].startswith(label) for i,label in enumerate(('FX=','CX=','K1=','P1=')))
assert all(rows[i]=='' for i in range(4,8))
for row,text in rows.items():
    link.osd_line(row,text)
link.osd_enable(True)
assert len(link.serial.writes)==9
for row,packet_bytes in enumerate(link.serial.writes[:-1]):
    command,sequence,payload=decode(packet_bytes)
    assert command==0x30 and sequence==11+row and len(payload)==49
    assert payload[0]==row and payload[1:].decode('ascii').rstrip()==rows[row]
assert decode(link.serial.writes[-1])==(0x31,19,b'\x01')
try:link.osd_line(8,'BAD')
except ValueError:pass
else:raise AssertionError('Invalid OSD row accepted')

sample=ROOT/'reports/real_images/pose_031_validation_center_yaw_left_corrected.png'
image=cv2.imdecode(np.frombuffer(sample.read_bytes(),dtype=np.uint8),cv2.IMREAD_COLOR)
assert image is not None and image.shape[:2]==(1080,1920)
quality=assess_frame(image)
assert quality['straightness']['rms_px']<.5
assert quality['accepted_sfr_edges']>=1
assert 0<quality['mtf50_cycles_per_pixel']<.5
print(json.dumps({'passed':True,'uart_osd_packets':9,'sample_grid_rms_px':quality['straightness']['rms_px'],
                  'sample_mtf50_cycles_per_pixel':quality['mtf50_cycles_per_pixel'],
                  'sample_sfr_edges':quality['accepted_sfr_edges'],'hardware_opened':False},indent=2))
