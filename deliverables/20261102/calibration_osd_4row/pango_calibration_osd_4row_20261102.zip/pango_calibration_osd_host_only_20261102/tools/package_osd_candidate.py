"""Package routed OSD candidate and exact baseline comparison, without programming hardware."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

root=Path(__file__).resolve().parents[1]
osd=Path('D:/fpga_osd_20261031/build/pds/osd_seed3')
baseline=Path('D:/fpga_osd_baseline_20261031/pango-undistort/build/pds/baseline_seed3')
project_out=root.parents[2]/'deliverables'
project_out.mkdir(exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

for folder in (osd,baseline):
    receipt=json.loads((folder/'receipt.json').read_text(encoding='utf-8'))
    if receipt['exit_code']!=0 or not receipt['timing_passed']:
        raise RuntimeError(f'PDS timing not passed: {folder}')
    for src in (folder/'source').rglob('*'):
        if src.is_file():
            current=root/src.relative_to(folder)
            if not current.is_file() or hashlib.sha256(src.read_bytes()).digest()!=hashlib.sha256(current.read_bytes()).digest():
                if folder==osd:raise RuntimeError(f'OSD source differs from routed snapshot: {src}')

bitstream=osd/'generate_bitstream/hdmi_ddr_ov5640_top.sbit'
target=root/'release/osd_candidate_seed3_20261031.sbit'
if target.exists():
    if sha(target)!=sha(bitstream):raise RuntimeError('Existing candidate bitstream differs from routed snapshot')
else:shutil.copy2(bitstream,target)

reports=root/'reports/pds_osd_comparison_20261031'
reports.mkdir(exist_ok=True)
for label,folder in (('osd',osd),('baseline',baseline)):
    shutil.copy2(folder/'receipt.json',reports/f'{label}_receipt.json')
    shutil.copy2(folder/'source_hashes.json',reports/f'{label}_source_hashes.json')
    shutil.copy2(folder/'console.log',reports/f'{label}_console.log')
    shutil.copy2(folder/'report_timing/hdmi_ddr_ov5640_top.rtr',reports/f'{label}_timing.rtr')

manifest={
    'role':'Board-trial candidate; not board validated or promoted',
    'date':'2026-10-31',
    'original_zip':'pango_1080p30_software_release.zip',
    'original_zip_sha256':sha(Path('C:/Users/叶翔/xwechat_files/wxid_qanrp2aqlq8h22_bb90/msg/attach/45c166d2013de1ef13bda2f11286b94b/2026-10/Rec/772609ab0ca26de9/F/0/pango_1080p30_software_release.zip')),
    'candidate_bitstream':str(target.relative_to(root)).replace('\\','/'),
    'candidate_bitstream_sha256':sha(target),
    'pds_version':'2022.2-SP6.1',
    'place_route_seed':3,
    'candidate_source_manifest_sha256':json.loads((osd/'receipt.json').read_text())['source_manifest_sha256'],
    'baseline_source_manifest_sha256':json.loads((baseline/'receipt.json').read_text())['source_manifest_sha256'],
    'verification':{
        'pds_candidate_route_timing':True,
        'pds_baseline_route_timing':True,
        'host_checks':True,
        'osd_host_offline_checks':True,
        'rtl_functional_simulation':False,
        'board_validation':False,
        'simulator_blocker':'ModelSim 10.7 design loading: FileWatch(fileName) missing',
    },
}
(root/'release/osd_candidate_manifest_20261031.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

name='pango_1080p30_HDMI_OSD_candidate_final_20261031'
archive=project_out/(name+'.zip')
if archive.exists():raise FileExistsError(archive)
files=[p for p in sorted(root.rglob('*')) if p.is_file() and p.name!='SHA256SUMS_OSD_20261031.txt'
       and not any(q in {'build','__pycache__'} for q in p.relative_to(root).parts)]
checks={p.relative_to(root).as_posix():sha(p) for p in files}
hashes=root/'SHA256SUMS_OSD_20261031.txt'
hashes.write_text(''.join(f'{digest}  {path}\n' for path,digest in checks.items()),encoding='utf-8')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in files+[hashes]:z.write(path,name+'/'+path.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for path,digest in checks.items():
        assert hashlib.sha256(z.read(name+'/'+path)).hexdigest()==digest,path
    assert hashlib.sha256(z.read(name+'/release/osd_candidate_seed3_20261031.sbit')).hexdigest()==manifest['candidate_bitstream_sha256']
archive_hash=sha(archive)
archive.with_suffix('.zip.sha256').write_text(archive_hash+'  '+archive.name+'\n',encoding='utf-8')
print(json.dumps({'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':archive_hash,
                  'bitstream':str(target),'bitstream_sha256':sha(target),'verified_files':len(checks)},ensure_ascii=False,indent=2))
