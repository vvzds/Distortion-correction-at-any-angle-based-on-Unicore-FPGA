"""Render the RTL 5x7 glyph table over a held-out image for layout review."""
from pathlib import Path
import re
import sys

import cv2
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'host'))
from model import load_calibration
from osd_monitor import calibration_rows

source=(ROOT/'source/rtl/video_osd.v').read_text(encoding='ascii')
font={}
for code,body in re.findall(r"8'h([0-9a-f]{2}):glyph=\{([^}]+)\}",source):
    rows=re.findall(r"5'b([01]{5})",body)
    assert len(rows)==7
    font[chr(int(code,16))]=rows
sample=ROOT/'reports/real_images/pose_031_validation_center_yaw_left_corrected.png'
image=cv2.imdecode(np.frombuffer(sample.read_bytes(),np.uint8),cv2.IMREAD_COLOR)
assert image is not None and image.shape[:2]==(1080,1920)
rows=calibration_rows(load_calibration())
cv2.rectangle(image,(24,24),(807,223),(44,36,17),-1)
cv2.rectangle(image,(24,24),(807,223),(169,181,68),1)
for line,text in rows.items():
    color=(243,245,241)
    for col,ch in enumerate(text.upper()[:48]):
        for yy,bits in enumerate(font.get(ch,['00000']*7)):
            for xx,bit in enumerate(bits):
                if bit=='1':
                    px=32+col*16+xx*2;py=32+line*24+yy*2
                    cv2.rectangle(image,(px,py),(px+1,py+1),color,-1)
target=ROOT/'reports/osd_layout_preview.png'
encoded,png=cv2.imencode('.png',image)
assert encoded
target.write_bytes(png.tobytes())
print(target)
