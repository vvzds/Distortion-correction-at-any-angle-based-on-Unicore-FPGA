@echo off
cd /d "%~dp0"
python host\imu_trial.py %*
pause
