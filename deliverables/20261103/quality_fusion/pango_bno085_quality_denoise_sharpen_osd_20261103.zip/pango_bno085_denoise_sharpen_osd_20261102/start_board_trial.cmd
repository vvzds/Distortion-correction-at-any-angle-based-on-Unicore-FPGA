@echo off
cd /d "%~dp0"
python tools\start_feedback_trial.py --port COM9
pause
