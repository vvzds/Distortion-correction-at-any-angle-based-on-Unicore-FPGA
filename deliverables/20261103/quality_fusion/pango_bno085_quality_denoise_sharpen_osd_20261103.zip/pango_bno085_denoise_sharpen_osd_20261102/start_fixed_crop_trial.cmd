@echo off
cd /d "%~dp0"
python host\board_trial.py --port COM9 --zoom 1.5
pause
