PG2L100H-6 FBG676 / PDS2022.2-SP6.4
Selected seed: 3, slow setup WNS +0.593ns with 0.4ns setup uncertainty.
All 3 implementation seeds passed all STA constraints.
Hardware is disconnected: bitstream has NOT been programmed or board-tested.
SHA256: 38ab1af1fc0fe1c15a7934d91b343679b0d4c999d788714bcf9b199b13a42ffd
See ../BOARD_TEST.md and ../reports/pds_seed_summary.json.
