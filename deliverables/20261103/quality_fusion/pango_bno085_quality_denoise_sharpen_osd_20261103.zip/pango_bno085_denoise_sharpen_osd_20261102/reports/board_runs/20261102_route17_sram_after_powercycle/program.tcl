cfg_set_tcl_break -flag true
cfg_connect -ip 127.0.0.1 -port 65421
cfg_set_cable_property -index 0 -freq 10Mhz
cfg_scan_chain
cfg_assign_file -file C:/Users/lenovo/Documents/Codex/_route17_sram_20261102_1/candidate.sbit -device_index 0
cfg_set_device_property -device_index 0 -program 0 -readback 0
cfg_program -device_index 0
cfg_disconnect
cfg_close
