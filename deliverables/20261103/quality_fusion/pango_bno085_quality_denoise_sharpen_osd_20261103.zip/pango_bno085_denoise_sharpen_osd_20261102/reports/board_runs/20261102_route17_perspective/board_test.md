# BNO085 透视补偿板测记录

日期：2026-11-02（Asia/Shanghai）

## 构建与下载

- 工程：`build/pds/map_route17_seed3_rotpipe/pango_undistort.pds`
- 器件：PG2L100H-6 FBG676，JTAG ID `0x00602899`
- PDS：2022.2-SP6.1，seed 3
- 时序：`All Constraints Met`；DDR PHY setup WNS `+0.396 ns`，hold WHS `+0.134 ns`，失败端点为 0
- 位流：`candidate.sbit`，3,791,112 字节
- SHA-256：`63B9A5904757903DA33BAAF301A66F802F9B5A64D6315EB6B661D20899BEB7FD`
- SRAM/JTAG 临时配置成功，`done bit=1`；未写入 Flash

## 仿真验证

- `check_imu_projective_map.py`：4 组姿态/透视系数测试通过
- 1080p native video 回归：2,073,600 个像素全部匹配 golden

## 实板结果

- HDMI 视频稳定，画面可见
- COM8、115200 baud 状态包确认固件身份正确
- 姿态透视使能、参考姿态有效、映射有效；最终 `capture_generation=2`
- 倾斜摄像头时，操作者观察到画面有明显补偿，同时出现黑边
- 重新锁定当前姿态后，操作者确认基准画面没有黑边
- 倾斜状态读取：`invalid_pixels=6867`、`overflow_tiles=0`、`core_fault=false`、`write_fault=false`
- `rx_errors=1`，本轮锁定前后均为 1；没有观察到新增串口错误
- 上位机 GUI 验证：GUI 连接 COM8 并锁定姿态成功；用户观察到倾斜时出现黑边，转回锁定姿态后黑边消失
- 后续手机视频 `1c07f7f2a5751466ae9e3c81354c1cde.mp4`（约 17.8 秒）同时拍到棋盘卡、FPGA 设备和 HDMI 屏幕；设备动作期间 HDMI 棋盘画面持续可见。视频未拍到上位机状态，也没有同角度补偿开/关对照，不能据此量化几何校正精度。

黑边是校正后映射到摄像头有效视野之外的像素，当前 RTL 将这些输出像素置黑。本版本没有自动裁边或动态放大；增大裁剪/缩放可减少黑边，但会损失视场。此次只验证了可见补偿，没有测出最大可接受姿态角，也没有保留 HDMI 截图或视频。

## 交付文件

- 本目录：`candidate.sbit`、`program.txt`、`program_receipt.json`
- 完整 PDS 工程快照与时序报告：`build/pds/map_route17_seed3_rotpipe/`
- 更新后的 IMU 透视 RTL：`source/rtl/imu_projective_map.v`
- JTAG 程序员脚本修正：`tools/program_sram.py`（使用工作目录内的相对 Tcl 文件名）

上位机 GUI 姿态锁定和可见补偿流程已完成一次实板验证。尚未保留 HDMI 截图或演示视频，也未测出最大可接受姿态角。
