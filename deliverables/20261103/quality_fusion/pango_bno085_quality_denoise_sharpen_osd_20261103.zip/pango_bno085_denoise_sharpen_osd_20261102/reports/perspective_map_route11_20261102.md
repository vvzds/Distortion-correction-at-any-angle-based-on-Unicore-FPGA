# BNO085 姿态驱动透视映射交付记录

日期：2026-11-02  
工程：PG2L100H / OV5640 / Pango PDS 2022.2-SP6.1

## 实现

- 从 BNO085 SPI/SHTP 姿态快照取得四元数；用户已提供板端 SPI 链路约 200 Hz 的验证信息。
- FPGA 保存参考姿态，计算相对四元数、相机坐标系旋转矩阵和逆映射参数，按组更新现有校正参数。
- 原有 125 MHz 像素映射/插值主流水保持每拍接收能力；新增姿态运算在控制路径分阶段完成。
- 当前模型补偿相机绕光心旋转。它不估计平移、近景视差或场景深度，不能宣称为对任意场景、任意倾斜平面的通用透视矫正。

## 开源参考

- CEVA `sh2`：https://github.com/ceva-dsp/sh2 ，固定提交 `b514b1e2586ddc195e553dac89fc94c637b25298`。
- SparkFun BNO08x Arduino Library： https://github.com/sparkfun/SparkFun_BNO08x_Arduino_Library ，固定提交 `fd0149c280b4c7420e2dea4d034587373a8ca8b9`。
- BNO085 数据手册与资料来源、校验记录见 [bno085_sources.json](bno085_sources.json)。上游用于核对器件协议和数据格式，没有直接复制其 MCU 驱动代码进 FPGA。

## 验证

- `tools/check_imu_projective_map.py`：通过；4 组参考/姿态映射用例，另覆盖启动同步、配置序号更新和 IMU epoch 失效。
- `tools/run_sim.py host_control_tb ...`：通过；UART CRC、参数检查、帧原子配置与 IMU 命令用例通过。
- PDS seed 3 完整布线：`Design Summary : All Constraints Met.`
- DDR slow-corner setup WNS：`+0.008 ns`，失败端点 0；hold WHS：`+0.141 ns`，失败端点 0。
- DDR fast-corner setup WNS：`+2.336 ns`；hold WHS：`+0.101 ns`。全工程报告中 setup、hold、recovery、removal 均通过。
- 资源：LUT 14,953 / 66,600（22.45%）；寄存器 20,575 / 133,200（15.45%）；DRM 84.5 / 155（54.52%）；APM 148 / 240（61.67%）。

## 候选位流

- PDS 快照：`build/pds/map_route11_seed3/`
- 位流：`build/pds/map_route11_seed3/generate_bitstream/hdmi_ddr_ov5640_top.sbit`
- 大小：3,791,112 字节
- SHA-256：`0798DDB9622FFB7F74B40D902AA96B4F25FB0B384FF81DC091B3C6BCE220AFEE`
- 源码快照清单哈希：`66907febb936ba26fcdd10e0abdf5d9140367531415ec72b1dcfea4c501118e0`

该构建通过静态时序分析，但还没有用这份新位流做板端验证。由于板卡此前反馈过热，板端确认须等板卡冷却、检查供电/散热后再由操作者临时 SRAM/JTAG 配置；目前不写 Flash。
