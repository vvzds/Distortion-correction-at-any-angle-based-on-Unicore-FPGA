# 当前工程快照（2026-10-31）

本包为当前暂时最新工程，代码基准提交：fd228f3862afffc2a96ca94eb9c76a9e2c550e71。板测按用户要求暂停。

包含完整RTL/厂商IP源文件、PDS工程与约束、上位机、标定配置、仿真及验证工具、测试报告、可下载位流和旧版本回退文件。未包含PDS/ModelSim/Python安装目录、Git数据库、可重新生成的编译缓存及本轮原始采集画面/逐样本日志。

## 当前状态

- 2026-11-01 在完整包基础上接入纯 FPGA BNO085 旋转透视参数生成、UART命令0x26、GUI控制与状态回读。ModelSim验证四组姿态/参考重锁/epoch失效回退，UART命令测试和主机检查通过。
- 此实现尚无 PDS 综合/布线报告、时序结论或新位流，未做板测；不要用现有发布位流声称包含此功能，也不要下载本轮未通过构建的产物。
- 本机 PDS 2022.2-SP6.1 在读取 `build.tcl` 时失败，错误称脚本不存在，尽管快照目录中该文件存在；当前无法取得资源/时序数据。ModelSim 全 RTL 清单为0 errors、123 warnings（旧 `fram_buf.v` 换行格式提示）。
- 这次修正了 HDMI 顶层缺失的 `core_clk`/`hs_o` 声明及旧模块输出重复声明，以消除通用 RTL 编译错误。

- BNO085经SPI接FPGA，由板载USB串口转发PC；实板姿态约200Hz，通信错误0。
- 当前有效安装外参见calibration/bno085_mount.json，由独立抬头/右转动作与滚转反馈修订；原声明映射也保留在其中。
- 滚转补偿经用户主观初步验收。最新仿射初测：抬头后无明显变化；右转有十分微小的局部拉伸感；滚转基本稳定。完整仿射尚未验收，不能将旧视频链路验收视为新仿射全部功能通过。
- 裁边1.0～2.5倍，每档0.1倍，共16档，默认1.5倍，按钮或键盘+/-可调。
- FPGA专用位流：release/pango_undistort_bno085_r1.sbit；身份/时序文件：release/bno085_manifest.json。该位流不变，最近修订在上位机配置和界面。
- BNO初版manifest中的hardware_tested=false是发布时的历史状态；后续实测见reports/bno085_roll_board_acceptance.json、bno085_axis_direction_review.json和bno085_affine_trial_feedback_20261031.json。

## 使用方法

在解压后的pango-undistort目录打开终端。串口COM9是本机既往端口，换电脑须指定实际端口。需要Python 3和Tkinter；依赖：

    python -m pip install -r requirements-board.txt

最近板测用的小角度仿射模式（手动开启Gamma）：

    python host/bno085_trial.py --port COM9 --mode affine --gamma

已初步验收的滚转模式：

    python host/bno085_trial.py --port COM9 --mode roll --gamma

双击start_bno085_trial.cmd默认进入roll模式，Gamma可按G开启。程序启动时补偿OFF；S/空格静止锁参考，X关闭，R重锁，P冻结，G切Gamma，+/-裁边，Q/Esc退出。退出会尝试恢复无裁边自然去畸变画面。

断电后SRAM程序会丢失。接线核对、板卡允许使用且PDS JTAG server启动后下载：

    python tools/program_sram.py --manifest release/bno085_manifest.json --output reports/board_runs/new_bno_download

output必须使用新目录。命令仅下载SRAM，不写Flash。接线表见docs/BNO085初版接线与板测.md。

## 重建

本机环境PDS2022.2-SP6.4，目标PG2L100H-6 FBG676。tools/build.py会复制完整输入并保存哈希：

    python tools/build.py --name bno_rebuild_unique_name --seed 3

新电脑使用--pds指定安装目录。源代码/配置不应依赖旧build目录；历史报告中存在原机器绝对路径，仅作证据。使用PDS命令行构建脚本build.tcl，避免将旧工程数据库当作新实现结果。

## 已知边界

姿态透视补偿仅为纯旋转模型，假设绕光心转动，不补偿平移、近景视差或深度变化；待 PDS 时序闭合和实板方向/画面验证。

二维仿射仅近似小角度俯仰/偏航，默认倾角限15°；Game模式长期航向可漂移；端到端延迟尚无定量实测；固定裁边不能保证所有角度无黑边。下一轮应优先检查偏航局部拉伸及混合运动。

DELIVERY_SHA256.json列出包内文件SHA256；压缩包旁另附整体.sha256。旧文档/manifest保留其原版本结论，当前快照状态以本说明和上述BNO实测记录为准。
