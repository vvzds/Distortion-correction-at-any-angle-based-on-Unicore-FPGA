@echo off
cd /d "%~dp0"
python host\bno085_trial.py %*
pause
