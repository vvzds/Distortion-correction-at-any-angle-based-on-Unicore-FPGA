# Full Engineering Package: BNO085 + Quality Pipeline + Calibration OSD

This combined source candidate preserves the full BNO085 project and adds the
display-only denoise stage, prior sharpen stage, four-row HDMI OSD, and host GUI
quality controls.

- Includes the BNO085 SPI/SHTP RTL, FPGA projective-map source, host controls,
  calibration, vendor IP, PDS project/constraints, historical release images,
  simulation sources, and verification reports.
- Adds RGB565 edge-aware five-tap horizontal denoise, bounded five-tap horizontal
  sharpening, separate host quality controls, and four-row HDMI calibration OSD.
- The seed 3 projective-map build candidate and timing receipt are under `reports/board_runs/20261102_route17_perspective/`; the projective-map candidate has not been board-accepted.
- `release/pango_bno085_quality_denoise_sharpen_osd_seed7_20261103.sbit` is the
  combined candidate. Its seed7 PDS route passed all constrained setup/hold
  checks. SHA256 and exact source-manifest identity are in
  `release/quality_fusion_seed7_manifest.json`.
- The combined candidate has not been programmed or visually accepted on the
  board. In particular, stable 1080p30 and denoising quality remain unverified.
- Generated `build/` databases, `.venv`, Python bytecode caches, and `.git` are
  omitted from the share ZIP. The final PDS receipt, source hashes, timing report,
  and route logs are retained in `reports/pds/denoise_sharpen_osd_final_seed7_20261103/`.

Open `pango_undistort.pds` in PDS. The batch build entry is `build.tcl`.
