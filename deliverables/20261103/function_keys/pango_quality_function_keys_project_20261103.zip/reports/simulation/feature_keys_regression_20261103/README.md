# Feature-Key Candidate RTL Regression

ModelSim SE-64 10.7 compiled and ran these current-source module testbenches on
2026-11-03. The compile logs report zero errors and zero warnings. Each bench
uses fatal assertions for failed expectations; all five reached normal finish.

| Testbench | Coverage |
|---|---|
| `feature_key_control_tb` | Active-low synchronization/debounce, defaults, one event per press, all key modes, KEY1 host/key state sharing, KEY3 preset cycle, KEY4 host/key synchronization |
| `display_denoise_tb` | Flat field, impulse response, edge guard, bypass |
| `display_sharpen_tb` | Flat field, black guard, hard edge, bypass, data enable |
| `video_osd_tb` | Glyph/panel rendering, passthrough, blanking, frame-boundary visibility |
| `host_control_tb` | UART frame/CRC, command bounds, atomic update, replacement, status, IMU commands |

Each subdirectory keeps `run.log`, `receipt.json`, and `inputs.json` with the
input manifest SHA256. These checks validate the listed modules only. They do
not prove full-frame correction throughput, stable 1080p30, or board behavior.
